// Readable fence for the 1.1.0 corpus. apply.mjs checks this before execution.
// Bare and blank are forms, not private code points.

export const SCHEMA = 'cc0.query-key-cases.v4';
export const CASE_IDS = Object.freeze([
  'grouped-ampersand',
  'pair-in-one-value',
  'pair-order',
  'value-order',
  'path-delimiter',
  'space-encodings',
  'semicolon-value',
  'dict-list',
  'body-json-type',
  'body-bool-type',
  'body-field-shape',
  'unicode-key',
  'key-holds-equals',
  'bare-versus-blank',
  'blank-versus-absent',
  'bare-versus-absent',
  'swapped-bare-blank',
  'bare-blank-order',
  'duplicate-bare',
  'unicode-bare-blank',
  'encoded-blank-neighbor',
  'key-equals-bare-blank',
  'unicode-value-order',
  'empty-segment',
  'duplicate-with-bare-neighbor',
]);

const TOP_KEYS = ['schema', 'license', 'role', 'customerDemand', 'independentContributor', 'codec', 'legend', 'bank', 'cases'];
const CASE_KEYS = ['id', 'left', 'right', 'oldEqual', 'midEqual', 'nowEqual', 'm', 'lp', 'rp', 'include', 'bodyL', 'bodyR', 'dictKey', 'dictVals', 'wire', 'gap', 'gapRight'];

function fail(code) {
  const error = new Error(code);
  error.code = code;
  throw error;
}

function bankString(bank, index) {
  if (typeof index !== 'number' || !Number.isInteger(index) || index < 0 || index >= bank.length) fail('bank_refused');
  const value = bank[index];
  if (typeof value !== 'string') fail('bank_refused');
  if (value.length > 0 && /%[0-9A-Fa-f]{2}/.test(value)) fail('bank_refused');
  if (/[\u0000-\u001f\u007f]/.test(value)) fail('bank_refused');
  return value;
}

function specs(bank, rows) {
  if (!Array.isArray(rows)) fail('pairs_refused');
  for (const item of rows) {
    if (Array.isArray(item)) {
      if (item.length !== 2) fail('pairs_refused');
      bankString(bank, item[0]);
      bankString(bank, item[1]);
      continue;
    }
    if (!item || typeof item !== 'object' || Array.isArray(item)) fail('pairs_refused');
    if (Object.keys(item).some((key) => !['k', 'form', 'v'].includes(key)) || !Object.hasOwn(item, 'k') || !Object.hasOwn(item, 'form')) fail('pairs_refused');
    bankString(bank, item.k);
    if (!['value', 'bare', 'blank'].includes(item.form)) fail('representation_refused');
    if (item.form === 'value') {
      if (!Object.hasOwn(item, 'v')) fail('pairs_refused');
      bankString(bank, item.v);
    } else if (Object.hasOwn(item, 'v')) fail('representation_refused');
  }
}

export function assertCorpus(artifact) {
  if (!artifact || typeof artifact !== 'object' || Array.isArray(artifact)) fail('artifact_refused');
  if (artifact.schema !== SCHEMA || artifact.license !== 'CC0-1.0') fail('artifact_refused');
  if (artifact.role !== 'first-party-seed' || artifact.customerDemand !== false || artifact.independentContributor !== false) fail('label_refused');
  if (artifact.codec !== 'urllib.parse.quote' || Object.hasOwn(artifact, 'code') || Object.hasOwn(artifact, 'identity')) fail('artifact_refused');
  if (Object.keys(artifact).sort().join() !== TOP_KEYS.slice().sort().join()) fail('artifact_refused');
  if (typeof artifact.legend !== 'string' || !artifact.legend.includes('expectations, not execution') || !artifact.legend.includes('bare') || !artifact.legend.includes('blank')) fail('artifact_refused');
  const bank = artifact.bank;
  if (!Array.isArray(bank) || bank.length !== 22) fail('bank_refused');
  if (bankString(bank, 0) !== 'a' || bankString(bank, 6) !== '/p' || bankString(bank, 20) !== 'a=1' || bankString(bank, 21) !== '') fail('bank_refused');
  for (let index = 0; index < bank.length; index += 1) bankString(bank, index);
  if (!Array.isArray(artifact.cases) || artifact.cases.length !== CASE_IDS.length) fail('case_shape');
  artifact.cases.forEach((item, index) => {
    if (!item || typeof item !== 'object' || Array.isArray(item) || item.id !== CASE_IDS[index]) fail('case_shape');
    if (Object.keys(item).some((key) => !CASE_KEYS.includes(key))) fail('case_shape');
    if (typeof item.oldEqual !== 'boolean' || typeof item.midEqual !== 'boolean' || typeof item.nowEqual !== 'boolean') fail('expectation_refused');
    if (item.left !== undefined) specs(bank, item.left);
    if (item.right !== undefined) specs(bank, item.right);
    if (item.wire !== undefined && typeof item.wire !== 'boolean') fail('representation_refused');
    if (item.gap !== undefined && item.gap !== 'between') fail('representation_refused');
    if (item.gapRight !== undefined && item.gapRight !== 'between') fail('representation_refused');
    if ((item.gap || item.gapRight) && item.wire !== true) fail('representation_refused');
    if (item.wire === true && item.dictKey !== undefined) fail('representation_refused');
  });
  return {schema: SCHEMA, cases: CASE_IDS.length, bank: bank.length};
}
