# Query-key 1.1.0

Original CC0 cases plus the raw-query forms a later checkout kept apart. Stored `oldEqual`, `midEqual`, and `nowEqual` values are expectations. They are not execution.

A bare segment has no `=` (`?a`). A blank segment has `=` and an empty value (`?a=`). A missing key is absent. Duplicates stay a multiset. Wires are generated with `urllib.parse.quote` and `safe=""`. They are not stored in `corpus.json`. A literal `+` becomes `%2B`. An `&` inside a value becomes `%26`. This recipe does not invent a private code point for bare or blank, and it does not execute supplied text.

Upstream request-key code stays under its own MIT licence. It is an input, not part of this archive. See `UPSTREAM.txt`. The author reported 133 passed and 2 skipped on their own tests. This archive does not replay that run.

## Caller document

`apply` reads one JSON document with schema `cc0.query-key-caller.v4`. The corpus file is still required and is checked on its own. You do not edit the 25 stored cases. The caller document is not a corpus case.

```json
{
  "schema": "cc0.query-key-caller.v4",
  "left": {"method": "GET", "path": "/next-consumer-42", "pairs": [
    {"key": "route=λ", "form": "bare"},
    {"key": "next", "form": "value", "value": "7&8"}
  ]},
  "right": {"method": "GET", "path": "/next-consumer-42", "pairs": [
    {"key": "route=λ", "form": "blank"},
    {"key": "next", "form": "value", "value": "7&8"}
  ]}
}
```

`left` and `right` each have `method`, `path`, and `pairs`. A pair is an object with `key` and `form`. `form` is `bare`, `blank`, or `value`. `value` is present only for `form` `value`, and it must be a non-empty string. An empty value is `blank`, not `value`. Optional `body` is a flat object of strings, finite numbers, and booleans. `bodyInclude` is required exactly when `body` is present, and every included name must be a body field. Optional top-level `expect` is `{oldEqual, midEqual, nowEqual}` and is compared only after the three checkouts run. It never supplies the result. Extra keys, percent-encoded caller strings, unknown forms, and nested body values are refused. Examples under `examples/` are inputs, not special cases in the runner.

## Run

Extract this archive. From the `query-key-1.1.0` directory:

```
node apply.mjs decode --artifact corpus.json
node apply.mjs cases --artifact corpus.json
node apply.mjs apply --artifact corpus.json --input examples/next-consumer.json
```

Without `--before`, `--middle`, and `--after` together, execution stays false and actual equality is unknown. The codec wire is still returned and is labeled as not execution. Pass three clean checkouts only when you already have them:

```
node apply.mjs cases --artifact corpus.json --before /path/to/before --middle /path/to/middle --after /path/to/after
node apply.mjs mount --before /path/to/before --middle /path/to/middle --after /path/to/after
node apply.mjs apply --artifact corpus.json --input examples/next-consumer.json --before /path/to/before --middle /path/to/middle --after /path/to/after
node apply.mjs apply --artifact corpus.json --input examples/next-consumer.json --before /path/to/before --middle /path/to/middle --after /path/to/after --mount
```

`--before` must be commit `f0b3e89463d4b291cab95830151c4c1c05ff04b6`. `--middle` must be commit `164d9e30abf5cd8aa3c2eaae617c71a115b24fbe`. `--after` must be commit `9cdf0e470a232c2a9779c88f080a2aeb1e76a664`. One Python process evaluates the corpus, and one process evaluates a caller document. `mount` listens on `127.0.0.1` and calls the checkout's middleware with an in-process confirmation double and an in-process consumption store. `--mount` on `apply` does that for the caller pair. Both sides must be `GET` and must use the same `bodyInclude`. It needs `fastapi`, `starlette`, and `uvicorn` on the local `python3`. A missing directory is `sdk_unavailable`. A wrong commit is `pin_mismatch`. A missing middleware library is `middleware_dependency_unavailable`. A caller expectation that disagrees with the checkouts is `expectation_mismatch`. This recipe does not select a checkout, open a wallet, call a live RPC, or settle a payment.

Hosted acquisition of this archive is not claimed.
