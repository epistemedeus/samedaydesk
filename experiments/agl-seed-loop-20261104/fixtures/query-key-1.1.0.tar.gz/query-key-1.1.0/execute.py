#!/usr/bin/env python3
"""Three-pin query runner, caller-input command, and loopback probe.

Stored corpus expectations are checked only after the pinned checkouts run.
Caller input is a separate document. Its equality comes from those checkouts,
never from a stored row. This file does not choose a checkout, sign, open a
wallet, settle a payment, or execute supplied text.
"""
import http.client
import importlib
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
import types
from pathlib import Path
from urllib.parse import quote

sys.dont_write_bytecode = True

BEFORE = "f0b3e89463d4b291cab95830151c4c1c05ff04b6"
MIDDLE = "164d9e30abf5cd8aa3c2eaae617c71a115b24fbe"
AFTER = "9cdf0e470a232c2a9779c88f080a2aeb1e76a664"
SCHEMA = "cc0.query-key-cases.v4"
CALLER_SCHEMA = "cc0.query-key-caller.v4"
CALLER_LIMIT = 65536
TEXT_RE = re.compile(r"[\x00-\x1f\x7f]")
PCT_RE = re.compile(r"%[0-9A-Fa-f]{2}")
CASE_IDS = (
    "grouped-ampersand", "pair-in-one-value", "pair-order", "value-order",
    "path-delimiter", "space-encodings", "semicolon-value", "dict-list",
    "body-json-type", "body-bool-type", "body-field-shape", "unicode-key",
    "key-holds-equals", "bare-versus-blank", "blank-versus-absent",
    "bare-versus-absent", "swapped-bare-blank", "bare-blank-order",
    "duplicate-bare", "unicode-bare-blank", "encoded-blank-neighbor",
    "key-equals-bare-blank", "unicode-value-order", "empty-segment",
    "duplicate-with-bare-neighbor",
)
RAW = {
    "bare-versus-blank": ("a", "a="),
    "blank-versus-absent": ("a=", ""),
    "bare-versus-absent": ("a", ""),
    "swapped-bare-blank": ("a=&b", "a&b="),
    "bare-blank-order": ("a&a=", "a=&a"),
    "duplicate-bare": ("a&a", "a"),
    "unicode-bare-blank": ("q%CE%BB", "q%CE%BB="),
    "encoded-blank-neighbor": ("a=1%262&b=", "a=1%262&b"),
    "key-equals-bare-blank": ("a%3D1", "a%3D1="),
    "unicode-value-order": ("q%CE%BB=%C3%A9&q%CE%BB=%C3%BC", "q%CE%BB=%C3%BC&q%CE%BB=%C3%A9"),
    "empty-segment": ("a=1&&b=2", "a=1&b=2"),
    "duplicate-with-bare-neighbor": ("a=1&a=2&b", "a=2&a=1&b="),
}
PAY = "nano_pay"
attempts = []
_orig_connect = None


def fail(code, **extra):
    print(json.dumps({"ok": False, "code": code, **extra}, ensure_ascii=False))
    raise SystemExit(1)


def flag(name):
    if name not in sys.argv:
        return None
    index = sys.argv.index(name)
    if index + 1 >= len(sys.argv) or sys.argv[index + 1].startswith("--"):
        fail("usage")
    return sys.argv[index + 1]


def switched(name):
    return name in sys.argv


def install_socket_guard():
    global _orig_connect
    import socket
    _orig_connect = socket.socket.connect

    def guarded(self, address):
        host = address[0] if isinstance(address, tuple) and address else str(address)
        attempts.append({"fn": "connect", "host": str(host)})
        if host in ("127.0.0.1", "::1"):
            return _orig_connect(self, address)
        raise OSError("connect_refused")

    socket.socket.connect = guarded


def footprint():
    pid = os.getpid()
    text = Path(f"/proc/{pid}/status").read_text()
    fields = {}
    for line in text.splitlines():
        if line.startswith(("VmRSS:", "Threads:", "PPid:", "Pid:")):
            key, value = line.split(":", 1)
            fields[key] = value.strip()
    raw = Path(f"/proc/{pid}/task/{pid}/children").read_text().strip()
    return {"pid": pid, "rssKb": int(fields["VmRSS"].split()[0]), "threads": int(fields["Threads"]), "childPids": raw.split() if raw else []}


def bank_string(bank, index):
    if isinstance(index, bool) or not isinstance(index, int) or index < 0 or index >= len(bank):
        fail("bank_refused")
    value = bank[index]
    if not isinstance(value, str) or (value and re.search(r"%[0-9A-Fa-f]{2}", value)) or re.search(r"[\x00-\x1f\x7f]", value):
        fail("bank_refused")
    return value


def specs_from(bank, rows):
    if not isinstance(rows, list):
        fail("pairs_refused")
    out = []
    for item in rows:
        if isinstance(item, list):
            if len(item) != 2:
                fail("pairs_refused")
            out.append({"key": bank_string(bank, item[0]), "form": "value", "value": bank_string(bank, item[1])})
            continue
        if not isinstance(item, dict) or set(item) - {"k", "form", "v"} or "k" not in item or "form" not in item:
            fail("pairs_refused")
        form = item["form"]
        if form not in ("value", "bare", "blank"):
            fail("representation_refused")
        key = bank_string(bank, item["k"])
        if form == "value":
            if "v" not in item:
                fail("pairs_refused")
            out.append({"key": key, "form": "value", "value": bank_string(bank, item["v"])})
        elif "v" in item:
            fail("representation_refused")
        else:
            out.append({"key": key, "form": form, "value": None if form == "bare" else ""})
    return out


def body_from(bank, rows):
    if rows is None:
        return None
    if not isinstance(rows, list):
        fail("body_refused")
    body = {}
    for field in rows:
        if not isinstance(field, dict):
            fail("body_refused")
        key = bank_string(bank, field.get("k"))
        kind = field.get("t")
        if kind == 0:
            if isinstance(field.get("v"), bool) or not isinstance(field.get("v"), (int, float)):
                fail("body_type_refused")
            body[key] = field["v"]
        elif kind == 1:
            body[key] = bank_string(bank, field.get("v"))
        elif kind == 2:
            if not isinstance(field.get("v"), bool):
                fail("body_type_refused")
            body[key] = field["v"]
        else:
            fail("body_type_refused")
    return body


def segment(spec):
    key = quote(spec["key"], safe="")
    if spec["form"] == "bare":
        return key
    if spec["form"] == "blank":
        return key + "="
    return key + "=" + quote(spec["value"], safe="")


def raw_query(specs, gap):
    parts = [segment(spec) for spec in specs]
    if gap == "between":
        if len(parts) < 2:
            fail("representation_refused")
        parts = [parts[0], ""] + parts[1:]
    elif gap is not None:
        fail("representation_refused")
    return "&".join(parts)


def decode(path):
    try:
        artifact = json.loads(Path(path).read_text())
    except (OSError, json.JSONDecodeError):
        fail("artifact_refused")
    if not isinstance(artifact, dict) or artifact.get("schema") != SCHEMA or artifact.get("license") != "CC0-1.0":
        fail("artifact_refused")
    if artifact.get("role") != "first-party-seed" or artifact.get("customerDemand") is not False or artifact.get("independentContributor") is not False:
        fail("label_refused")
    if artifact.get("codec") != "urllib.parse.quote":
        fail("artifact_refused")
    allowed = ["schema", "license", "role", "customerDemand", "independentContributor", "codec", "legend", "bank", "cases"]
    if sorted(artifact) != sorted(allowed):
        fail("artifact_refused")
    legend = artifact.get("legend")
    if not isinstance(legend, str) or "expectations, not execution" not in legend or "bare" not in legend or "blank" not in legend:
        fail("artifact_refused")
    bank = artifact.get("bank")
    if not isinstance(bank, list) or len(bank) != 22:
        fail("bank_refused")
    if bank_string(bank, 0) != "a" or bank_string(bank, 6) != "/p" or bank_string(bank, 20) != "a=1" or bank_string(bank, 21) != "":
        fail("bank_refused")
    bank = [bank_string(bank, index) for index in range(len(bank))]
    raw_cases = artifact.get("cases")
    if not isinstance(raw_cases, list) or len(raw_cases) != len(CASE_IDS):
        fail("case_shape")
    cases = []
    case_keys = {"id", "left", "right", "oldEqual", "midEqual", "nowEqual", "m", "lp", "rp", "include", "bodyL", "bodyR", "dictKey", "dictVals", "wire", "gap", "gapRight"}
    for index, item in enumerate(raw_cases):
        if not isinstance(item, dict) or item.get("id") != CASE_IDS[index] or set(item) - case_keys:
            fail("case_shape")
        if not isinstance(item.get("oldEqual"), bool) or not isinstance(item.get("midEqual"), bool) or not isinstance(item.get("nowEqual"), bool):
            fail("expectation_refused")
        wire = item.get("wire") is True
        gap = item.get("gap")
        gap_right = item.get("gapRight")
        if (gap not in (None, "between")) or (gap_right not in (None, "between")) or ((gap or gap_right) and not wire) or (wire and item.get("dictKey") is not None):
            fail("representation_refused")
        method = "GET" if item.get("m") is None else bank_string(bank, item["m"])
        left_path = bank[6] if item.get("lp") is None else bank_string(bank, item["lp"])
        right_path = left_path if item.get("rp") is None else bank_string(bank, item["rp"])
        include = None if item.get("include") is None else [bank_string(bank, slot) for slot in item["include"]]
        left_specs = [] if item.get("left") is None else specs_from(bank, item["left"])
        right_specs = [] if item.get("right") is None else specs_from(bank, item["right"])
        dict_query = None
        if item.get("dictKey") is not None:
            dict_query = {bank_string(bank, item["dictKey"]): [bank_string(bank, slot) for slot in item.get("dictVals") or []]}
        left_raw = raw_query(left_specs, gap) if wire else None
        right_raw = raw_query(right_specs, gap_right) if wire else None
        if item["id"] in RAW and (left_raw, right_raw) != RAW[item["id"]]:
            fail("wire_mismatch", id=item["id"], left=left_raw, right=right_raw)
        def side(path, specs, raw, query_form, body_rows):
            return {
                "method": method, "path": path, "specs": specs, "raw": raw, "wire": wire,
                "pairs": [[spec["key"], spec["value"]] for spec in specs],
                "queryForm": query_form, "dict": dict_query, "include": include,
                "body": body_from(bank, body_rows),
            }
        cases.append({
            "id": item["id"],
            "stored": {"oldEqual": item["oldEqual"], "midEqual": item["midEqual"], "nowEqual": item["nowEqual"], "kind": "stored-expectation"},
            "left": side(left_path, left_specs, left_raw, "pairs", item.get("bodyL")),
            "right": side(right_path, right_specs, right_raw, "dict-list" if dict_query is not None else "pairs", item.get("bodyR")),
        })
    return cases


def require_checkout(root):
    path = Path(root)
    if not path.is_dir() or not (path / "src" / "x402_nano_exact" / "consumption.py").is_file():
        fail("sdk_unavailable", path=str(root))


def head(root):
    try:
        return subprocess.check_output(["git", "-C", str(root), "rev-parse", "HEAD"], text=True).strip()
    except (subprocess.CalledProcessError, OSError):
        fail("sdk_unavailable", path=str(root))


def clean(root):
    diff = subprocess.run(
        ["git", "-C", str(root), "diff", "--exit-code", "HEAD", "--", "src/x402_nano_exact/consumption.py", "src/x402_nano_exact/middleware.py"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )
    return diff.returncode == 0


def qualify_one(root, expected):
    require_checkout(root)
    found = head(root)
    if found != expected or not clean(root):
        fail("pin_mismatch", path=str(root), head=found, expected=expected)
    return found


def load_consumption(root):
    name = "x402_nano_exact"
    for mod in list(sys.modules):
        if mod == name or mod.startswith(name + "."):
            del sys.modules[mod]
    package = types.ModuleType(name)
    package.__path__ = [str(Path(root) / "src" / name)]
    package.__package__ = name
    sys.modules[name] = package
    try:
        module = importlib.import_module(name + ".consumption")
    except ImportError:
        fail("sdk_unavailable", path=str(root))
    filename = Path(module.canonical_request_key.__code__.co_filename).resolve()
    base = Path(root).resolve()
    if base not in filename.parents or filename.name != "consumption.py":
        fail("consumer_file_mismatch", path=str(filename))
    return module


def starlette_pairs(raw):
    try:
        from starlette.datastructures import QueryParams
    except ImportError:
        fail("middleware_dependency_unavailable")
    text = raw.decode("latin-1")
    return [[key, value] for key, value in QueryParams(text).multi_items()]


def parsed_pairs(module, pin, side):
    if not side["wire"]:
        return None if side["queryForm"] == "dict-list" else side["pairs"]
    raw = side["raw"].encode("ascii")
    if pin == "after":
        if not hasattr(module, "query_pairs"):
            fail("representation_refused", pin=pin)
        return [[key, value] for key, value in module.query_pairs(raw)]
    return starlette_pairs(raw)


def call(function, side, pairs):
    kwargs = {"method": side["method"], "path": side["path"]}
    if side["queryForm"] == "dict-list" and not side["wire"]:
        kwargs["query"] = {key: list(values) for key, values in side["dict"].items()}
    elif pairs:
        kwargs["query"] = [tuple(pair) for pair in pairs]
    if side["include"]:
        kwargs["body_include"] = list(side["include"])
        kwargs["body"] = side["body"] or {}
    return function(**kwargs)


def locators():
    before, middle, after = flag("--before"), flag("--middle"), flag("--after")
    present = [item is not None for item in (before, middle, after)]
    if any(present) and not all(present):
        fail("usage")
    return before, middle, after


def run_cases():
    artifact = flag("--artifact")
    before, middle, after = locators()
    if not artifact:
        fail("usage")
    cases = decode(artifact)
    modules = None
    pins = None
    if before is not None:
        pins = {"before": qualify_one(before, BEFORE), "middle": qualify_one(middle, MIDDLE), "after": qualify_one(after, AFTER)}
        modules = {"before": load_consumption(before), "middle": load_consumption(middle), "after": load_consumption(after)}
        if not hasattr(modules["after"], "query_pairs"):
            fail("representation_refused", pin="after")
    before_loop = footprint()
    rows = []
    for item in cases:
        actual = None
        if modules is not None:
            keys = {}
            parsed = {}
            for pin, module in modules.items():
                left_pairs = parsed_pairs(module, pin, item["left"])
                right_pairs = parsed_pairs(module, pin, item["right"])
                parsed[pin] = {"left": left_pairs, "right": right_pairs}
                keys[pin] = (call(module.canonical_request_key, item["left"], left_pairs), call(module.canonical_request_key, item["right"], right_pairs))
            old_equal = keys["before"][0] == keys["before"][1]
            mid_equal = keys["middle"][0] == keys["middle"][1]
            now_equal = keys["after"][0] == keys["after"][1]
            if old_equal != item["stored"]["oldEqual"] or mid_equal != item["stored"]["midEqual"] or now_equal != item["stored"]["nowEqual"]:
                fail("expectation_mismatch", id=item["id"], oldEqual=old_equal, midEqual=mid_equal, nowEqual=now_equal, stored=item["stored"])
            actual = {
                "kind": "key-execution", "oldEqual": old_equal, "midEqual": mid_equal, "nowEqual": now_equal,
                "beforeLeft": keys["before"][0], "beforeRight": keys["before"][1],
                "middleLeft": keys["middle"][0], "middleRight": keys["middle"][1],
                "afterLeft": keys["after"][0], "afterRight": keys["after"][1], "parsed": parsed,
            }
        rows.append({
            "id": item["id"], "stored": item["stored"], "executed": modules is not None, "actual": actual,
            "leftRaw": item["left"]["raw"], "rightRaw": item["right"]["raw"],
            "leftForms": [spec["form"] for spec in item["left"]["specs"]],
            "rightForms": [spec["form"] for spec in item["right"]["specs"]],
        })
    after_loop = footprint()
    if any(item["host"] not in ("127.0.0.1", "::1") for item in attempts):
        fail("connect_attempt")
    if before_loop["childPids"] or after_loop["childPids"]:
        fail("unexpected_child")
    print(json.dumps({
        "ok": True, "schema": "cc0.query-key-cases-run.v4", "codec": "urllib.parse.quote",
        "executed": modules is not None, "cases": rows,
        "requiredPins": {"before": BEFORE, "middle": MIDDLE, "after": AFTER},
        "resolvedPins": pins, "callerPaths": {"before": before, "middle": middle, "after": after},
        "walletCalls": 0, "facilitatorCalls": 0, "liveSettlement": False, "replaySettlementFixed": False,
        "authorReportReplayed": False, "connectAttempts": attempts,
        "footprint": {"beforeLoop": before_loop, "afterLoop": after_loop},
    }, ensure_ascii=False))


def run_decode():
    artifact = flag("--artifact")
    if not artifact:
        fail("usage")
    cases = decode(artifact)
    print(json.dumps({"ok": True, "schema": SCHEMA, "cases": len(cases), "executed": False, "bank": 22}, ensure_ascii=False))


class MemoryNode:
    def __init__(self, facts):
        self.calls = []
        self.handler = 0
        self.facts = facts

    def is_cemented(self, block_hash):
        self.calls.append("is_cemented")
        return True

    def block_facts(self, block_hash):
        self.calls.append("block_facts")
        return self.facts


class MemoryStore:
    def __init__(self, concurrent):
        self.rows = {}
        self.concurrent = concurrent
        self.binds = 0

    def bind(self, row):
        self.binds += 1
        existing = self.rows.get(row.send_hash)
        if existing is not None and existing.request_key != row.request_key:
            raise self.concurrent()
        if existing is None:
            self.rows[row.send_hash] = row
        return self.rows[row.send_hash]

    def complete(self, send_hash, response_handle):
        row = self.rows[send_hash]
        row.status = "completed"
        row.response_handle = response_handle
        return row

    def resolve_unknown(self, send_hash):
        row = self.rows.get(send_hash)
        if row is not None:
            row.status = "outcome_unknown"

    def get(self, send_hash):
        return self.rows.get(send_hash)


def http_exchange(port, method, path, query, headers, payload):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    target = path if not query else path + "?" + query
    conn.request(method, target, body=payload, headers=headers or {})
    response = conn.getresponse()
    body = response.read()
    status = response.status
    conn.close()
    try:
        parsed = json.loads(body)
    except json.JSONDecodeError:
        parsed = {"raw": body.decode("utf-8", "replace")}
    return status, parsed


def http_get(port, query, headers):
    return http_exchange(port, "GET", "/p", query, headers, None)


def build_app(consumption, middleware, confirmation, body_include=None):
    from fastapi import FastAPI
    from fastapi.responses import JSONResponse
    app = FastAPI()
    node = MemoryNode(confirmation.BlockFacts(link_as_account=PAY, amount="1"))
    store = MemoryStore(consumption.ConcurrentBind)
    authority = confirmation.ConfirmationAuthority(node)
    guard = middleware.NanoConsumptionMiddleware(authority, store, body_include=body_include)

    @app.middleware("http")
    async def outer(request, call_next):
        pay = request.headers.get("x-probe-pay")
        if pay in ("nano", "other"):
            request.state.payment_payload = {"block": {"hash": request.headers.get("x-probe-hash")}}
            network = "nano:mainnet" if pay == "nano" else "other"
            request.state.payment_requirements = {"network": network, "scheme": "exact", "payTo": PAY, "amount": "1"}
        return await guard(request, call_next)

    @app.api_route("/{full_path:path}", methods=["GET"])
    async def handler(full_path: str = ""):
        node.handler += 1
        return JSONResponse({"ok": True, "path": "/" + full_path})

    return app, node, store


def start_server(app):
    import uvicorn
    config = uvicorn.Config(app, host="127.0.0.1", port=0, log_level="critical", access_log=False)
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(300):
        if server.started and server.servers:
            sockets = server.servers[0].sockets
            if sockets:
                return server, sockets[0].getsockname()[1]
        time.sleep(0.01)
    fail("consumer_failed", reason="loopback_not_ready")


def stop_server(server):
    server.should_exit = True
    for _ in range(200):
        if not server.started:
            return
        time.sleep(0.01)


def probe_steps():
    same = {
        "pass-through": {"status": [200], "replayed": [False], "handler": [1], "binds": [0], "nodeCalls": [0]},
        "other-network": {"status": [200], "replayed": [False], "handler": [1], "binds": [0], "nodeCalls": [0]},
        "pair-order": {"status": [200, 200], "replayed": [False, True], "handler": [1, 1], "binds": [1, 1], "nodeCalls": [2, 4]},
        "bare-repeat": {"status": [200, 200], "replayed": [False, True], "handler": [1, 1], "binds": [1, 1], "nodeCalls": [2, 4]},
    }
    collide = {"status": [200, 200], "replayed": [False, True], "handler": [1, 1], "binds": [1, 1], "nodeCalls": [2, 4]}
    distinct = {"status": [200, 409], "replayed": [False, False], "handler": [1, 1], "binds": [1, 1], "nodeCalls": [2, 4]}
    by_pin = {
        "bare-then-blank": {"before": collide, "middle": collide, "after": distinct},
        "encoded-delimiter": {"before": collide, "middle": distinct, "after": distinct},
        "unicode-bare-blank": {"before": collide, "middle": collide, "after": distinct},
    }
    steps = {
        "pass-through": [{"query": "a"}],
        "other-network": [{"query": "a", "pay": "other", "hash": f"{1:064x}"}],
        "bare-then-blank": [{"query": "a", "pay": "nano", "hash": f"{2:064x}"}, {"query": "a=", "pay": "nano", "hash": f"{2:064x}"}],
        "pair-order": [{"query": "b=2&a=1", "pay": "nano", "hash": f"{3:064x}"}, {"query": "a=1&b=2", "pay": "nano", "hash": f"{3:064x}"}],
        "encoded-delimiter": [{"query": "a=1%262", "pay": "nano", "hash": f"{4:064x}"}, {"query": "a=1&a=2", "pay": "nano", "hash": f"{4:064x}"}],
        "unicode-bare-blank": [{"query": "q%CE%BB", "pay": "nano", "hash": f"{5:064x}"}, {"query": "q%CE%BB=", "pay": "nano", "hash": f"{5:064x}"}],
        "bare-repeat": [{"query": "a", "pay": "nano", "hash": f"{6:064x}"}, {"query": "a", "pay": "nano", "hash": f"{6:064x}"}],
    }
    probes = []
    for name, rows in steps.items():
        expect = {pin: same[name] for pin in ("before", "middle", "after")} if name in same else by_pin[name]
        probes.append({"id": name, "steps": rows, "expect": expect})
    return probes


def run_mount():
    before, middle, after = locators()
    if before is None:
        fail("usage")
    pins = {"before": qualify_one(before, BEFORE), "middle": qualify_one(middle, MIDDLE), "after": qualify_one(after, AFTER)}
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        fail("middleware_dependency_unavailable")
    roots = {"before": before, "middle": middle, "after": after}
    observed = []
    for pin, root in roots.items():
        consumption = load_consumption(root)
        try:
            middleware = importlib.import_module("x402_nano_exact.middleware")
            confirmation = importlib.import_module("x402_nano_exact.confirmation")
        except ImportError as error:
            if "fastapi" in str(error) or "starlette" in str(error):
                fail("middleware_dependency_unavailable")
            fail("sdk_unavailable", path=str(root))
        filename = Path(middleware.NanoConsumptionMiddleware.__call__.__code__.co_filename).resolve()
        if Path(root).resolve() not in filename.parents or filename.name != "middleware.py":
            fail("consumer_file_mismatch", path=str(filename))
        app, node, store = build_app(consumption, middleware, confirmation)
        server, port = start_server(app)
        try:
            if not str(port).isdigit() or port <= 0:
                fail("consumer_failed")
            for probe in probe_steps():
                rows = []
                for step in probe["steps"]:
                    handler_before = node.handler
                    binds_before = store.binds
                    calls_before = len(node.calls)
                    headers = {}
                    if step.get("pay"):
                        headers["x-probe-pay"] = step["pay"]
                        headers["x-probe-hash"] = step["hash"]
                    status, body = http_get(port, step["query"], headers)
                    rows.append({
                        "status": status, "replayed": body.get("replayed") is True,
                        "handler": node.handler - handler_before, "binds": store.binds - binds_before,
                        "nodeCalls": len(node.calls) - calls_before, "body": body,
                    })
                expect = probe["expect"][pin]
                actual = {
                    "status": [row["status"] for row in rows],
                    "replayed": [row["replayed"] for row in rows],
                    "handler": [],
                    "binds": [],
                    "nodeCalls": [],
                }
                handler_total = binds_total = calls_total = 0
                for row in rows:
                    handler_total += row["handler"]
                    binds_total += row["binds"]
                    calls_total += row["nodeCalls"]
                    actual["handler"].append(handler_total)
                    actual["binds"].append(binds_total)
                    actual["nodeCalls"].append(calls_total)
                if actual != expect:
                    fail("expectation_mismatch", id=probe["id"], pin=pin, actual=actual, expect=expect, rows=rows)
                observed.append({"id": probe["id"], "pin": pin, "port": port, "host": "127.0.0.1", "rows": rows})
        finally:
            stop_server(server)
    if any(item["host"] not in ("127.0.0.1", "::1") for item in attempts):
        fail("connect_attempt")
    print(json.dumps({
        "ok": True, "schema": "cc0.query-key-mount.v4", "executed": True, "loopback": "127.0.0.1",
        "resolvedPins": pins, "probes": observed, "walletCalls": 0, "facilitatorCalls": 0,
        "liveSettlement": False, "replaySettlementFixed": False, "signer": False,
        "connectAttempts": attempts, "authorReportReplayed": False,
    }, ensure_ascii=False))


def read_bounded(path, code):
    try:
        raw = Path(path).read_bytes()
    except OSError:
        fail(code)
    if len(raw) > CALLER_LIMIT:
        fail(code)

    def pairs(items):
        seen = set()
        out = {}
        for key, value in items:
            if key in seen:
                raise ValueError("duplicate")
            seen.add(key)
            out[key] = value
        return out

    try:
        parsed = json.loads(raw, object_pairs_hook=pairs)
    except (json.JSONDecodeError, ValueError, TypeError):
        fail(code)
    return parsed


def plain(value, limit):
    if not isinstance(value, str) or len(value) < 1 or len(value) > limit:
        fail("caller_refused")
    if TEXT_RE.search(value) or PCT_RE.search(value):
        fail("representation_refused")
    return value


def body_value(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        if len(value) > 256 or TEXT_RE.search(value) or PCT_RE.search(value):
            fail("representation_refused")
        return value
    if isinstance(value, int) and abs(value) <= 10**15:
        return value
    if isinstance(value, float) and math.isfinite(value) and abs(value) <= 10**15:
        return value
    fail("representation_refused")


def body_object(value):
    if not isinstance(value, dict) or len(value) < 1 or len(value) > 8:
        fail("caller_refused")
    return {plain(key, 128): body_value(item) for key, item in value.items()}


def include_list(value, body):
    if not isinstance(value, list) or len(value) < 1 or len(value) > 8:
        fail("caller_refused")
    names = []
    for item in value:
        name = plain(item, 128)
        if name not in body or name in names:
            fail("caller_refused")
        names.append(name)
    return names


def pairs_of(value):
    if not isinstance(value, list) or len(value) > 16:
        fail("caller_refused")
    specs = []
    for item in value:
        if not isinstance(item, dict) or set(item) - {"key", "form", "value"} or "key" not in item or "form" not in item:
            fail("caller_refused")
        form = item["form"]
        if form not in ("bare", "blank", "value"):
            fail("representation_refused")
        key = plain(item["key"], 128)
        if form == "value":
            if "value" not in item or not isinstance(item["value"], str) or item["value"] == "":
                fail("representation_refused")
            held = item["value"]
            if len(held) > 256 or TEXT_RE.search(held) or PCT_RE.search(held):
                fail("representation_refused")
            specs.append({"key": key, "form": "value", "value": held})
        elif "value" in item:
            fail("representation_refused")
        else:
            specs.append({"key": key, "form": form, "value": None if form == "bare" else ""})
    return specs


def side_of(value):
    if not isinstance(value, dict) or set(value) - {"method", "path", "pairs", "body", "bodyInclude"}:
        fail("caller_refused")
    if "method" not in value or "path" not in value or "pairs" not in value:
        fail("caller_refused")
    path = plain(value["path"], 256)
    if not path.startswith("/"):
        fail("caller_refused")
    has_body = "body" in value
    has_include = "bodyInclude" in value
    if has_body != has_include:
        fail("caller_refused")
    body = body_object(value["body"]) if has_body else None
    include = include_list(value["bodyInclude"], body) if has_include else None
    specs = pairs_of(value["pairs"])
    return {
        "method": plain(value["method"], 32), "path": path, "specs": specs,
        "raw": raw_query(specs, None), "body": body, "bodyInclude": include,
    }


def expect_of(value):
    if value is None:
        return None
    keys = {"oldEqual", "midEqual", "nowEqual"}
    if not isinstance(value, dict) or set(value) != keys:
        fail("caller_refused")
    for key in keys:
        if not isinstance(value[key], bool):
            fail("caller_refused")
    return {key: value[key] for key in ("oldEqual", "midEqual", "nowEqual")}


def read_caller(path):
    parsed = read_bounded(path, "caller_refused")
    if not isinstance(parsed, dict) or parsed.get("schema") != CALLER_SCHEMA:
        fail("caller_refused")
    if set(parsed) - {"schema", "left", "right", "expect"} or "left" not in parsed or "right" not in parsed:
        fail("caller_refused")
    return {"left": side_of(parsed["left"]), "right": side_of(parsed["right"]), "expect": expect_of(parsed.get("expect"))}


def public_side(side):
    pairs = []
    for spec in side["specs"]:
        row = {"key": spec["key"], "form": spec["form"]}
        if spec["form"] == "value":
            row["value"] = spec["value"]
        pairs.append(row)
    out = {"method": side["method"], "path": side["path"], "pairs": pairs, "raw": side["raw"]}
    if side["body"] is not None:
        out["body"] = side["body"]
        out["bodyInclude"] = side["bodyInclude"]
    return out


def caller_pairs(module, pin, side):
    raw = side["raw"].encode("ascii")
    if pin == "after":
        if not hasattr(module, "query_pairs"):
            fail("representation_refused", pin=pin)
        return [[key, value] for key, value in module.query_pairs(raw)]
    return starlette_pairs(raw)


def call_side(function, side, pairs):
    kwargs = {"method": side["method"], "path": side["path"]}
    if pairs:
        kwargs["query"] = [tuple(pair) for pair in pairs]
    if side["bodyInclude"]:
        kwargs["body_include"] = list(side["bodyInclude"])
        kwargs["body"] = side["body"]
    return function(**kwargs)


def check_mount_shape(caller):
    includes = []
    for side in (caller["left"], caller["right"]):
        if side["method"].upper() != "GET":
            fail("representation_refused", reason="mount_method")
        if any(char in side["path"] for char in " ?#"):
            fail("representation_refused", reason="mount_path")
        includes.append(side["bodyInclude"])
    if includes[0] != includes[1]:
        fail("representation_refused", reason="mount_body")
    return includes[0]


def mount_caller(roots, caller, equal_by_pin):
    try:
        import fastapi  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        fail("middleware_dependency_unavailable")
    body_include = caller["left"]["bodyInclude"]
    observed = []
    for pin, root in roots.items():
        consumption = load_consumption(root)
        try:
            middleware = importlib.import_module("x402_nano_exact.middleware")
            confirmation = importlib.import_module("x402_nano_exact.confirmation")
        except ImportError as error:
            if "fastapi" in str(error) or "starlette" in str(error):
                fail("middleware_dependency_unavailable")
            fail("sdk_unavailable", path=str(root))
        filename = Path(middleware.NanoConsumptionMiddleware.__call__.__code__.co_filename).resolve()
        if Path(root).resolve() not in filename.parents or filename.name != "middleware.py":
            fail("consumer_file_mismatch", path=str(filename))
        app, node, store = build_app(consumption, middleware, confirmation, body_include)
        server, port = start_server(app)
        try:
            rows = []
            for side in (caller["left"], caller["right"]):
                handler_before = node.handler
                binds_before = store.binds
                calls_before = len(node.calls)
                headers = {"x-probe-pay": "nano", "x-probe-hash": f"{42:064x}"}
                payload = None
                if side["body"] is not None:
                    payload = json.dumps(side["body"], sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
                    headers["Content-Type"] = "application/json"
                status, body = http_exchange(port, "GET", quote(side["path"], safe="/"), side["raw"] or None, headers, payload)
                rows.append({
                    "status": status, "replayed": body.get("replayed") is True,
                    "handler": node.handler - handler_before, "binds": store.binds - binds_before,
                    "nodeCalls": len(node.calls) - calls_before, "body": body,
                })
            same = equal_by_pin[pin]
            expected_status = [200, 200] if same else [200, 409]
            expected_replayed = [False, True] if same else [False, False]
            actual_status = [row["status"] for row in rows]
            actual_replayed = [row["replayed"] for row in rows]
            if actual_status != expected_status or actual_replayed != expected_replayed:
                fail("consumer_failed", reason="mount_key_disagreement", pin=pin, equal=same, status=actual_status, replayed=actual_replayed)
            observed.append({"pin": pin, "host": "127.0.0.1", "port": port, "rows": rows})
        finally:
            stop_server(server)
    return {"schema": "cc0.query-key-caller-mount.v4", "loopback": "127.0.0.1", "signer": False, "probes": observed}


def run_apply():
    artifact = flag("--artifact")
    source = flag("--input")
    before, middle, after = locators()
    mount = switched("--mount")
    if not artifact or not source:
        fail("usage")
    if mount and before is None:
        fail("usage")
    decode(artifact)
    caller = read_caller(source)
    if mount:
        check_mount_shape(caller)
    modules = None
    pins = None
    if before is not None:
        pins = {"before": qualify_one(before, BEFORE), "middle": qualify_one(middle, MIDDLE), "after": qualify_one(after, AFTER)}
        modules = {"before": load_consumption(before), "middle": load_consumption(middle), "after": load_consumption(after)}
        if not hasattr(modules["after"], "query_pairs"):
            fail("representation_refused", pin="after")
    before_loop = footprint()
    actual = None
    if modules is not None:
        keys = {}
        parsed = {}
        for pin, module in modules.items():
            left_pairs = caller_pairs(module, pin, caller["left"])
            right_pairs = caller_pairs(module, pin, caller["right"])
            parsed[pin] = {"left": left_pairs, "right": right_pairs}
            keys[pin] = (
                call_side(module.canonical_request_key, caller["left"], left_pairs),
                call_side(module.canonical_request_key, caller["right"], right_pairs),
            )
        old_equal = keys["before"][0] == keys["before"][1]
        mid_equal = keys["middle"][0] == keys["middle"][1]
        now_equal = keys["after"][0] == keys["after"][1]
        if caller["expect"] is not None and (
            old_equal != caller["expect"]["oldEqual"] or mid_equal != caller["expect"]["midEqual"] or now_equal != caller["expect"]["nowEqual"]
        ):
            fail(
                "expectation_mismatch", oldEqual=old_equal, midEqual=mid_equal, nowEqual=now_equal,
                beforeLeft=keys["before"][0], beforeRight=keys["before"][1],
                middleLeft=keys["middle"][0], middleRight=keys["middle"][1],
                afterLeft=keys["after"][0], afterRight=keys["after"][1],
            )
        actual = {
            "kind": "key-execution", "oldEqual": old_equal, "midEqual": mid_equal, "nowEqual": now_equal,
            "beforeLeft": keys["before"][0], "beforeRight": keys["before"][1],
            "middleLeft": keys["middle"][0], "middleRight": keys["middle"][1],
            "afterLeft": keys["after"][0], "afterRight": keys["after"][1], "parsed": parsed,
        }
    after_loop = footprint()
    if before_loop["childPids"] or after_loop["childPids"]:
        fail("unexpected_child")
    mounted = None
    if mount:
        mounted = mount_caller(
            {"before": before, "middle": middle, "after": after},
            caller,
            {"before": actual["oldEqual"], "middle": actual["midEqual"], "after": actual["nowEqual"]},
        )
    if any(item["host"] not in ("127.0.0.1", "::1") for item in attempts):
        fail("connect_attempt")
    print(json.dumps({
        "ok": True, "schema": "cc0.query-key-caller-run.v4", "codec": "urllib.parse.quote",
        "executed": modules is not None, "actual": actual,
        "wire": {"kind": "codec", "left": caller["left"]["raw"], "right": caller["right"]["raw"], "execution": modules is not None},
        "input": {"left": public_side(caller["left"]), "right": public_side(caller["right"])},
        "expectationChecked": modules is not None and caller["expect"] is not None,
        "mount": mounted,
        "requiredPins": {"before": BEFORE, "middle": MIDDLE, "after": AFTER},
        "resolvedPins": pins, "callerPaths": {"before": before, "middle": middle, "after": after},
        "walletCalls": 0, "facilitatorCalls": 0, "liveSettlement": False, "replaySettlementFixed": False,
        "signer": False, "authorReportReplayed": False, "connectAttempts": attempts,
        "footprint": {"beforeLoop": before_loop, "afterLoop": after_loop},
    }, ensure_ascii=False))


def main():
    install_socket_guard()
    command = sys.argv[1] if len(sys.argv) > 1 else None
    if command == "cases":
        run_cases()
    elif command == "decode":
        run_decode()
    elif command == "mount":
        run_mount()
    elif command == "apply":
        run_apply()
    else:
        fail("usage")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        fail("consumer_failed")
