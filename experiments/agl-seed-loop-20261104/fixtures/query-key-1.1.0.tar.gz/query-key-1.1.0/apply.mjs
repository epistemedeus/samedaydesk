#!/usr/bin/env node
// Cold command surface for the 1.1.0 archive. One Python process does the work.
import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {dirname, join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {assertCorpus} from './contract.mjs';

const here = dirname(fileURLToPath(import.meta.url));

function emit(payload, status) {
  process.stdout.write(JSON.stringify(payload) + '\n');
  process.exit(status);
}

function artifactPath(argv) {
  const index = argv.indexOf('--artifact');
  if (index < 0) return null;
  return argv[index + 1] || '';
}

const argv = process.argv.slice(2);
const command = argv[0];
if (!['decode', 'cases', 'mount', 'apply'].includes(command)) emit({ok: false, code: 'usage'}, 1);
const artifact = artifactPath(argv);
if (command === 'apply') {
  const inputAt = argv.indexOf('--input');
  if (inputAt < 0 || !argv[inputAt + 1] || argv[inputAt + 1].startsWith('--')) emit({ok: false, code: 'usage'}, 1);
}
if (command !== 'mount') {
  if (!artifact) emit({ok: false, code: 'usage'}, 1);
  let parsed;
  try { parsed = JSON.parse(readFileSync(artifact, 'utf8')); }
  catch { emit({ok: false, code: 'artifact_refused'}, 1); }
  try { assertCorpus(parsed); }
  catch (error) { emit({ok: false, code: error.code || 'artifact_refused'}, 1); }
}
const child = spawnSync('python3', [join(here, 'execute.py'), ...argv], {encoding: 'utf8'});
if (child.error) emit({ok: false, code: 'sdk_unavailable', reason: 'python3'}, 1);
if (child.stdout) process.stdout.write(child.stdout);
if (child.stderr) process.stderr.write(child.stderr);
process.exit(child.status === null ? 1 : child.status);
