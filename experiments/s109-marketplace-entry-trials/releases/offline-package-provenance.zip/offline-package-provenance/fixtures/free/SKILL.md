skill recipe free
