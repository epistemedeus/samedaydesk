acceptance report packaging
