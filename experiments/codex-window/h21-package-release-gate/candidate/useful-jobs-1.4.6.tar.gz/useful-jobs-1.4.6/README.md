# useful-jobs 1.4.4

Offline wrappers. Four engine sources (lockfile, JSON Schema webhook drift, route-table
diff, page-change) plus the original six PR51 jobs. Run locally on your own files.
No purchase authority, no hosted extract, no scheduler daemon, no paid HTTP endpoint.

## Requirements

- Node.js 22 or newer
- Offline local filesystem access to your inputs
- Acquire tools (download/verify/extract only): bash, curl, python3, tar, mktemp

## Install (offline)

From the 1.4.4 release archive (after you unpack it):

```bash
cd useful-jobs-1.4.4
node -v   # expect v22+
node bin/useful-jobs.mjs list
node bin/useful-jobs.mjs version
```

Download path: `/for-agents/useful-jobs/useful-jobs-1.4.4.tar.gz`
(kit mirror `/kit/useful-jobs-1.4.4.tar.gz`). Verify size and sha256 from
`useful-jobs-1.4.4.sha256.json` before extract.

Previous version 1.3.0 remains at `/for-agents/useful-jobs/useful-jobs-1.3.0.tar.gz`
(2574904 bytes, sha256 `bc4db0ec83109852b8fdbd542d10d515c0053a30dd9b93836c9ad7c738510b6c`).
Previous version 1.2.0 remains at `/for-agents/useful-jobs/useful-jobs-1.2.0.tar.gz`
(2579117 bytes, sha256 `dec31ea66f1605fb9578c7d15c9583b130c6e2c0b82b5e6b93422381a04461eb`).
Previous version 1.1.0 remains at `/for-agents/useful-jobs/useful-jobs-1.1.0.tar.gz`
(2577606 bytes, sha256 `de8ebee19ffd5d9019fa7988291fe37d861e7bf3f5ee7dd341c9d2f0f0065534`).
Previous version 1.0.0 remains at `/for-agents/useful-jobs/useful-jobs-1.0.0.tar.gz`
(2522418 bytes, sha256 `6bf650391fad4fa658a7959e9717fc5499faf4caffa0a39f67c6c2ee033bdb51`).

Pinned nested archives under `vendor-pins/` are verified by sha256/size before
the six PR51 jobs run. Exact pins are in `vendor-pins/PIN.json`.

## List jobs

```bash
node bin/useful-jobs.mjs list
node bin/useful-jobs.mjs list --json
node bin/useful-jobs.mjs help lockfile-pin-delta
```

## Run a job

Caller mode requires semantic inputs. Missing inputs refuse closed. Labeled
samples require an explicit `--example` flag except page-change, which refuses
`--example` (`sample_as_delivered_watch`).

```bash
# Labeled sample (not a customer run)
node bin/useful-jobs.mjs run lockfile-pin-delta --example
node bin/useful-jobs.mjs run json-schema-webhook-drift --example
node bin/useful-jobs.mjs run route-table-diff --example --out-dir ./out/route-example

# H04 public lockfile excerpt (caller files, not --example)
node bin/useful-jobs.mjs run lockfile-pin-delta \
  --before ./samples/lockfile/h04-pub-lock-01/before.json \
  --after ./samples/lockfile/h04-pub-lock-01/after.json \
  --out-dir ./out/h04-lock

# Held page-change job (no --example)
node bin/useful-jobs.mjs run page-change-offline-job \
  --job ./samples/page/h04-page-01/job.json \
  --out-dir ./out/h04-page

# Original six (unchanged)
node bin/useful-jobs.mjs run api-upgrade-brief --example
```

Default outputs for the six PR51 jobs land in `out/<job>/` when `--out-dir`
is omitted. `route-table-diff` and `page-change-offline-job` require `--out-dir`.

## The ten jobs

| Job id | Required inputs | Outputs | --example |
| --- | --- | --- | --- |
| `lockfile-pin-delta` | `--before --after` | `pin-delta.{json,md}` | labeled SAMPLE |
| `json-schema-webhook-drift` | `--before --after --used` | `drift-brief.{json,md}` | labeled SAMPLE |
| `route-table-diff` | `--before --after --out-dir` | `route-diff.{json,md}` | labeled SAMPLE |
| `page-change-offline-job` | `--job --out-dir` | `page-change.{json,md}` | refused |
| `api-upgrade-brief` | `--before --after --used` | `upgrade-brief.{json,md}` | labeled SAMPLE |
| `vendor-budget-impact` | `--before --after` | `budget-impact.{json,md}` | labeled SAMPLE |
| `feed-agenda` | `--before --after` | `agenda.{json,ics}` | labeled SAMPLE |
| `evidence-ci-annotation` | `--input` | `annotations.{json,md}` | labeled SAMPLE |
| `listing-repair-packet` | `--input` | `repair-packet.{json,md}` | labeled SAMPLE |
| `repeat-job-record` | `--next-run` | `repeat-job.{json,md}` | labeled SAMPLE |

Machine catalog: `catalog.json`. Concrete job outcomes: `jobs-outcomes.json`.
Per-job caller guides: `apps/<job>/CALLER.md`.

H04 public inputs (pin `37dd4b42cf21dc2031715971971bb2426a7beb80`) are copied
under `samples/`. This archive does not require a sibling H04 tree or a private Git clone.

## Honesty rules

- Samples under `samples/` and `--example` are labeled fixtures, not customers.
- `page-change-offline-job --example` is refused. Use a held extract-batch job document.
- Evidence CI annotations from caller-supplied packets stay **unattested**.
- Vendor conflicting/unknown evidence stays **partial**.
- Incomplete listing capture stays **partial** for every `identity.provider`, including unknown names.
- A declared listing provider other than `grexal|agensi` is **refused** (`unsupported-provider`) when capture is complete. Engine `ok:true` is not actionable evidence.
- Lockfile equality is npm `package-lock.json` fields only.
- This package is a local execution kit. It does not publish a paid HTTP merchant route.
- No purchase, network, or background scheduler authority.

## Tests

The packaged `npm test` suite is the 1.0.0 regression for the six PR51 jobs.
Public 1.4.4 cold-prefix checks live in the SameDayDesk tree
(`npm run test:useful-jobs-public`).

## License

Pilot-authored wrappers and samples: MIT (`LICENSE`). Nested vendor archives
keep their original licenses (`NOTICE`, `licenses/vendor/`). Engine
`page-change-offline-job` is UNLICENSED SDS (`NOTICE.md`); I01 hash-terms
hasher is MIT.

## 1.4.4 pricing-row qualification

Compare caller-supplied pricing snapshots for added, removed, changed and incomparable-unit rows. Not a bill calculator or live quote. Supply dated snapshots with stable field identity and matching units. Added/removed rows describe snapshot coverage, not confirmed SKU launches/retirements. Same-unit numeric deltas are per listed unit, not savings. No usage, free-tier, tax, tariff or currency conversion.

Previous 1.4.0 remains byte-identical at /for-agents/useful-jobs/useful-jobs-1.4.0.tar.gz.

## 1.4.4 pinned engine repairs

JSON Schema selected required-keyword membership, supported instance-set semantics, HTTP-witness-safe explicit Express 5 subset, lockfile semantics and bounded offline page facts. Pricing-row scope remains unchanged. This is an offline analysis kit, not a runtime compatibility guarantee. Engine source commit and complete copied-file hashes are recorded in the release pin.

Versions 1.0.0 through 1.4.1 remain byte-identical.

## 1.4.4 temporary vendor lifecycle

Vendor extracts are reused within the calling process and removed on normal exit, extraction failure, SIGINT, and SIGTERM. Explicit cleanup is idempotent. Existing engines and pricing scope are unchanged. A SIGKILL or host failure can still leave scratch for an owner-verified cleanup. Versions 1.0.0 through 1.4.2 remain byte-identical.

## 1.4.4 SDS wrapper overlay

This archive keeps the 1.4.3 kit CLI, engines, and `lib/common.mjs` vendor scratch lifecycle.
It also ships the in-tree SDS execution.v1 wrapper and managed-order interrupt path at their
repo-relative locations (`server/paid-useful-jobs/lib/wrapper.mjs`, `tools/managed-useful-jobs-order/lib/create-order.mjs`).
Those files include publication rollback (`rollback-incomplete`) and `interrupted-incomplete`.
Vendor-budget-impact identity still extracts nested useful-jobs 1.0.0 (`6bf65039…`, 2522418 bytes).
Do not re-nest useful-jobs-1.4.3.tar.gz. Version 1.4.3 remains byte-identical at
`/for-agents/useful-jobs/useful-jobs-1.4.3.tar.gz` (2615491 bytes, sha256 `a18ab918…`).
Extracted Postgres `import 'pg'` is a host driver; this package does not vendor `node_modules`.
No live fetch or purchase authority.

## 1.4.5 packaged engine layout and Postgres driver declaration

Selected M01 engines advertised by SDS execution.v1 resolve from packaged `engines/<id>`
using the same `cli.relativeBin` as in-tree `tools/<id>`. That is general layout resolution,
not a per-job alias. Git fetch is not a packaged-runtime acquisition path.
Optional Postgres store: from the extract run
`cd tools/managed-useful-jobs-order && npm install --omit=dev --no-fund --no-audit`
to install declared `pg` 8.23.0 for host postgresql-16. The archive does not contain `node_modules`.
Versions 1.4.4 (`ff493409…`) and 1.4.3 (`a18ab918…`) remain byte-identical.
No live fetch or purchase authority.

## H21 1.4.6 review candidate — release gate incomplete

Public M01 and vendor-budget-impact commands now use the packaged SDS publication rollback helper. Explicit output directories preserve caller files on handled publication failure and release scratch directories. Publication is not crash-atomic. No hosted artifact retrieval or payment authority is added.
For the optional Postgres driver: `cd tools/managed-useful-jobs-order && npm ci --omit=dev --no-fund --no-audit`.
