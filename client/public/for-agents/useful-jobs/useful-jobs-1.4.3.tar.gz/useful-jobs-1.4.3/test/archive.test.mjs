import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import http from "node:http";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { ROOT, assertArchivePins, readJson } from "../lib/common.mjs";

const PKG = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
const STAGE = `${PKG.name}-${PKG.version}`;
const ARCHIVE = path.join(ROOT, "dist", `${STAGE}.tar.gz`);
const PIN = path.join(ROOT, "dist", `${STAGE}.sha256.json`);

function ensureArchive() {
  const build = spawnSync(process.execPath, [path.join(ROOT, "scripts/build-archive.mjs")], {
    encoding: "utf8",
    cwd: ROOT,
    timeout: 120000,
  });
  assert.equal(build.status, 0, `build-archive failed: ${build.stderr || build.stdout}`);
  assert.ok(fs.existsSync(ARCHIVE), "archive missing after build");
  assert.ok(fs.existsSync(PIN), "pin missing after build");
}

function listenArchive(buf, name) {
  return new Promise((resolve, reject) => {
    const server = http.createServer((req, res) => {
      if (req.url === `/${name}` || req.url === "/") {
        res.writeHead(200, {
          "content-type": "application/gzip",
          "content-length": buf.length,
        });
        res.end(buf);
        return;
      }
      res.writeHead(404);
      res.end("not found");
    });
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      resolve({ server, port, url: `http://127.0.0.1:${port}/${name}` });
    });
    server.on("error", reject);
  });
}

function httpGetFile(url, dest) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, { timeout: 5000 }, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        reject(new Error(`status ${res.statusCode}`));
        return;
      }
      const chunks = [];
      res.on("data", (c) => chunks.push(c));
      res.on("end", () => {
        const body = Buffer.concat(chunks);
        fs.writeFileSync(dest, body);
        resolve(body);
      });
    });
    req.on("error", reject);
    req.on("timeout", () => {
      req.destroy();
      reject(new Error("timeout"));
    });
  });
}

test("nested vendor pins verify before any extract/pack", () => {
  assert.doesNotThrow(() => assertArchivePins());
});

test("release archive builds with allowlist only and matching sha/bytes", () => {
  ensureArchive();
  const pin = readJson(PIN);
  const buf = fs.readFileSync(ARCHIVE);
  assert.equal(buf.length, pin.bytes);
  assert.equal(createHash("sha256").update(buf).digest("hex"), pin.sha256);
  assert.equal(pin.nestedPinsVerified, true);

  const list = spawnSync("tar", ["-tzf", ARCHIVE], { encoding: "utf8" });
  assert.equal(list.status, 0);
  const names = list.stdout.split("\n").filter(Boolean);
  assert.ok(names.some((n) => n.includes("bin/useful-jobs.mjs")));
  assert.ok(names.some((n) => n.includes("catalog.json")));
  assert.ok(names.some((n) => n.includes("jobs-outcomes.json")));
  assert.ok(names.some((n) => n.includes("LICENSE")));
  assert.ok(names.some((n) => n.includes("NOTICE")));
  assert.ok(!names.some((n) => n.includes("/receipts/")));
  assert.ok(!names.some((n) => /RESULT/i.test(path.basename(n))));
  assert.ok(!names.some((n) => n.includes("DESIGN.md")));
});

test("fresh HTTP acquire + unpack + list (documented next command)", async () => {
  ensureArchive();
  const pin = readJson(PIN);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), "uj-http-acquire-"));
  const name = path.basename(ARCHIVE);
  const buf = fs.readFileSync(ARCHIVE);
  const { server, url } = await listenArchive(buf, name);
  try {
    const bad = await httpGetFile(`http://127.0.0.1:${server.address().port}/missing.bin`, path.join(work, "bad.bin")).then(
      () => null,
      (e) => e,
    );
    assert.ok(bad, "missing download must fail");

    const dest = path.join(work, name);
    const got = await httpGetFile(url, dest);
    assert.equal(got.length, pin.bytes);
    assert.equal(createHash("sha256").update(got).digest("hex"), pin.sha256);

    const untar = spawnSync("tar", ["-xzf", dest, "-C", work], { encoding: "utf8" });
    assert.equal(untar.status, 0);
    const pkgDir = path.join(work, STAGE);
    assert.ok(fs.existsSync(path.join(pkgDir, "bin/useful-jobs.mjs")));
    const list = spawnSync(process.execPath, ["bin/useful-jobs.mjs", "list"], {
      encoding: "utf8",
      cwd: pkgDir,
    });
    assert.equal(list.status, 0, list.stderr);
    assert.match(list.stdout, /api-upgrade-brief/);
    assert.match(list.stdout, /repeat-job-record/);
    const unpackedPkg = JSON.parse(fs.readFileSync(path.join(pkgDir, "package.json"), "utf8"));
    assert.equal(unpackedPkg.name, "useful-jobs");
  } finally {
    await new Promise((r) => server.close(r));
  }
});

test("sh/bash acquire script fail-closed on missing args", () => {
  const r = spawnSync("bash", [path.join(ROOT, "scripts/acquire-accept.sh")], { encoding: "utf8" });
  assert.equal(r.status, 2);
});
