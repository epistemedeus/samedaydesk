import test from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import fs from "node:fs";
import os from "node:os";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { ROOT, assertArchivePins, fixture, writeJson, readJson } from "../lib/common.mjs";
import { buildImpact } from "../apps/vendor-budget-impact/cli.mjs";
import { buildRepeatRecord } from "../apps/repeat-job-record/cli.mjs";
import { validateNextRunManifest } from "../lib/validate-next-run.mjs";
import { validateEvidencePacket } from "../lib/validate-evidence.mjs";

function run(rel, args, { expectStatus = 0 } = {}) {
  const r = spawnSync(process.execPath, [path.join(ROOT, rel), ...args], {
    encoding: "utf8",
    timeout: 120000,
    cwd: fs.mkdtempSync(path.join(os.tmpdir(), "s242-cwd-")),
  });
  if (expectStatus === 0) {
    assert.equal(r.status, 0, `${rel} failed: ${r.stderr || r.stdout}`);
    return JSON.parse(r.stdout.trim());
  }
  assert.equal(r.status, expectStatus, `${rel} expected ${expectStatus}: ${r.stdout}`);
  return JSON.parse(r.stdout.trim());
}

test("archive and kit pins match released bytes/sha256", () => {
  assert.doesNotThrow(() => assertArchivePins());
});

test("no-args refuses for all six apps", () => {
  const apps = [
    "apps/api-upgrade-brief/cli.mjs",
    "apps/vendor-budget-impact/cli.mjs",
    "apps/feed-agenda/cli.mjs",
    "apps/evidence-ci-annotation/cli.mjs",
    "apps/listing-repair-packet/cli.mjs",
    "apps/repeat-job-record/cli.mjs",
  ];
  for (const rel of apps) {
    const out = run(rel, [], { expectStatus: 2 });
    assert.equal(out.ok, false);
    assert.equal(out.code, "missing-required-inputs");
  }
});

test("explicit --example mode labels samples for all six apps", () => {
  const apps = [
    ["apps/api-upgrade-brief/cli.mjs", "upgrade-brief.json"],
    ["apps/vendor-budget-impact/cli.mjs", "budget-impact.json"],
    ["apps/feed-agenda/cli.mjs", "agenda.json"],
    ["apps/evidence-ci-annotation/cli.mjs", "annotations.json"],
    ["apps/listing-repair-packet/cli.mjs", "repair-packet.json"],
    ["apps/repeat-job-record/cli.mjs", "repeat-job.json"],
  ];
  for (const [rel, artName] of apps) {
    const out = run(rel, ["--example"]);
    assert.equal(out.ok, true);
    assert.ok(out.outDir);
    const art = readJson(path.join(out.outDir, artName));
    assert.equal(art.caller.sampleLabel, "explicit-example");
    assert.equal(art.caller.exampleMode, true);
  }
});

test("api-upgrade-brief two distinct callers + collision-safe default outs", () => {
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), "s242-api-cwd-"));
  const a = spawnSync(
    process.execPath,
    [
      path.join(ROOT, "apps/api-upgrade-brief/cli.mjs"),
      "--before",
      fixture("openapi/a/before.yaml"),
      "--after",
      fixture("openapi/a/after.yaml"),
      "--used",
      fixture("openapi/a/used.json"),
    ],
    { encoding: "utf8", cwd, timeout: 120000 },
  );
  const b = spawnSync(
    process.execPath,
    [
      path.join(ROOT, "apps/api-upgrade-brief/cli.mjs"),
      "--before",
      fixture("openapi/b/before.yaml"),
      "--after",
      fixture("openapi/b/after.yaml"),
      "--used",
      fixture("openapi/b/used.json"),
    ],
    { encoding: "utf8", cwd, timeout: 120000 },
  );
  assert.equal(a.status, 0, a.stderr || a.stdout);
  assert.equal(b.status, 0, b.stderr || b.stdout);
  const ja = JSON.parse(a.stdout.trim());
  const jb = JSON.parse(b.stdout.trim());
  assert.notEqual(ja.outDir, jb.outDir);
  assert.notEqual(ja.digest, jb.digest);
  assert.ok(fs.existsSync(path.join(ja.outDir, "upgrade-brief.md")));
  assert.ok(fs.existsSync(path.join(jb.outDir, "upgrade-brief.md")));
});

test("vendor-budget-impact conflicting/unknown-only stay partial", () => {
  const conflicting = buildImpact(
    {
      ok: true,
      report: {
        counts: { conflicting: 1, unknown: 0, fieldChanges: 0, unitChanges: 0, added: 0, removed: 0 },
        unitChanges: [],
        fieldChanges: [],
      },
    },
    { sampleLabel: "unit" },
  );
  const unknown = buildImpact(
    {
      ok: true,
      report: {
        counts: { conflicting: 0, unknown: 2, fieldChanges: 0, unitChanges: 0, added: 0, removed: 0 },
        unitChanges: [],
        fieldChanges: [],
      },
    },
    { sampleLabel: "unit" },
  );
  assert.equal(conflicting.status, "partial");
  assert.equal(unknown.status, "partial");
  const outA = fs.mkdtempSync(path.join(os.tmpdir(), "s242-bud-a-"));
  const outB = fs.mkdtempSync(path.join(os.tmpdir(), "s242-bud-b-"));
  const a = run("apps/vendor-budget-impact/cli.mjs", [
    "--before",
    fixture("pricing/a/before.json"),
    "--after",
    fixture("pricing/a/after.json"),
    "--out-dir",
    outA,
  ]);
  const b = run("apps/vendor-budget-impact/cli.mjs", [
    "--before",
    fixture("pricing/b/before.json"),
    "--after",
    fixture("pricing/b/after.json"),
    "--out-dir",
    outB,
  ]);
  assert.equal(a.purchaseAuthority, false);
  assert.notEqual(a.digest, b.digest);
});

test("feed-agenda two callers differ", () => {
  const outA = fs.mkdtempSync(path.join(os.tmpdir(), "s242-ag-a-"));
  const outB = fs.mkdtempSync(path.join(os.tmpdir(), "s242-ag-b-"));
  const a = run("apps/feed-agenda/cli.mjs", [
    "--before",
    fixture("feed/a/before.xml"),
    "--after",
    fixture("feed/a/after.xml"),
    "--out-dir",
    outA,
  ]);
  const b = run("apps/feed-agenda/cli.mjs", [
    "--before",
    fixture("feed/b/before.xml"),
    "--after",
    fixture("feed/b/after.xml"),
    "--out-dir",
    outB,
  ]);
  assert.ok(fs.existsSync(path.join(outA, "agenda.ics")));
  assert.notEqual(a.digest, b.digest);
});

test("evidence refuses forged thin JSON; schema-valid pass stays unattested/informational", async () => {
  await assert.rejects(
    () => validateEvidencePacket({ status: "pass", jobId: "fake" }),
    (err) => err.code === "unsupported-evidence-schema",
  );
  const forgedDir = fs.mkdtempSync(path.join(os.tmpdir(), "s242-ev-forge-"));
  const forged = path.join(forgedDir, "forged.json");
  writeJson(forged, { status: "pass", jobId: "fake" });
  const refused = run("apps/evidence-ci-annotation/cli.mjs", ["--input", forged], { expectStatus: 2 });
  assert.equal(refused.ok, false);
  assert.equal(refused.code, "unsupported-evidence-schema");

  const outP = fs.mkdtempSync(path.join(os.tmpdir(), "s242-ev-p-"));
  const outR = fs.mkdtempSync(path.join(os.tmpdir(), "s242-ev-r-"));
  const pass = run("apps/evidence-ci-annotation/cli.mjs", [
    "--input",
    fixture("evidence/caller-a.json"),
    "--out-dir",
    outP,
  ]);
  const fail = run("apps/evidence-ci-annotation/cli.mjs", [
    "--input",
    fixture("evidence/refused.json"),
    "--out-dir",
    outR,
  ]);
  // Hand-authored fully schema-valid pass remains visibly untrusted.
  assert.equal(pass.status, "informational");
  assert.equal(pass.trust, "unattested");
  assert.equal(pass.authority, false);
  assert.equal(fail.status, "refused");
  const art = readJson(path.join(outP, "annotations.json"));
  assert.equal(art.status, "informational");
  assert.equal(art.trust, "unattested");
  assert.equal(art.authority, false);
  assert.equal(art.underlying.kitProduced, false);
  assert.equal(art.underlying.externallyAttested, false);
  assert.equal(art.underlying.authority, false);
  assert.match(String(art.underlying.provenanceKind), /unattested|caller-supplied/);
  assert.equal(art.underlying.schema, "s137.consumer-evidence.packet.v1");
  assert.ok(art.underlying.formatReference);
  assert.notEqual(art.underlying.formatReference, undefined);
  // Useful CI annotations still emitted without trusted action.
  assert.ok((art.githubCheckAnnotations || []).length >= 1);
  const md = fs.readFileSync(path.join(outP, "annotations.md"), "utf8");
  assert.match(md, /unattested/i);
  assert.match(md, /Authority: \*\*false\*\*/);
});

test("listing-repair-packet partial stays non-global", () => {
  const out = fs.mkdtempSync(path.join(os.tmpdir(), "s242-list-p-"));
  const r = run("apps/listing-repair-packet/cli.mjs", [
    "--input",
    fixture("listing/partial.json"),
    "--out-dir",
    out,
  ]);
  assert.equal(r.status, "partial");
  const art = readJson(path.join(out, "repair-packet.json"));
  assert.ok(art.gaps.length > 0);
});

test("repeat-job-record verifies local bytes; byte change at same path is detected", async () => {
  await assert.rejects(
    () => validateNextRunManifest({ family: "x" }),
    (err) => err.code === "unsupported-next-run-schema",
  );
  const forgedDir = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-forge-"));
  const forged = path.join(forgedDir, "forged.json");
  writeJson(forged, { family: "x" });
  const refused = run("apps/repeat-job-record/cli.mjs", ["--next-run", forged], { expectStatus: 2 });
  assert.equal(refused.code, "unsupported-next-run-schema");

  // Workspace: copy manifest + inputs; change ONLY file bytes, not hash strings.
  const work = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-bytes-"));
  const before = path.join(work, "before.json");
  const after = path.join(work, "after.json");
  fs.copyFileSync(fixture("pricing/a/before.json"), before);
  fs.copyFileSync(fixture("pricing/a/after.json"), after);
  const base = readJson(fixture("repeat/a/next-run.json"));
  const man = structuredClone(base);
  man.inputs = { before: "./before.json", after: "./after.json" };
  man.currentInputs.before.path = "./before.json";
  man.currentInputs.after.path = "./after.json";
  man.currentInputs.before.bytes = fs.statSync(before).size;
  man.currentInputs.after.bytes = fs.statSync(after).size;
  man.currentInputs.before.sha256 = createHash("sha256").update(fs.readFileSync(before)).digest("hex");
  man.currentInputs.after.sha256 = createHash("sha256").update(fs.readFileSync(after)).digest("hex");
  const manPath = path.join(work, "next-run.json");
  writeJson(manPath, man);

  const outOk = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-ok-"));
  const ok = run("apps/repeat-job-record/cli.mjs", ["--next-run", manPath, "--out-dir", outOk]);
  assert.equal(ok.status, "actionable");
  assert.equal(ok.identityVerified, true);
  const artOk = readJson(path.join(outOk, "repeat-job.json"));
  assert.equal(artOk.identityVerified, true);
  assert.equal(artOk.repeatJob.identityVerification.state, "verified");

  // Change ONLY after file bytes; leave declared hash string unchanged.
  fs.writeFileSync(after, JSON.stringify({ ...readJson(after), mutated: true, nonce: "s251-byte-change" }) + "\n");
  const mismatch = run(
    "apps/repeat-job-record/cli.mjs",
    ["--next-run", manPath, "--out-dir", fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-bad-"))],
    { expectStatus: 2 },
  );
  assert.equal(mismatch.code, "input-digest-mismatch");

  // Correct manifest to actual new bytes → verified identity changes.
  const man2 = structuredClone(man);
  man2.currentInputs.after.bytes = fs.statSync(after).size;
  man2.currentInputs.after.sha256 = createHash("sha256").update(fs.readFileSync(after)).digest("hex");
  const manPath2 = path.join(work, "next-run-corrected.json");
  writeJson(manPath2, man2);
  const out2 = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-ok2-"));
  const ok2 = run("apps/repeat-job-record/cli.mjs", ["--next-run", manPath2, "--out-dir", out2]);
  assert.equal(ok2.status, "actionable");
  assert.equal(ok2.identityVerified, true);
  assert.notEqual(ok2.digest, ok.digest);

  // Manifest-only import (files unavailable) → informational, not verified identity.
  const orphanDir = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-orphan-"));
  const orphanMan = structuredClone(man);
  orphanMan.currentInputs.before.path = "./missing-before.json";
  orphanMan.currentInputs.after.path = "./missing-after.json";
  orphanMan.inputs = { before: "./missing-before.json", after: "./missing-after.json" };
  const orphanPath = path.join(orphanDir, "next-run.json");
  writeJson(orphanPath, orphanMan);
  const outOrphan = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-orph-out-"));
  const orphan = run("apps/repeat-job-record/cli.mjs", ["--next-run", orphanPath, "--out-dir", outOrphan]);
  assert.equal(orphan.status, "informational");
  assert.equal(orphan.identityVerified, false);
  const artOrphan = readJson(path.join(outOrphan, "repeat-job.json"));
  assert.equal(artOrphan.identityVerified, false);
  assert.match(String(artOrphan.repeatJob.identityVerification.state), /unverified|missing/);

  // Two legitimate distinct callers still pass with verified identity.
  const outA = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-a-"));
  const outB = fs.mkdtempSync(path.join(os.tmpdir(), "s242-rep-b-"));
  const a = run("apps/repeat-job-record/cli.mjs", [
    "--next-run",
    fixture("repeat/a/next-run.json"),
    "--out-dir",
    outA,
  ]);
  const b = run("apps/repeat-job-record/cli.mjs", [
    "--next-run",
    fixture("repeat/b/next-run.json"),
    "--out-dir",
    outB,
  ]);
  assert.equal(a.status, "actionable");
  assert.equal(b.status, "actionable");
  assert.equal(a.identityVerified, true);
  assert.equal(b.identityVerified, true);
  assert.notEqual(a.digest, b.digest);
  const art = readJson(path.join(outA, "repeat-job.json"));
  assert.equal(art.repeatJob.schedulerDaemon, false);
  assert.ok(art.repeatJob.inputs.declaredDigests.before.sha256);
  assert.ok(art.repeatJob.inputs.verifiedDigests.before.sha256);
});

test("output refuses collision with source input path", () => {
  const input = fixture("listing/caller-alpha.json");
  const out = run(
    "apps/listing-repair-packet/cli.mjs",
    ["--input", input, "--out-dir", input],
    { expectStatus: 2 },
  );
  assert.equal(out.code, "out-dir-collides-with-input");
});

test("capacity results name parallel_node_acceptance_jobs and reject invented 12", () => {
  const rejected = path.join(ROOT, "receipts/CAPACITY-LEDGER-20260910-s233-rejected.jsonl");
  // File is created on accept; presence after accept is checked in accept script path.
  // Here assert resource-sample field naming.
  const r = spawnSync(
    process.execPath,
    [path.join(ROOT, "scripts/resource-sample.mjs"), "unit", "4"],
    { encoding: "utf8" },
  );
  assert.equal(r.status, 0);
  const j = JSON.parse(r.stdout.trim());
  assert.equal(j.workloadClass, "parallel_node_acceptance_jobs");
  assert.equal(j.parallelNodeAcceptanceJobs, 4);
  assert.equal(j.nativeModelConcurrency, "unmeasured");
  assert.equal(j.overlapBuilders, undefined);
});
