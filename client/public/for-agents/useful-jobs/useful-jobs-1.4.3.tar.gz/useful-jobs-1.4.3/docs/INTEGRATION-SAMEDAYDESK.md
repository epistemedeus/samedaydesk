# SameDayDesk integration proposal (minimal)

Point a SameDayDesk `/for-agents/useful-jobs` page at the frozen useful-jobs
release archive and a machine-readable discovery document.

## Suggested discovery JSON

Serve something like:

```json
{
  "schema": "samedaydesk.for-agents.useful-jobs.v1",
  "package": "useful-jobs",
  "version": "1.0.0",
  "archiveUrl": "https://samedaydesk.com/for-agents/useful-jobs/useful-jobs-1.0.0.tar.gz",
  "sha256": "<release-archive-sha256>",
  "bytes": 0,
  "node": ">=22",
  "offline": true,
  "purchaseAuthority": false,
  "jobsCatalogUrl": "https://samedaydesk.com/for-agents/useful-jobs/catalog.json",
  "install": [
    "curl -fsSL <archiveUrl> -o useful-jobs-1.0.0.tar.gz",
    "echo '<sha256>  useful-jobs-1.0.0.tar.gz' | sha256sum -c -",
    "tar -xzf useful-jobs-1.0.0.tar.gz",
    "cd useful-jobs-1.0.0",
    "node bin/useful-jobs.mjs list"
  ]
}
```

## Page shape

- One job list from `catalog.json`
- Exact archive bytes + sha256
- Offline install commands only
- No customer/payment/revenue claims

Site ownership and publication remain outside this package. This file is a
pointer for the owning site integration after the archive is frozen.
