#!/usr/bin/env node
import path from "node:path";
import {
  assertArchivePins, recordRepeatBin, runNodeJson, writeJson, writeText, parseArgs, fixture, labelSample,
} from "../../lib/common.mjs";
import { envelope, digestObj } from "../../lib/artifact.mjs";
import { requireCallerInputs, resolveOutDir } from "../../lib/cli-runtime.mjs";

const APP = "api-upgrade-brief";
const OUTPUTS = ["upgrade-brief.json", "upgrade-brief.md"];

export function buildBrief(underlying, caller) {
  const outer = underlying?.report || underlying || {};
  const inner = outer.report || outer;
  const impact = inner.impact || {};
  const added = impact.added || [];
  const removed = impact.removed || [];
  const changed = impact.changed || [];
  const unknowns = impact.unknowns || [];
  const refused = underlying?.ok === false || inner.ok === false;
  const partial = (inner.uncertainties || []).length > 0 || unknowns.length > 0;
  const hasDelta = added.length + removed.length + changed.length > 0;
  const status = refused ? "refused" : partial ? "partial" : hasDelta ? "actionable" : "informational";
  const actions = [];
  for (const x of removed) {
    actions.push({
      priority: "high",
      kind: "retire-or-migrate",
      op: x.key || x,
      note: "Used operation removed in after snapshot",
    });
  }
  for (const x of changed) {
    actions.push({
      priority: "high",
      kind: "review-breaking-change",
      op: x.key || x,
      note: "Used operation changed",
    });
  }
  for (const x of added) {
    actions.push({
      priority: "medium",
      kind: "consider-adoption",
      op: x.key || x,
      note: "New used-pin operation in after snapshot",
    });
  }
  if (!actions.length && !refused) {
    actions.push({
      priority: "low",
      kind: "no-used-op-delta",
      note: "No structural delta on used operations; not a runtime compatibility proof",
    });
  }
  const art = envelope({
    appId: APP,
    status,
    summary: refused
      ? "OpenAPI used-ops comparison refused"
      : hasDelta
        ? `Used-ops delta: +${added.length}/~${changed.length}/-${removed.length}`
        : "No used-operation structural delta",
    actions,
    gaps: [...(inner.uncertainties || []), ...unknowns.map((u) => u.key || String(u))],
    underlying: {
      family: "openapi-used-ops",
      ok: !refused,
      differenceInDeliveredOutput: inner.differenceInDeliveredOutput || null,
    },
    caller: labelSample(caller),
  });
  art.digest = digestObj({ status: art.status, actions: art.actions, gaps: art.gaps, caller: art.caller });
  return art;
}

export function toMarkdown(art) {
  const lines = ["# API upgrade brief", "", `Status: **${art.status}**`, "", art.summary, "", "## Actions"];
  for (const a of art.actions) {
    lines.push(`- (${a.priority}) ${a.kind}${a.op ? `: \`${a.op}\`` : ""} - ${a.note}`);
  }
  if (art.gaps?.length) {
    lines.push("", "## Gaps");
    for (const g of art.gaps) lines.push(`- ${g}`);
  }
  lines.push("", "_Fixture samples are not live market facts or customer demand._", "");
  return lines.join("\n");
}

export function run(args) {
  assertArchivePins();
  const mode = requireCallerInputs(args, ["before", "after", "used"]);
  const exampleMode = mode.mode === "example";
  const before = exampleMode ? fixture("openapi/a/before.yaml") : args.before;
  const after = exampleMode ? fixture("openapi/a/after.yaml") : args.after;
  const used = exampleMode ? fixture("openapi/a/used.json") : args.used;
  const outDir = resolveOutDir(APP, args, [before, after, used], OUTPUTS);
  const r = runNodeJson(recordRepeatBin(), [
    "run",
    "--family",
    "openapi-used-ops",
    "--before",
    before,
    "--after",
    after,
    "--used",
    used,
  ]);
  if (!r.json) throw new Error(`record-repeat failed: ${r.combined.slice(0, 800)}`);
  const art = buildBrief(r.json, {
    before,
    after,
    used,
    exampleMode,
    sampleLabel: exampleMode ? "explicit-example" : "caller-input",
  });
  writeJson(path.join(outDir, "upgrade-brief.json"), art);
  writeText(path.join(outDir, "upgrade-brief.md"), toMarkdown(art));
  art.outDir = outDir;
  return art;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const art = run(parseArgs(process.argv.slice(2)));
    process.stdout.write(
      JSON.stringify({
        ok: true,
        appId: APP,
        status: art.status,
        digest: art.digest,
        outDir: art.outDir,
        actions: art.actions.length,
      }) + "\n",
    );
  } catch (err) {
    process.stdout.write(
      JSON.stringify({
        ok: false,
        refused: true,
        code: err.code || "error",
        error: err.message,
        detail: err.detail || null,
      }) + "\n",
    );
    process.exit(err.exitCode || 2);
  }
}
