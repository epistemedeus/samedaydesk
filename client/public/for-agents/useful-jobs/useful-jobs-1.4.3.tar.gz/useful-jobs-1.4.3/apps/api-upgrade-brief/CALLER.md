# api-upgrade-brief - caller guide

Machine-friendly contract for the API Upgrade Brief job.

## Purpose

Compare a **before** OpenAPI document to an **after** OpenAPI document against a
**used-operation pin list**, then emit a short upgrade brief with prioritized
actions (retire/migrate removed used ops, review changed used ops, consider
new used-pin ops). Offline structural comparison only.

## Honesty / limits

- Bundled and caller SAMPLE OpenAPI trees are **fixtures**, not customers,
  live APIs, or market demand.
- This job does **not** grant purchase, network, scheduler, or settlement
  authority.
- Output is **not** a runtime compatibility proof. Status may be
  `informational`, `actionable`, `partial`, or `refused`.

## Required inputs (caller mode)

| Flag | Meaning |
|------|---------|
| `--before` | Path to before OpenAPI YAML/JSON |
| `--after` | Path to after OpenAPI YAML/JSON |
| `--used` | Path to JSON listing used operations (`method` + `path`) |

Optional: `--out-dir <dir>` (default: `out/api-upgrade-brief/run-<id>/`).

Missing any required flag **refuses closed** (`missing-required-inputs`).

## `--example` vs caller files

| Mode | How | Inputs |
|------|-----|--------|
| Example | `--example` | Uses labeled fixtures under `samples/openapi/a/` |
| Caller | `--before` `--after` `--used` | Your paths (or package SAMPLE trees) |

Do not mix: `--example` ignores caller `--before`/`--after`/`--used`.

### Caller-authored SAMPLE trees (not customers)

- `samples/openapi/caller-alpha/` - inventory-style SAMPLE; after removes
  `DELETE /inventory/{sku}` and changes `POST /inventory`.
- `samples/openapi/caller-beta/` - shipments-style SAMPLE; after removes
  `PATCH /shipments/{id}` and changes `GET /shipments/{id}`.

Each directory has `SAMPLE.txt`, `before.yaml`, `after.yaml`, `used.json`.

## Outputs

Written under `--out-dir` (or the default run directory):

| File | Content |
|------|---------|
| `upgrade-brief.json` | Envelope: `status`, `summary`, `actions`, `gaps`, `digest`, caller label |
| `upgrade-brief.md` | Human-readable brief of the same actions |

Stdout JSON includes `ok`, `appId`, `status`, `digest`, `outDir`, `actions`.

## Exact commands

From the package root:

### Refuse when inputs missing

```bash
node bin/useful-jobs.mjs run api-upgrade-brief
node apps/api-upgrade-brief/cli.mjs
```

### Labeled package example

```bash
node bin/useful-jobs.mjs run api-upgrade-brief --example
node apps/api-upgrade-brief/cli.mjs --example
```

### Caller SAMPLE alpha

```bash
node bin/useful-jobs.mjs run api-upgrade-brief \
  --before samples/openapi/caller-alpha/before.yaml \
  --after samples/openapi/caller-alpha/after.yaml \
  --used samples/openapi/caller-alpha/used.json \
  --out-dir ./out/api-upgrade-brief/caller-alpha

node apps/api-upgrade-brief/cli.mjs \
  --before samples/openapi/caller-alpha/before.yaml \
  --after samples/openapi/caller-alpha/after.yaml \
  --used samples/openapi/caller-alpha/used.json \
  --out-dir ./out/api-upgrade-brief/caller-alpha
```

### Caller SAMPLE beta

```bash
node bin/useful-jobs.mjs run api-upgrade-brief \
  --before samples/openapi/caller-beta/before.yaml \
  --after samples/openapi/caller-beta/after.yaml \
  --used samples/openapi/caller-beta/used.json \
  --out-dir ./out/api-upgrade-brief/caller-beta

node apps/api-upgrade-brief/cli.mjs \
  --before samples/openapi/caller-beta/before.yaml \
  --after samples/openapi/caller-beta/after.yaml \
  --used samples/openapi/caller-beta/used.json \
  --out-dir ./out/api-upgrade-brief/caller-beta
```

### Help

```bash
node bin/useful-jobs.mjs help api-upgrade-brief
```
