#!/usr/bin/env node
import path from "node:path";
import {
  assertArchivePins, writeJson, writeText, parseArgs, fixture, labelSample, readJson,
} from "../../lib/common.mjs";
import { envelope, digestObj } from "../../lib/artifact.mjs";
import { requireCallerInputs, resolveOutDir } from "../../lib/cli-runtime.mjs";
import { validateEvidencePacket } from "../../lib/validate-evidence.mjs";

const APP = "evidence-ci-annotation";
const OUTPUTS = ["annotations.json", "annotations.md"];

/**
 * Downstream status for this local formatter never upgrades caller-supplied
 * schema-compatible packets into trusted/actionable kit authority.
 */
function decisionToStatus(decision) {
  if (decision === "fail") return "refused";
  if (decision === "partial" || decision === "conflict") return "partial";
  // pass / unknown → informational (useful CI rows, visibly untrusted)
  return "informational";
}

export function buildAnnotation(packet, provenance, caller) {
  const decision = packet.decision;
  const status = decisionToStatus(decision);
  const annotations = [];
  const sourcePath =
    (Array.isArray(packet.sources) && packet.sources[0] && packet.sources[0].path) || "evidence";
  for (const f of packet.findings || []) {
    annotations.push({
      path: sourcePath,
      annotation_level:
        decision === "fail" ? "failure" : decision === "partial" || decision === "conflict" ? "warning" : "notice",
      message: `${f.id}: ${f.summary || ""}`.trim(),
      title: `Evidence (unattested): ${packet.jobId || "job"}`,
    });
  }
  for (const g of packet.limitations || []) {
    annotations.push({
      path: "evidence",
      annotation_level: "warning",
      message: g,
      title: "Evidence limitation (unattested)",
    });
  }
  const actions = annotations.map((a) => ({
    priority: a.annotation_level === "failure" ? "high" : "medium",
    kind: "ci-annotation-unattested",
    note: a.message,
  }));
  if (!actions.length && status !== "refused") {
    actions.push({ priority: "low", kind: "ci-clean-unattested", note: "No annotation rows" });
  }
  const art = envelope({
    appId: APP,
    status,
    summary: `Caller-supplied evidence job ${packet.jobId || "unknown"} decision=${decision} (schema-compatible, unattested)`,
    actions,
    gaps: [
      ...(packet.limitations || []),
      "Caller-supplied schema-compatible packet is not kit-produced or externally attested; status is not trusted action",
    ],
    underlying: {
      formatReference: provenance.formatReference,
      schema: provenance.schema,
      provenanceKind: provenance.kind,
      origin: provenance.origin,
      authority: false,
      trust: "unattested",
      kitProduced: false,
      externallyAttested: false,
      decision,
      verificationClaims: provenance.verificationClaims || [],
      note: provenance.note,
    },
    caller: labelSample(caller),
  });
  art.trust = "unattested";
  art.authority = false;
  art.githubCheckAnnotations = annotations;
  art.digest = digestObj({
    status: art.status,
    trust: art.trust,
    authority: art.authority,
    decision,
    annotations,
    jobId: packet.jobId,
    caller: art.caller,
  });
  return art;
}

export function toMarkdown(art) {
  const lines = [
    "# CI evidence annotations (caller-supplied, unattested)",
    "",
    `Status: **${art.status}**`,
    `Trust: **${art.trust || "unattested"}**`,
    `Authority: **${art.authority === true ? "true" : "false"}**`,
    "",
    art.summary,
    "",
    "## Annotations",
  ];
  for (const a of art.githubCheckAnnotations || []) lines.push(`- [${a.annotation_level}] ${a.message}`);
  if (art.underlying?.verificationClaims?.length) {
    lines.push("", "## Caller verification claims (not automatic attestation)");
    for (const c of art.underlying.verificationClaims) {
      lines.push(`- claim: ${c.value}${c.label ? ` (${c.label})` : ""} - attested=false`);
    }
  }
  lines.push(
    "",
    "_Schema-compatible with the consumer-evidence packet format/reference only. Not kit-produced, not externally attested, not trusted action authority._",
    "",
  );
  return lines.join("\n");
}

export async function run(args) {
  assertArchivePins();
  const mode = requireCallerInputs(args, ["input"]);
  const exampleMode = mode.mode === "example";
  const input = exampleMode ? fixture("evidence/caller-a.json") : args.input;
  const outDir = resolveOutDir(APP, args, [input], OUTPUTS);
  const raw = readJson(input);
  const { packet, provenance } = await validateEvidencePacket(raw);
  const art = buildAnnotation(packet, provenance, {
    input,
    exampleMode,
    sampleLabel: exampleMode ? "explicit-example" : "caller-input",
  });
  writeJson(path.join(outDir, "annotations.json"), art);
  writeText(path.join(outDir, "annotations.md"), toMarkdown(art));
  art.outDir = outDir;
  return art;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  run(parseArgs(process.argv.slice(2)))
    .then((art) => {
      process.stdout.write(
        JSON.stringify({
          ok: true,
          appId: APP,
          status: art.status,
          trust: art.trust,
          authority: art.authority,
          digest: art.digest,
          outDir: art.outDir,
          annotations: (art.githubCheckAnnotations || []).length,
        }) + "\n",
      );
    })
    .catch((err) => {
      process.stdout.write(
        JSON.stringify({
          ok: false,
          refused: true,
          code: err.code || "error",
          error: err.message,
          detail: err.detail || null,
        }) + "\n",
      );
      process.exit(err.exitCode || 2);
    });
}
