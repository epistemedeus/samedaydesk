# Evidence CI Annotation

Format a **caller-supplied**, schema-compatible consumer-evidence packet into
GitHub Check-style annotation rows for local CI use.

This job is a local formatter only. Schema-compatible inputs stay
**unattested**. They are never treated as kit-produced trusted action.

| Field | Value |
| --- | --- |
| Job id | `evidence-ci-annotation` |
| Required input | `--input` (path to a JSON evidence packet) |
| Labeled sample | `--example` (uses `samples/evidence/caller-a.json`) |
| Outputs | `annotations.json`, `annotations.md` |
| Trust | always `unattested` |
| Authority | always `false` |

## Honesty

- Your packet is **caller-authored**. Passing the local schema check does **not**
  mean the kit produced it, attested it, or granted action authority.
- Output status for a schema-compatible `pass` (or unknown) decision is
  **informational**, with `trust: "unattested"` and `authority: false`.
- `partial` / `conflict` decisions map to status **partial** (still unattested).
- `fail` maps to status **refused** (still unattested; useful annotation rows only).
- Foreign-shaped JSON (wrong schema, thin `{ "status": "pass" }` objects, missing
  required fields) is **refused closed**. It is not upgraded into trusted action.
- Caller-supplied verification URLs, if present, are echoed as claims with
  `attested=false`. They do not become attestation.
- `--example` and files under `samples/evidence/` are **labeled fixtures**, not
  customer evidence.

## Required input

`--input <path>` - JSON object whose `schema` matches the pinned consumer-evidence
packet schema (`s137.consumer-evidence.packet.v1`). Minimum checked fields include
`decision`, `evidenceClass`, `clock`, `findings[]` (each with `citationIds`), and
`citations[]`.

Optional convenience:

- `--out-dir <dir>` - write outputs here (default: a fresh unique directory under
  `out/evidence-ci-annotation/`).

## Run

```bash
# Refuse closed when --input is missing
node bin/useful-jobs.mjs run evidence-ci-annotation
# → missing-required-inputs

# Labeled sample (caller-a fixture)
node bin/useful-jobs.mjs run evidence-ci-annotation --example

# Your packet
node bin/useful-jobs.mjs run evidence-ci-annotation \
  --input ./yours/evidence-packet.json \
  --out-dir ./out/evidence-ci
```

Direct app CLI (same contract):

```bash
node apps/evidence-ci-annotation/cli.mjs --input ./yours/evidence-packet.json
node apps/evidence-ci-annotation/cli.mjs --example
```

## Outputs

Written under the chosen `--out-dir`:

| File | Contents |
| --- | --- |
| `annotations.json` | Envelope with `status`, `trust: "unattested"`, `authority: false`, `githubCheckAnnotations[]`, digest, gaps, and underlying provenance (`kitProduced: false`, `externallyAttested: false`) |
| `annotations.md` | Human-readable annotation list with the same unattested / no-authority markers |

Stdout is a short JSON receipt (`ok`, `status`, `trust`, `authority`, `digest`,
`outDir`, `annotations` count).

## Two labeled caller samples

Both are hand-authored fixtures under `samples/evidence/`. They are schema-compatible
and stay **unattested**. They produce **different** annotation digests and row sets.

| Sample | Path | Decision → status | What differs |
| --- | --- | --- | --- |
| Caller A | `samples/evidence/caller-a.json` | `pass` → `informational` | Freshness findings; optional verification claim (still `attested=false`) |
| Caller B | `samples/evidence/caller-b.json` | `partial` → `partial` | Link-index findings plus limitation warnings |

```bash
node apps/evidence-ci-annotation/cli.mjs \
  --input samples/evidence/caller-a.json --out-dir ./out/ev-a

node apps/evidence-ci-annotation/cli.mjs \
  --input samples/evidence/caller-b.json --out-dir ./out/ev-b
```

Compare `annotations.json` digests and `githubCheckAnnotations` between the two
directories: different job ids, findings, levels, and status.

A third fixture, `samples/evidence/refused.json`, exercises the `fail` →
`refused` path (still unattested).

## What this job does not do

- Does not produce kit-authored evidence
- Does not externally attest caller packets
- Does not grant purchase, network, or CI-merge authority
- Does not treat schema compatibility as trust upgrade
