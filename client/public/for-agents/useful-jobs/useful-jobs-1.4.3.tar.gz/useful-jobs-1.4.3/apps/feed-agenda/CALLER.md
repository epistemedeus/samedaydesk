# Feed Agenda

Compare two RSS or Atom feed snapshots and turn the delta into a local agenda.

## What you get

- `agenda.json` - structured status, events (added / corrected / removed), and suggested actions
- `agenda.ics` - the same events as a calendar file you can open in a calendar app

## Required inputs

Caller mode needs both feed files:

| Flag | Meaning |
| --- | --- |
| `--before` | Earlier feed snapshot (RSS or Atom XML) |
| `--after` | Later feed snapshot (RSS or Atom XML) |

Optional: `--out-dir <dir>` to choose where outputs are written. If omitted, a fresh directory is created under `out/feed-agenda/`.

## Quick start

Labeled package sample (not your production feeds):

```bash
node bin/useful-jobs.mjs run feed-agenda --example
```

Your own before/after pair:

```bash
node bin/useful-jobs.mjs run feed-agenda \
  --before ./feeds/yesterday.xml \
  --after ./feeds/today.xml \
  --out-dir ./out/feed-agenda-run
```

Direct app entry:

```bash
node apps/feed-agenda/cli.mjs \
  --before ./feeds/yesterday.xml \
  --after ./feeds/today.xml \
  --out-dir ./out/feed-agenda-run
```

## Sample feed pairs

Under `samples/feed/`:

| Pair | Files | Intended delta |
| --- | --- | --- |
| `caller-alpha/` | `before.xml`, `after.xml` | One item removed, one item added |
| `caller-beta/` | `before.xml`, `after.xml` | One item removed, two items added |

Both pairs are labeled **SAMPLE**. They demonstrate fixture feed deltas only.

```bash
node apps/feed-agenda/cli.mjs \
  --before samples/feed/caller-alpha/before.xml \
  --after samples/feed/caller-alpha/after.xml \
  --out-dir ./out/agenda-alpha

node apps/feed-agenda/cli.mjs \
  --before samples/feed/caller-beta/before.xml \
  --after samples/feed/caller-beta/after.xml \
  --out-dir ./out/agenda-beta
```

## Honesty

- `--example` and everything under `samples/feed/` are labeled fixtures, not customer demand and not live market facts.
- Agenda entries describe sample feed deltas (added / corrected / removed). They are **not live deadlines**.
- ICS event descriptions repeat that fixture wording so calendar imports stay clearly non-operational.
- Missing `--before` or `--after` (without `--example`) refuses closed with `missing-required-inputs`.

## Outputs at a glance

Successful runs print a small JSON receipt on stdout (`ok`, `status`, `digest`, `outDir`, `events`) and write:

1. `agenda.json`
2. `agenda.ics`

Status is typically `actionable` when there is a delta, `informational` when the feeds match, `partial` when upstream reports conflicts, or `refused` when comparison cannot proceed.
