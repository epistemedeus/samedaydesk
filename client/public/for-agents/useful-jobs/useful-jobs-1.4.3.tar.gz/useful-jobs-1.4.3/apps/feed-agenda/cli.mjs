#!/usr/bin/env node
import path from "node:path";
import {
  assertArchivePins, recordRepeatBin, runNodeJson, writeJson, writeText, parseArgs, fixture, labelSample,
} from "../../lib/common.mjs";
import { envelope, digestObj } from "../../lib/artifact.mjs";
import { requireCallerInputs, resolveOutDir } from "../../lib/cli-runtime.mjs";

const APP = "feed-agenda";
const OUTPUTS = ["agenda.json", "agenda.ics"];

function unwrapItem(x) {
  const item = x?.item && typeof x.item === "object" ? x.item : x;
  return item && typeof item === "object" ? item : {};
}

function itemKey(x) {
  const item = unwrapItem(x);
  return item.id || x?.key || item.key || item.link || item.title || item.guid || JSON.stringify(x);
}

function eventFields(kind, x) {
  const item = unwrapItem(x);
  return {
    kind,
    key: itemKey(x),
    title: item.title || null,
    link: item.link || null,
    updated: item.updated || item.pubDate || null,
  };
}

export function buildAgenda(underlying, caller) {
  const outer = underlying?.report || underlying || {};
  const inner = outer.report || outer;
  const added = inner.added || [];
  const removed = inner.removed || [];
  const corrected = inner.corrected || [];
  const refused = underlying?.ok === false || inner.comparable === false || inner.ok === false;
  const partial = (inner.conflicting || []).length > 0;
  const hasDelta = added.length + removed.length + corrected.length > 0;
  const status = refused ? "refused" : partial ? "partial" : hasDelta ? "actionable" : "informational";
  const events = [];
  for (const x of added) events.push(eventFields("added", x));
  for (const x of corrected) events.push(eventFields("corrected", x));
  for (const x of removed) events.push(eventFields("removed", x));
  const actions = events.map((e) => ({
    priority: e.kind === "removed" ? "medium" : "high",
    kind: `agenda-${e.kind}`,
    key: e.key,
    note: `SAMPLE fixture feed ${e.kind} entry (not a live deadline)`,
  }));
  if (!actions.length && !refused) {
    actions.push({ priority: "low", kind: "agenda-unchanged", note: "No added/corrected/removed entries" });
  }
  const art = envelope({
    appId: APP,
    status,
    summary: refused
      ? "Feed comparison refused or incomparable"
      : `Agenda delta: +${added.length}/~${corrected.length}/-${removed.length}`,
    actions,
    gaps: partial ? ["conflicting feed items"] : [],
    underlying: { family: "rss-atom-brief", ok: !refused },
    caller: labelSample(caller),
  });
  art.events = events;
  art.digest = digestObj({ status: art.status, events, caller: art.caller });
  return art;
}

export function toIcs(art) {
  const stamp = art.generatedAt.replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//useful-jobs Feed Agenda//EN", "CALSCALE:GREGORIAN"];
  let i = 0;
  for (const e of art.events || []) {
    i += 1;
    lines.push(
      "BEGIN:VEVENT",
      `UID:${art.digest}-${i}@feed-agenda.sample`,
      `DTSTAMP:${stamp}`,
      `SUMMARY:${`${e.kind}: ${e.title || e.key}`.replace(/\n/g, " ")}`,
    );
    if (e.link) lines.push(`URL:${e.link}`);
    lines.push("DESCRIPTION:SAMPLE fixture feed delta. Not a live deadline.", "END:VEVENT");
  }
  if (!(art.events || []).length) {
    lines.push(
      "BEGIN:VEVENT",
      `UID:${art.digest}@feed-agenda.sample`,
      `DTSTAMP:${stamp}`,
      "SUMMARY:No feed agenda deltas",
      "DESCRIPTION:Informational empty agenda (SAMPLE fixture)",
      "END:VEVENT",
    );
  }
  lines.push("END:VCALENDAR", "");
  return lines.join("\r\n");
}

export function run(args) {
  assertArchivePins();
  const mode = requireCallerInputs(args, ["before", "after"]);
  const exampleMode = mode.mode === "example";
  const before = exampleMode ? fixture("feed/caller-alpha/before.xml") : args.before;
  const after = exampleMode ? fixture("feed/caller-alpha/after.xml") : args.after;
  const outDir = resolveOutDir(APP, args, [before, after], OUTPUTS);
  const r = runNodeJson(recordRepeatBin(), [
    "run",
    "--family",
    "rss-atom-brief",
    "--before",
    before,
    "--after",
    after,
  ]);
  if (!r.json) throw new Error(`record-repeat failed: ${r.combined.slice(0, 800)}`);
  const art = buildAgenda(r.json, {
    before,
    after,
    exampleMode,
    sampleLabel: exampleMode ? "explicit-example" : "caller-input",
  });
  writeJson(path.join(outDir, "agenda.json"), art);
  writeText(path.join(outDir, "agenda.ics"), toIcs(art));
  art.outDir = outDir;
  return art;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const art = run(parseArgs(process.argv.slice(2)));
    process.stdout.write(
      JSON.stringify({
        ok: true,
        appId: APP,
        status: art.status,
        digest: art.digest,
        outDir: art.outDir,
        events: (art.events || []).length,
      }) + "\n",
    );
  } catch (err) {
    process.stdout.write(
      JSON.stringify({
        ok: false,
        refused: true,
        code: err.code || "error",
        error: err.message,
        detail: err.detail || null,
      }) + "\n",
    );
    process.exit(err.exitCode || 2);
  }
}
