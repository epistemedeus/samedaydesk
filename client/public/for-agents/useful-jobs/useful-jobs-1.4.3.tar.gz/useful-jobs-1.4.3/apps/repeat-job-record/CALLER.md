# Repeat Job Record

Build an operator-schedulable next-run record from a next-run manifest, with
local byte verification of declared input digests. This job does **not** start
a scheduler daemon.

## Required inputs

| Flag | Meaning |
| --- | --- |
| `--next-run` | Path to a next-run manifest (`s176.next-run-manifest.v1` or `s163.next-run-manifest.v1`) |

## Optional inputs

| Flag | Meaning |
| --- | --- |
| `--input-root` | Resolve relative `currentInputs.*.path` values against this directory instead of the manifest directory |
| `--out-dir` | Output directory (default: fresh unique dir under `out/repeat-job-record/`) |
| `--example` | Run the labeled package sample (not a customer run) |

## Outputs

| File | Contents |
| --- | --- |
| `repeat-job.json` | Machine-readable repeat-job record envelope |
| `repeat-job.md` | Operator-facing markdown summary |

## Run

```bash
# Labeled sample (fixture only)
node bin/useful-jobs.mjs run repeat-job-record --example

# Your next-run manifest (paths resolve relative to the manifest directory)
node bin/useful-jobs.mjs run repeat-job-record \
  --next-run ./yours/next-run.json \
  --out-dir ./out/repeat

# Or pin relative inputs under an explicit root
node bin/useful-jobs.mjs run repeat-job-record \
  --next-run ./yours/next-run.json \
  --input-root ./yours/inputs \
  --out-dir ./out/repeat
```

Direct CLI:

```bash
node apps/repeat-job-record/cli.mjs --next-run ./yours/next-run.json --out-dir ./out/repeat
```

## Byte verification

Declared digests live in `currentInputs.{before,after,used}` (`path`, `bytes`,
`sha256`). On each run the job reads local files and compares:

| Local bytes vs declared digests | Result |
| --- | --- |
| All declared inputs present and match | `status: actionable`, `identityVerified: true` |
| Digest or byte-length **mismatch** | **Refuse** (`input-digest-mismatch`, exit 2). No verified record. |
| Declared inputs **missing** on disk | Record is written as **informational / unverified** (not verified identity) |
| Manifest schema/family invalid | **Refuse** closed |

Corrected bytes after a change are a **new identity**: update the declared
`bytes`/`sha256` in the manifest to match the new file contents, then re-run.
The prior digest no longer verifies.

Missing required caller flags (`--next-run` without `--example`) refuse closed
with `missing-required-inputs`.

## What this is not

- Not a background scheduler or cron daemon (`schedulerDaemon: false`)
- Not purchase, network, or demand proof
- Samples under `samples/repeat/` (including `--example` and caller-alpha/beta)
  are labeled fixtures, not customers
