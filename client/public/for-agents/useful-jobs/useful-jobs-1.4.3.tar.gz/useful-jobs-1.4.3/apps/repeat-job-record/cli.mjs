#!/usr/bin/env node
import path from "node:path";
import {
  assertArchivePins, writeJson, writeText, parseArgs, fixture, labelSample, readJson,
} from "../../lib/common.mjs";
import { envelope, digestObj } from "../../lib/artifact.mjs";
import { requireCallerInputs, resolveOutDir } from "../../lib/cli-runtime.mjs";
import { validateNextRunManifest, validateNextRunFile } from "../../lib/validate-next-run.mjs";

const APP = "repeat-job-record";
const OUTPUTS = ["repeat-job.json", "repeat-job.md"];

function statusFromVerification(validated) {
  const refused = validated.manifest?.ok === false;
  if (refused) return "refused";
  const state = validated.inputVerification?.state;
  if (state === "mismatch") return "refused";
  if (state === "verified") return validated.family ? "actionable" : "partial";
  if (state === "partial-missing-files") return "partial";
  // unverified-missing-files / no-declared-inputs / unknown → informational, not verified identity
  return "informational";
}

export function buildRepeatRecord(validated, caller, { scheduleHint = "manual-operator" } = {}) {
  const {
    manifest: nextRun,
    family,
    declaredInputs,
    verifiedDigestMaterial,
    inputVerification,
    manifestDigest,
    provenance,
  } = validated;
  const status = statusFromVerification(validated);
  const verified = inputVerification?.state === "verified";
  const record = {
    schema: "s242.repeat-job-record.v1",
    family,
    scheduleHint,
    schedulerDaemon: false,
    identityVerification: {
      state: inputVerification?.state || "unknown",
      verified,
      note: verified
        ? "Local file bytes matched declared digests relative to manifest/--input-root"
        : "Local file bytes were not fully verified; declared digests are not verified identity",
    },
    inputs: {
      before: caller.before || nextRun.inputs?.before || declaredInputs.before?.path || null,
      after: caller.after || nextRun.inputs?.after || declaredInputs.after?.path || null,
      used: caller.used || nextRun.inputs?.used || declaredInputs.used?.path || null,
      key: caller.key || nextRun.inputs?.key || null,
      declaredDigests: declaredInputs,
      verifiedDigests: verifiedDigestMaterial,
      manifestDigest,
    },
    nextRunManifest: nextRun,
    operatorInstructions: [
      "Re-run with changed local before/after artifacts using the same family.",
      "Do not start a background scheduler from this record.",
      "Preserve refused/partial flags from the underlying compare.",
      "Declared sha256 values are verified only when local file bytes match; otherwise the record is informational/unverified.",
    ],
  };
  const actions = [];
  if (status === "actionable") {
    actions.push({
      priority: "high",
      kind: "schedule-manually-or-via-caller-cron",
      note: `Repeat family ${family || "unknown"} with updated caller files; this record is not a daemon.`,
    });
  } else if (status === "informational") {
    actions.push({
      priority: "medium",
      kind: "supply-local-inputs-for-verified-identity",
      note: "Manifest schema is valid but local input bytes were not verified; do not treat identity as verified.",
    });
  } else if (status === "partial") {
    actions.push({
      priority: "high",
      kind: "complete-local-inputs",
      note: "Some declared inputs were missing; repeat identity is incomplete.",
    });
  } else {
    actions.push({
      priority: "high",
      kind: "fix-refused-or-mismatched-inputs",
      note: "Repeat record refused due to refused next-run or digest mismatch.",
    });
  }
  const gaps = [];
  if (!family) gaps.push("family missing from next-run manifest");
  if (!verified) {
    gaps.push("local input bytes not fully verified; identity is not verified");
    for (const m of inputVerification?.missing || []) {
      gaps.push(`missing local input ${m.slot}: ${m.path}`);
    }
  }
  const art = envelope({
    appId: APP,
    status,
    summary: status === "refused"
      ? "Cannot build verified repeat record from refused/mismatched next-run"
      : status === "actionable"
        ? `Verified repeat-job record for family ${family}`
        : status === "partial"
          ? `Partial repeat-job record for family ${family} (some inputs missing)`
          : `Unverified repeat-job record for family ${family} (manifest-only / missing local files)`,
    actions,
    gaps,
    underlying: {
      source: provenance.source,
      schema: provenance.schema,
      provenanceKind: provenance.kind,
      family,
      manifestDigest,
      inputVerificationState: inputVerification?.state || null,
      note: provenance.note,
    },
    caller: labelSample(caller),
  });
  art.repeatJob = record;
  art.identityVerified = verified;
  art.digest = digestObj({
    status: art.status,
    family,
    declaredDigests: declaredInputs,
    verifiedDigests: verifiedDigestMaterial,
    inputVerificationState: inputVerification?.state || null,
    manifestDigest,
    caller: art.caller,
  });
  return art;
}

export function toMarkdown(art) {
  const r = art.repeatJob || {};
  const lines = [
    "# Repeat job record (operator-schedulable, not a daemon)",
    "",
    `Status: **${art.status}**`,
    `Identity verified: **${art.identityVerified === true ? "true" : "false"}**`,
    `Verification state: **${r.identityVerification?.state || "unknown"}**`,
    "",
    art.summary,
    "",
    `Family: \`${r.family}\``,
    `Schedule hint: \`${r.scheduleHint}\``,
    `Daemon: **false**`,
    `Manifest digest: \`${r.inputs?.manifestDigest || ""}\``,
    "",
    "## Inputs",
    `- before: ${r.inputs?.before}`,
    `- after: ${r.inputs?.after}`,
    `- before.declared.sha256: ${r.inputs?.declaredDigests?.before?.sha256 || "n/a"}`,
    `- after.declared.sha256: ${r.inputs?.declaredDigests?.after?.sha256 || "n/a"}`,
    `- before.verified.sha256: ${r.inputs?.verifiedDigests?.before?.sha256 || "n/a"}`,
    `- after.verified.sha256: ${r.inputs?.verifiedDigests?.after?.sha256 || "n/a"}`,
    "",
    "## Operator steps",
  ];
  for (const s of r.operatorInstructions || []) lines.push(`- ${s}`);
  lines.push(
    "",
    "_Schema-validated next-run sample or caller input. Local byte verification required for verified identity. Not customer demand proof._",
    "",
  );
  return lines.join("\n");
}

export async function run(args) {
  assertArchivePins();
  const mode = requireCallerInputs(args, ["next-run"]);
  const exampleMode = mode.mode === "example";
  const nextRunPath = exampleMode ? fixture("repeat/a/next-run.json") : args["next-run"];
  const inputRoot = args["input-root"] ? path.resolve(String(args["input-root"])) : null;
  const sourcePaths = [nextRunPath, args.before, args.after, inputRoot].filter(Boolean);
  const outDir = resolveOutDir(APP, args, sourcePaths, OUTPUTS);
  const validated = await validateNextRunFile(nextRunPath, { inputRoot });
  const art = buildRepeatRecord(validated, {
    nextRunPath,
    before: args.before || null,
    after: args.after || null,
    inputRoot,
    exampleMode,
    sampleLabel: exampleMode ? "explicit-example" : "caller-input",
  });
  writeJson(path.join(outDir, "repeat-job.json"), art);
  writeText(path.join(outDir, "repeat-job.md"), toMarkdown(art));
  art.outDir = outDir;
  return art;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  run(parseArgs(process.argv.slice(2)))
    .then((art) => {
      process.stdout.write(
        JSON.stringify({
          ok: true,
          appId: APP,
          status: art.status,
          identityVerified: art.identityVerified === true,
          digest: art.digest,
          outDir: art.outDir,
          family: art.repeatJob?.family || null,
        }) + "\n",
      );
    })
    .catch((err) => {
      process.stdout.write(
        JSON.stringify({
          ok: false,
          refused: true,
          code: err.code || "error",
          error: err.message,
          detail: err.detail || null,
        }) + "\n",
      );
      process.exit(err.exitCode || 2);
    });
}
