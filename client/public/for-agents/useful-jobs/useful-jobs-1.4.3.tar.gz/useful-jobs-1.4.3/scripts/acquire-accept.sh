#!/usr/bin/env bash
# Fresh-directory HTTP acquire + unpack + README path smoke for useful-jobs.
# Literal acquire AND documented next command run in the SAME shell (no stdout contamination).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ARCHIVE="${1:-}"
PIN_JSON="${2:-}"
PORT="${ACQUIRE_PORT:-8765}"

if [[ -z "$ARCHIVE" || -z "$PIN_JSON" ]]; then
  echo "usage: acquire-accept.sh <archive.tar.gz> <sha256.json>" >&2
  exit 2
fi

ARCHIVE="$(cd "$(dirname "$ARCHIVE")" && pwd)/$(basename "$ARCHIVE")"
PIN_JSON="$(cd "$(dirname "$PIN_JSON")" && pwd)/$(basename "$PIN_JSON")"

EXPECTED_SHA=$(node -e "const j=require(process.argv[1]); process.stdout.write(j.sha256)" "$PIN_JSON")
EXPECTED_BYTES=$(node -e "const j=require(process.argv[1]); process.stdout.write(String(j.bytes))" "$PIN_JSON")
NAME=$(basename "$ARCHIVE")

WORKDIR=$(mktemp -d /tmp/useful-jobs-acquire-XXXXXX)
SERVE_LOG="$WORKDIR/serve.json"
cd "$WORKDIR"

# Start local HTTP server from a path unrelated to the acquire cwd.
node "$ROOT/scripts/http-serve-archive.mjs" "$ARCHIVE" "$PORT" >"$SERVE_LOG" &
SERVER_PID=$!
cleanup() {
  kill "$SERVER_PID" 2>/dev/null || true
}
trap cleanup EXIT
sleep 0.3
URL=$(node -e "const j=JSON.parse(require('fs').readFileSync(process.argv[1],'utf8')); process.stdout.write(j.url)" "$SERVE_LOG")

# Same-shell: acquire then immediately verify + next documented command.
# Fail closed on download failure (sh/bash conditional).
if ! curl -fsSL "$URL" -o "$NAME"; then
  echo "download-failed" >&2
  exit 3
fi
ACTUAL_BYTES=$(wc -c <"$NAME" | tr -d ' ')
if [[ "$ACTUAL_BYTES" != "$EXPECTED_BYTES" ]]; then
  echo "byte-mismatch expected=$EXPECTED_BYTES actual=$ACTUAL_BYTES" >&2
  exit 4
fi
echo "${EXPECTED_SHA}  ${NAME}" | sha256sum -c -
tar -xzf "$NAME"
PKG_DIR=$(find . -maxdepth 1 -type d -name 'useful-jobs-*' | head -n 1)
cd "$PKG_DIR"

# Documented next command from README (same shell after acquire).
node -v
node bin/useful-jobs.mjs list
node bin/useful-jobs.mjs list --json >/dev/null
node bin/useful-jobs.mjs help >/dev/null

# Each of six caller paths (explicit --example only for samples).
for job in api-upgrade-brief vendor-budget-impact feed-agenda evidence-ci-annotation listing-repair-packet repeat-job-record; do
  node bin/useful-jobs.mjs run "$job" --example >/dev/null
done

# Missing inputs refuse.
set +e
node bin/useful-jobs.mjs run api-upgrade-brief >/tmp/uj-miss.out 2>/tmp/uj-miss.err
MISS=$?
set -e
test "$MISS" -eq 2

# Owning tests + accept from unpacked tree (no source substitution).
npm test
npm run accept

echo "ACQUIRE_ACCEPT_OK workdir=$WORKDIR pkg=$PKG_DIR"
