#!/usr/bin/env node
/**
 * Build the portable useful-jobs release archive from the allowlist.
 * Verifies nested vendor pins before packing. No network.
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { ROOT, assertArchivePins, writeJson } from "../lib/common.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, "package.json"), "utf8"));
const outDir = path.join(ROOT, "dist");
const stageName = `${pkg.name}-${pkg.version}`;
const stage = path.join(outDir, stageName);
const archivePath = path.join(outDir, `${stageName}.tar.gz`);

assertArchivePins();

const include = [
  "bin",
  "apps",
  "engines",
  "lib",
  "samples",
  "vendor-pins",
  "docs",
  "licenses",
  "test",
  "scripts/accept-all.mjs",
  "scripts/resource-sample.mjs",
  "scripts/build-archive.mjs",
  "scripts/http-serve-archive.mjs",
  "catalog.json",
  "jobs-outcomes.json",
  "package.json",
  "README.md",
  "LICENSE",
  "NOTICE",
  "PACKAGING-ALLOWLIST.txt",
  "scripts/acquire-accept.sh",
];

fs.rmSync(outDir, { recursive: true, force: true });
fs.mkdirSync(stage, { recursive: true });

function copyPath(rel) {
  const src = path.join(ROOT, rel);
  const dst = path.join(stage, rel);
  if (!fs.existsSync(src)) throw new Error(`missing allowlisted path ${rel}`);
  fs.mkdirSync(path.dirname(dst), { recursive: true });
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    fs.cpSync(src, dst, {
      recursive: true,
      filter: (p) => {
        const base = path.basename(p);
        if (base === "node_modules" || base === "out" || base === ".git") return false;
        if (base.startsWith("RESULT")) return false;
        if (base === "DESIGN.md") return false;
        if (base === "receipts") return false;
        return true;
      },
    });
  } else {
    fs.copyFileSync(src, dst);
  }
}

for (const rel of include) copyPath(rel);

// Exclude capacity receipts if any slipped into scripts copy of parent receipts
const receiptsInStage = path.join(stage, "receipts");
if (fs.existsSync(receiptsInStage)) fs.rmSync(receiptsInStage, { recursive: true, force: true });

const tar = spawnSync(
  "tar",
  ["-czf", archivePath, "-C", outDir, stageName],
  { encoding: "utf8" },
);
if (tar.status !== 0) throw new Error(`tar failed: ${tar.stderr}`);

const bytes = fs.statSync(archivePath).size;
const sha256 = createHash("sha256").update(fs.readFileSync(archivePath)).digest("hex");
const pin = {
  schema: "useful-jobs.release-archive.v1",
  name: stageName,
  archive: path.basename(archivePath),
  bytes,
  sha256,
  node: ">=22",
  builtAt: new Date().toISOString(),
  nestedPinsVerified: true,
};
writeJson(path.join(outDir, `${stageName}.sha256.json`), pin);
writeJson(path.join(ROOT, "receipts/capacity/archive-pin.json"), pin);
const releaseDir = path.join(ROOT, "release");
fs.mkdirSync(releaseDir, { recursive: true });
fs.copyFileSync(archivePath, path.join(releaseDir, path.basename(archivePath)));
writeJson(path.join(releaseDir, `${stageName}.sha256.json`), pin);
process.stdout.write(`${JSON.stringify({ ok: true, ...pin, path: archivePath }, null, 2)}\n`);
