#!/usr/bin/env node
import fs from "node:fs";
import { execSync } from "node:child_process";

function meminfo() {
  const text = fs.readFileSync("/proc/meminfo", "utf8");
  const get = (k) => Number(text.match(new RegExp(`^${k}:\\s+(\\d+)`, "m"))[1]);
  return {
    MemTotal_kB: get("MemTotal"),
    MemAvailable_kB: get("MemAvailable"),
    MemFree_kB: get("MemFree"),
  };
}

function disk() {
  const line = execSync("df -B1 --output=size,avail,pcent /", { encoding: "utf8" })
    .trim()
    .split("\n")[1]
    .trim()
    .split(/\s+/);
  return { size: Number(line[0]), avail: Number(line[1]), usedPct: line[2] };
}

function psi(kind) {
  try {
    return fs.readFileSync(`/proc/pressure/${kind}`, "utf8").trim();
  } catch {
    return null;
  }
}

function cgroup() {
  const read = (p) => {
    try {
      return fs.readFileSync(p, "utf8").trim();
    } catch {
      return null;
    }
  };
  return {
    memory_current: read("/sys/fs/cgroup/memory.current"),
    memory_max: read("/sys/fs/cgroup/memory.max"),
    cpu_max: read("/sys/fs/cgroup/cpu.max"),
  };
}

const mem = meminfo();
const d = disk();
const parallelNodeAcceptanceJobs = Number(process.argv[3] || 0);
const sample = {
  at: new Date().toISOString(),
  phase: process.argv[2] || "sample",
  workloadClass: "parallel_node_acceptance_jobs",
  parallelNodeAcceptanceJobs,
  // Desired/planned concurrency is not measurement; keep explicit.
  desiredConcurrencyHint: parallelNodeAcceptanceJobs,
  nativeModelChildIdentities: "unmeasured",
  nativeModelConcurrency: "unmeasured",
  mem,
  memAvailablePct: Number(((100 * mem.MemAvailable_kB) / mem.MemTotal_kB).toFixed(2)),
  disk: d,
  diskFreePct: Number(((100 * d.avail) / d.size).toFixed(2)),
  cgroup: cgroup(),
  psi_memory: psi("memory"),
  psi_cpu: psi("cpu"),
  cpuCount: Number(execSync("nproc", { encoding: "utf8" }).trim()),
  reserve: { memFloorPct: 25, diskFloorPct: 20 },
  cloudVMs: 1,
  admitNew: null,
};
sample.admitNew = sample.memAvailablePct >= 25 && sample.diskFreePct >= 20;
process.stdout.write(`${JSON.stringify(sample)}\n`);
