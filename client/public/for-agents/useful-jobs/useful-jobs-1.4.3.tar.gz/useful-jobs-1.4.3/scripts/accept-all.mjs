#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { ROOT, assertArchivePins, fixture, writeJson } from "../lib/common.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const LEDGER = path.join(ROOT, "receipts/CAPACITY-LEDGER.jsonl");
const RESULTS = path.join(ROOT, "receipts/CAPACITY-RESULTS.json");

function appendLedger(row) {
  fs.mkdirSync(path.dirname(LEDGER), { recursive: true });
  fs.appendFileSync(LEDGER, `${JSON.stringify(row)}\n`);
}

function sample(phase, parallelNodeAcceptanceJobs) {
  const r = spawnSync(
    process.execPath,
    [path.join(HERE, "resource-sample.mjs"), phase, String(parallelNodeAcceptanceJobs)],
    { encoding: "utf8" },
  );
  if (r.status !== 0) throw new Error(`resource-sample failed: ${r.stderr}`);
  const j = JSON.parse(r.stdout.trim());
  appendLedger({ event: "resource_sample", ...j });
  if (!j.admitNew) appendLedger({ event: "admit_stop", reason: "reserve", phase, sample: j });
  return j;
}

function runOne(rel, args) {
  return new Promise((resolve) => {
    const started = Date.now();
    const p = spawn(process.execPath, [path.join(ROOT, rel), ...args], {
      stdio: ["ignore", "pipe", "pipe"],
    });
    let out = "";
    let err = "";
    p.stdout.on("data", (d) => {
      out += d;
    });
    p.stderr.on("data", (d) => {
      err += d;
    });
    p.on("close", (code) => {
      resolve({
        rel,
        status: code,
        stdout: out.trim(),
        stderr: err.trim(),
        ms: Date.now() - started,
        pid: p.pid,
      });
    });
  });
}

/**
 * Run jobs with a real concurrency ceiling. Observed parallel count is the
 * number of simultaneously active Node acceptance children, never a desired target.
 */
async function runPool(jobs, maxParallel) {
  const queue = jobs.map((j, i) => ({ rel: j[0], args: j[1], index: i }));
  const done = new Array(jobs.length);
  let cursor = 0;
  let active = 0;
  let peakParallel = 0;
  const activeChildIdentities = [];
  const waveStarted = Date.now();

  await new Promise((resolve, reject) => {
    const launch = () => {
      while (active < maxParallel && cursor < queue.length) {
        const job = queue[cursor++];
        active += 1;
        peakParallel = Math.max(peakParallel, active);
        const child = {
          index: job.index,
          rel: job.rel,
          startedAt: new Date().toISOString(),
          finishedAt: null,
          pid: null,
        };
        activeChildIdentities.push(child);
        runOne(job.rel, job.args)
          .then((result) => {
            child.finishedAt = new Date().toISOString();
            child.pid = result.pid;
            child.exitStatus = result.status;
            done[job.index] = result;
            active -= 1;
            if (done.filter(Boolean).length === queue.length) resolve();
            else launch();
          })
          .catch(reject);
      }
    };
    if (!queue.length) resolve();
    else launch();
  });

  return {
    done,
    peakParallel,
    activeChildIdentities,
    ms: Date.now() - waveStarted,
  };
}

assertArchivePins();

// Preserve S233 raw ledger bytes as dated rejected evidence (do not rewrite observations).
const rejectedPath = path.join(ROOT, "receipts/CAPACITY-LEDGER-20260910-s233-rejected.jsonl");
if (fs.existsSync(LEDGER) && !fs.existsSync(rejectedPath)) {
  fs.copyFileSync(LEDGER, rejectedPath);
}
fs.writeFileSync(LEDGER, "");

appendLedger({
  event: "accept_start",
  at: new Date().toISOString(),
  heavyParentId: null,
  implementer: "cursor-agent",
  workloadClass: "parallel_node_acceptance_jobs",
  note: "Node acceptance concurrency meter only. Native Cursor Task child meter is receipts/capacity/child-sessions.json (distinct). No Grok Heavy.",
});

let res = sample("accept_start", 0);
if (!res.admitNew) {
  console.error(JSON.stringify({ ok: false, reason: "reserve_at_start", sample: res }));
  process.exit(2);
}

const outRoot = path.join(ROOT, "receipts/accept-out");
fs.rmSync(outRoot, { recursive: true, force: true });
fs.mkdirSync(outRoot, { recursive: true });

const jobs = [
  ["apps/api-upgrade-brief/cli.mjs", ["--before", fixture("openapi/a/before.yaml"), "--after", fixture("openapi/a/after.yaml"), "--used", fixture("openapi/a/used.json"), "--out-dir", path.join(outRoot, "api-a")]],
  ["apps/api-upgrade-brief/cli.mjs", ["--before", fixture("openapi/b/before.yaml"), "--after", fixture("openapi/b/after.yaml"), "--used", fixture("openapi/b/used.json"), "--out-dir", path.join(outRoot, "api-b")]],
  ["apps/vendor-budget-impact/cli.mjs", ["--before", fixture("pricing/a/before.json"), "--after", fixture("pricing/a/after.json"), "--out-dir", path.join(outRoot, "budget-a")]],
  ["apps/vendor-budget-impact/cli.mjs", ["--before", fixture("pricing/b/before.json"), "--after", fixture("pricing/b/after.json"), "--out-dir", path.join(outRoot, "budget-b")]],
  ["apps/feed-agenda/cli.mjs", ["--before", fixture("feed/a/before.xml"), "--after", fixture("feed/a/after.xml"), "--out-dir", path.join(outRoot, "agenda-a")]],
  ["apps/feed-agenda/cli.mjs", ["--before", fixture("feed/b/before.xml"), "--after", fixture("feed/b/after.xml"), "--out-dir", path.join(outRoot, "agenda-b")]],
  ["apps/evidence-ci-annotation/cli.mjs", ["--input", fixture("evidence/caller-a.json"), "--out-dir", path.join(outRoot, "ev-a")]],
  ["apps/evidence-ci-annotation/cli.mjs", ["--input", fixture("evidence/caller-b.json"), "--out-dir", path.join(outRoot, "ev-b")]],
  ["apps/listing-repair-packet/cli.mjs", ["--input", fixture("listing/caller-alpha.json"), "--out-dir", path.join(outRoot, "list-a")]],
  ["apps/listing-repair-packet/cli.mjs", ["--input", fixture("listing/partial.json"), "--out-dir", path.join(outRoot, "list-b")]],
  ["apps/repeat-job-record/cli.mjs", ["--next-run", fixture("repeat/a/next-run.json"), "--out-dir", path.join(outRoot, "rep-a")]],
  ["apps/repeat-job-record/cli.mjs", ["--next-run", fixture("repeat/b/next-run.json"), "--out-dir", path.join(outRoot, "rep-b")]],
];

const cpuCount = Number(spawnSync("nproc", { encoding: "utf8" }).stdout.trim() || "1");
// Real operating point: min(cpu, job count). Do not manufacture idle children for 6/12/18/24 targets.
const operatingPoint = Math.max(1, Math.min(cpuCount, jobs.length, 4));

const admit = sample("admit_pool", operatingPoint);
if (!admit.admitNew) {
  console.error(JSON.stringify({ ok: false, stoppedAt: "admit_pool", admit }));
  process.exit(2);
}

appendLedger({
  event: "wave_start",
  label: "node_acceptance_pool",
  workloadClass: "parallel_node_acceptance_jobs",
  desiredConcurrencyHint: operatingPoint,
  jobs: jobs.length,
  at: new Date().toISOString(),
});

sample(`mid_pool`, operatingPoint);
const wave = await runPool(jobs, operatingPoint);
sample(`complete_pool`, 0);

appendLedger({
  event: "wave_complete",
  label: "node_acceptance_pool",
  workloadClass: "parallel_node_acceptance_jobs",
  observedPeakParallelNodeAcceptanceJobs: wave.peakParallel,
  jobs: jobs.length,
  ms: wave.ms,
  failed: wave.done.filter((d) => d.status !== 0).length,
  activeChildIdentities: wave.activeChildIdentities,
});

const all = wave.done;
fs.writeFileSync(
  path.join(ROOT, "receipts/ACCEPT-RESULTS.json"),
  `${JSON.stringify({ at: new Date().toISOString(), results: all }, null, 2)}\n`,
);
const failed = all.filter((d) => d.status !== 0);

const capacityResults = {
  schema: "s242.capacity-results.v1",
  at: new Date().toISOString(),
  workloadClass: "parallel_node_acceptance_jobs",
  jobsAccepted: all.length - failed.length,
  jobsFailed: failed.length,
  operatingPointHint: operatingPoint,
  observedPeakParallelNodeAcceptanceJobs: wave.peakParallel,
  activeChildIdentities: wave.activeChildIdentities,
  startFinishOverlap: wave.activeChildIdentities.map((c) => ({
    index: c.index,
    rel: c.rel,
    pid: c.pid,
    startedAt: c.startedAt,
    finishedAt: c.finishedAt,
  })),
  nativeModelChildIdentities: "receipts/capacity/child-sessions.json",
  nativeModelConcurrency: "measured-separately-in-child-sessions",
  nativeCursorTaskChildrenMeter: "receipts/capacity/child-overlap.json",
  rejectedPriorLedger: "receipts/CAPACITY-LEDGER-20260910-s233-rejected.jsonl",
  note: "Node acceptance peak is observedPeakParallelNodeAcceptanceJobs only. Native Cursor Task child IDs/overlap live under receipts/capacity/child-*.json and are not this Node pool.",
};

writeJson(RESULTS, capacityResults);

appendLedger({
  event: "accept_finished",
  accepted: all.length - failed.length,
  failed: failed.length,
  workloadClass: "parallel_node_acceptance_jobs",
  observedPeakParallelNodeAcceptanceJobs: wave.peakParallel,
  nativeModelConcurrency: "measured-separately-in-child-sessions",
});

if (failed.length) {
  console.error(JSON.stringify({ ok: false, failed, capacityResults }, null, 2));
  process.exit(1);
}
console.log(
  JSON.stringify(
    {
      ok: true,
      accepted: all.length,
      workloadClass: "parallel_node_acceptance_jobs",
      observedPeakParallelNodeAcceptanceJobs: wave.peakParallel,
      nativeModelConcurrency: "measured-separately-in-child-sessions",
      nativeCursorTaskChildrenMeter: "receipts/capacity/child-overlap.json",
    },
    null,
    2,
  ),
);
