#!/usr/bin/env node
/** Tiny local-only static file server for archive acquire tests. */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const fileArg = process.argv[2];
const port = Number(process.argv[3] || 8765);
if (!fileArg) {
  console.error("usage: http-serve-archive.mjs <file> [port]");
  process.exit(2);
}
const filePath = path.resolve(fileArg);
const data = fs.readFileSync(filePath);
const name = path.basename(filePath);
const server = http.createServer((req, res) => {
  if (req.url === `/${name}` || req.url === "/") {
    res.writeHead(200, {
      "content-type": "application/gzip",
      "content-length": data.length,
      "content-disposition": `attachment; filename="${name}"`,
    });
    res.end(data);
    return;
  }
  res.writeHead(404);
  res.end("not found");
});
server.listen(port, "127.0.0.1", () => {
  process.stdout.write(
    JSON.stringify({ ok: true, url: `http://127.0.0.1:${port}/${name}`, bytes: data.length }) + "\n",
  );
});
