# SAMPLE

Labeled fixture for Repeat Job Record caller-alpha.

Not a customer run. Not demand proof. Family: `pricing-row-unit`.
Use with:

```bash
node bin/useful-jobs.mjs run repeat-job-record \
  --next-run samples/repeat/caller-alpha/next-run.json \
  --out-dir ./out/repeat-alpha
```
