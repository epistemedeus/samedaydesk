# SAMPLE

Labeled fixture for Repeat Job Record caller-beta.

Not a customer run. Not demand proof. Family: `openapi-used-ops`.
Use with:

```bash
node bin/useful-jobs.mjs run repeat-job-record \
  --next-run samples/repeat/caller-beta/next-run.json \
  --out-dir ./out/repeat-beta
```
