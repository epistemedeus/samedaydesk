# useful-jobs

Offline wrappers that turn released SameDayDesk and consumer evidence/repeat
kits into six caller-facing jobs. Run them locally on your own files. No
purchase authority, no network requirement for the default path, and no
scheduler daemon.

## Requirements

- Node.js 22 or newer
- Offline local filesystem access to your inputs

## Install (offline)

From a release archive (after you unpack it):

```bash
cd useful-jobs-1.0.0
node -v   # expect v22+
node bin/useful-jobs.mjs list
```

Pinned nested archives under `vendor-pins/` are verified by sha256/size before
use. Exact pins are in `vendor-pins/PIN.json`.

## List jobs

```bash
node bin/useful-jobs.mjs list
node bin/useful-jobs.mjs list --json
node bin/useful-jobs.mjs help api-upgrade-brief
```

## Run a job

Caller mode requires semantic inputs. Missing inputs refuse closed. Labeled
samples require an explicit `--example` flag.

```bash
# Labeled sample (not a customer run)
node bin/useful-jobs.mjs run api-upgrade-brief --example

# Your files
node bin/useful-jobs.mjs run api-upgrade-brief \
  --before ./yours/before.yaml \
  --after ./yours/after.yaml \
  --used ./yours/used.json \
  --out-dir ./out/api-upgrade
```

Default outputs land in a fresh unique directory under `out/<job>/` when
`--out-dir` is omitted. Source paths cannot be reused as the output scope.

## The six jobs

| Job id | Required inputs | Outputs |
| --- | --- | --- |
| `api-upgrade-brief` | `--before --after --used` | `upgrade-brief.{json,md}` |
| `vendor-budget-impact` | `--before --after` | `budget-impact.{json,md}` |
| `feed-agenda` | `--before --after` | `agenda.{json,ics}` |
| `evidence-ci-annotation` | `--input` | `annotations.{json,md}` |
| `listing-repair-packet` | `--input` | `repair-packet.{json,md}` |
| `repeat-job-record` | `--next-run` | `repeat-job.{json,md}` |

Machine catalog: `catalog.json`. Concrete job outcomes: `jobs-outcomes.json`.
Per-job caller guides: `apps/<job>/CALLER.md`.

## Honesty rules

- Samples under `samples/` and `--example` are labeled fixtures, not customers.
- Evidence CI annotations from caller-supplied schema-compatible packets stay
  **unattested** (useful annotations, not trusted kit action).
- Vendor conflicting/unknown evidence stays **partial** even without a known delta.
- Repeat job records verify local file bytes against declared digests. Mismatch
  refuses. Missing files produce an informational unverified record.
- No purchase, network, or background scheduler authority.

## Tests

```bash
npm test
npm run accept
```

## License

Pilot-authored wrappers and samples: MIT (`LICENSE`). Nested vendor archives
keep their original licenses (`NOTICE`, `licenses/vendor/`).
