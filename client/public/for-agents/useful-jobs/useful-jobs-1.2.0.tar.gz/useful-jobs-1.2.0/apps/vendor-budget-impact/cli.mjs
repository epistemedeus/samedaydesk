#!/usr/bin/env node
import path from "node:path";
import {
  assertArchivePins, recordRepeatBin, runNodeJson, writeJson, writeText, parseArgs, fixture, labelSample,
} from "../../lib/common.mjs";
import { envelope, digestObj } from "../../lib/artifact.mjs";
import { requireCallerInputs, resolveOutDir } from "../../lib/cli-runtime.mjs";

const APP = "vendor-budget-impact";
const OUTPUTS = ["budget-impact.json", "budget-impact.md"];

export function buildImpact(underlying, caller) {
  const outer = underlying?.report || underlying || {};
  const inner = outer.report || outer;
  const counts = inner.counts || {};
  const unitChanges = inner.unitChanges || [];
  const fieldChanges = inner.fieldChanges || [];
  const refused = underlying?.ok === false || inner.ok === false;
  const partial = (counts.conflicting || 0) > 0 || (counts.unknown || 0) > 0;
  const hasDelta =
    (counts.unitChanges || unitChanges.length) +
      (counts.fieldChanges || fieldChanges.length) +
      (counts.added || 0) +
      (counts.removed || 0) >
    0;
  // Incomplete/conflicting evidence stays partial even without a known delta.
  const status = refused ? "refused" : partial ? "partial" : hasDelta ? "actionable" : "informational";
  const actions = [];
  for (const u of unitChanges) {
    actions.push({
      priority: "high",
      kind: "normalize-unit-before-budgeting",
      fieldKey: u.fieldKey,
      beforeUnit: u.beforeUnit,
      afterUnit: u.afterUnit,
      note: "Unit label changed; do not compare numeric fields until units match. No purchase authorized.",
    });
  }
  for (const f of fieldChanges) {
    actions.push({
      priority: "medium",
      kind: "review-price-field",
      fieldKey: f.fieldKey || f.key,
      note: "Price/field delta in curated fixture rows - not a live quote.",
    });
  }
  if (!actions.length && !refused) {
    actions.push({
      priority: partial ? "high" : "low",
      kind: partial ? "resolve-conflicting-or-unknown-rows" : "no-budget-delta",
      note: partial
        ? "Conflicting/unknown pricing evidence present; impact is non-final even without a known delta"
        : "No field/unit deltas in curated rows",
    });
  }
  const art = envelope({
    appId: APP,
    status,
    summary: refused
      ? "Pricing compare refused"
      : `Budget-impact scan: fieldChanges=${counts.fieldChanges || fieldChanges.length} unitChanges=${counts.unitChanges || unitChanges.length} conflicting=${counts.conflicting || 0} unknown=${counts.unknown || 0}`,
    actions,
    gaps: partial ? ["conflicting or unknown pricing rows present; treat impact as non-final"] : [],
    underlying: { family: "pricing-row-unit", counts, ok: !refused },
    caller: labelSample(caller),
  });
  art.purchaseAuthority = false;
  art.digest = digestObj({ status: art.status, actions: art.actions, counts, caller: art.caller });
  return art;
}

export function toMarkdown(art) {
  const lines = [
    "# Vendor budget impact (no purchase authority)",
    "",
    `Status: **${art.status}**`,
    "",
    art.summary,
    "",
    "## Recommended reviews",
  ];
  for (const a of art.actions) {
    lines.push(`- (${a.priority}) ${a.kind}${a.fieldKey ? `: \`${a.fieldKey}\`` : ""} - ${a.note}`);
  }
  lines.push("", "_Curated fixture rows only. Not current market prices or customer demand._", "");
  return lines.join("\n");
}

export function run(args) {
  assertArchivePins();
  const mode = requireCallerInputs(args, ["before", "after"]);
  const exampleMode = mode.mode === "example";
  const before = exampleMode ? fixture("pricing/a/before.json") : args.before;
  const after = exampleMode ? fixture("pricing/a/after.json") : args.after;
  const outDir = resolveOutDir(APP, args, [before, after], OUTPUTS);
  const r = runNodeJson(recordRepeatBin(), [
    "run",
    "--family",
    "pricing-row-unit",
    "--before",
    before,
    "--after",
    after,
  ]);
  if (!r.json) throw new Error(`record-repeat failed: ${r.combined.slice(0, 800)}`);
  const art = buildImpact(r.json, {
    before,
    after,
    exampleMode,
    sampleLabel: exampleMode ? "explicit-example" : "caller-input",
  });
  writeJson(path.join(outDir, "budget-impact.json"), art);
  writeText(path.join(outDir, "budget-impact.md"), toMarkdown(art));
  art.outDir = outDir;
  return art;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    const art = run(parseArgs(process.argv.slice(2)));
    process.stdout.write(
      JSON.stringify({
        ok: true,
        appId: APP,
        status: art.status,
        digest: art.digest,
        outDir: art.outDir,
        purchaseAuthority: false,
      }) + "\n",
    );
  } catch (err) {
    process.stdout.write(
      JSON.stringify({
        ok: false,
        refused: true,
        code: err.code || "error",
        error: err.message,
        detail: err.detail || null,
      }) + "\n",
    );
    process.exit(err.exitCode || 2);
  }
}
