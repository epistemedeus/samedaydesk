# Vendor Budget Impact

Offline scan of curated pricing-row JSON (`before` vs `after`) for field and unit
deltas that may affect a vendor budget. This job never authorizes a purchase.

## Required inputs

Caller mode requires both paths:

| Flag | Meaning |
| --- | --- |
| `--before` | Pricing-row snapshot JSON (earlier / baseline) |
| `--after` | Pricing-row snapshot JSON (later / candidate) |

Missing either input refuses closed with `missing-required-inputs`.

Optional: `--out-dir <dir>` for a stable output folder. When omitted, a fresh
unique directory under `out/vendor-budget-impact/` is created. The output path
must not collide with an input path.

## Labeled example

```bash
node bin/useful-jobs.mjs run vendor-budget-impact --example
# or
node apps/vendor-budget-impact/cli.mjs --example
```

`--example` loads the packaged fixture under `samples/pricing/a/`. That run is a
labeled sample, not a customer or live-market quote.

## Your files

```bash
node bin/useful-jobs.mjs run vendor-budget-impact \
  --before ./yours/before.json \
  --after ./yours/after.json \
  --out-dir ./out/budget
```

Each input is a JSON object with a `rows` array. Every row needs at least
`field`, `value`, and `unit` (same shape as the packaged samples).

Additional labeled SAMPLE pairs (also not customers):

- `samples/pricing/caller-alpha/` - field-value delta only
- `samples/pricing/caller-beta/` - unit delta plus a different field delta

## Outputs

Written into the resolved `--out-dir` (or a fresh default directory):

| File | Contents |
| --- | --- |
| `budget-impact.json` | Machine artifact: status, actions, gaps, digest |
| `budget-impact.md` | Short human review of the same scan |

Stdout is a one-line JSON receipt (`ok`, `status`, `digest`, `outDir`,
`purchaseAuthority: false`).

## Honesty

- **No purchase authority.** Reviews are advisory only; `purchaseAuthority` is
  always false.
- **Conflicting or unknown** upstream pricing evidence keeps status **`partial`**
  even when no numeric delta is known. Treat that impact as non-final.
- Packaged paths under `samples/` and any `--example` run are **fixtures /
  SAMPLE labels**, not customers, demand, or live quotes.
- Curated row compares are not current market prices.
