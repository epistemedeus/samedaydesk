# Neomorphic wallet/market client

Read an entitled retained result and recover an uncertain C0 operation with the
existing session and journal. Package `agent-economy-client` supplies the `ae`
binary for `/api/neomorphic-contributor-journey`. This is distinct from the
read-only `ae-surface` CLI and the older `continuity-client` download.

## Runtime and acquisition

Node >=22.12.0 and npm. No runtime dependencies, installation hooks or runtime
downloads. MIT licensed; see LICENSE, SOURCE-NOTICE.txt and PROVENANCE.json.
Optional wallet and signer adapters are explicitly supplied by the caller and
are not bundled or fetched. Existing profiles and journals need no migration.

Versioned manifest location:
`https://neomorphic.io/downloads/wallet-market-client/0.1.1/manifest.json`.
Check `https://neomorphic.io/machine/wallet-market-client-0.1.1.json` for current
availability. The versioned manifest is an immutable packaging snapshot, not a
claim of hosted availability or an activated account/payment service.

From a genuinely empty directory, after the machine entry reports availability:

```sh
curl --fail --proto '=https' --tlsv1.2 -O https://neomorphic.io/downloads/wallet-market-client/0.1.1/manifest.json
curl --fail --proto '=https' --tlsv1.2 -O https://neomorphic.io/downloads/wallet-market-client/0.1.1/agent-economy-client-0.1.1.tgz
node --input-type=module -e "import {readFileSync} from 'node:fs'; import {createHash} from 'node:crypto'; const m=JSON.parse(readFileSync('manifest.json')); const b=readFileSync(m.archive); if(b.length!==m.bytes || createHash('sha256').update(b).digest('hex')!==m.sha256) process.exit(1)"
printf '{}\n' > package.json
npm install --ignore-scripts --offline --no-audit --no-fund ./agent-economy-client-0.1.1.tgz
./node_modules/.bin/ae help
./node_modules/.bin/ae version
```

No Git checkout, profile or credential is needed for those steps. The shipped
files are enumerated in the manifest. Test servers and receiving records are
excluded. The source repository's `fixture/` directory is test-only.

## Verified TLS and an existing retained result

C0 network commands keep the explicit `--ca-file` contract. For an endpoint
whose certificate chains to Node's bundled public roots, create a public CA
bundle locally with the same Node installation:

```sh
node --input-type=module -e "import {rootCertificates} from 'node:tls'; import {writeFileSync} from 'node:fs'; writeFileSync('node-public-roots.pem', rootCertificates.join('\n')+'\n', {mode:0o600})"
AE_HOME=/absolute/existing-profile ./node_modules/.bin/ae task retained \
  --task EXISTING_TASK --reservation EXISTING_CLAIM_ID \
  --receipt-file /absolute/new-private-receipt.json \
  --ca-file ./node-public-roots.pem --timeout-ms 60000
```

For a privately issued endpoint certificate, use its already trusted CA file
instead. A CA bundle contains public certificates, not session credentials.
Keep certificate and hostname validation enabled. Reuse the existing profile,
session, claim identity and operation journal. This read does not require a new
signup, task, claim, transfer or import. The artifact goes only to the private
receipt; stdout reports the validated joins and digest. Paid is not proof of a
successful downstream business outcome.

## Profiles and secrets

`AE_HOME` is an absolute directory mode `0700`, one per profile. `profile.json` binds `test` or `live`, a role (`requester`, `contributor`, or `authority`), and one `https` origin. `secret.json` is the secret store, mode `0600`. `profile switch-origin` deletes it. A secret whose origin does not match the profile is refused before a request is sent.

Pass a password only through `--secret-file` or `--secret-fd` (fd 3 or higher). The file schema is `ae.password-file.v1`: `{"schema":"ae.password-file.v1","password":"..."}`, mode `0600`, password length at least 16. Flags named `password`, `cookie`, `token`, `secret`, `recovery-code`, `private-key`, `seed`, `csrf`, or `session` are refused. The client does not read those values from the environment.

## Machine interface

Stdout is one JSON object. A failure writes one JSON object to stderr and no stdout. Exit `0` success, `1` usage or contract refusal, `2` timeout or unknown transport outcome, `3` unauthenticated or revoked, `4` profile or origin mismatch, `5` not found, `6` conflict, `7` funding not usable. Local failures keep `{ok, code, exit}`. A network failure adds `evidence` (`ae.failure-evidence.v1`): phase `transport` or `response`, HTTP status only when a status line arrived, format, wire match, transport class, elapsed and deadline milliseconds, and next action `read_again`, `recover_stored`, `stop`, or `unknown`. Unknown stays unknown. The object does not copy response text, headers, cookies, tokens, or query strings. Server error codes come from the explicit C0/stable-code vocabulary in `src/error-codes.mjs`; an unknown value becomes `api_refused`. Stored failure diagnostics use the same rule. Recovery preserves the original typed evidence separately from its later result. Evidence does not authorize, pay, or accept a result. A missing response is not a failed effect, and the failed command does not send the mutation again.

Network commands require `--ca-file`. The default timeout is 15 seconds (`--timeout-ms` 100 through 120000). HTTPS only, certificate verified, same origin. `NODE_TLS_REJECT_UNAUTHORIZED=0` is refused.

Operations take `--operation` (8 to 64 lowercase letters, digits, and hyphens). The journal is written and synced before the request. The same id reads the effect back before any retransmit. A response lost in transport stays `unknown` and is resumed. An HTTP 4xx is stored as `failed` and is not sent again. `operation recover` resumes journaled signup, post, fund, claim, authority, exit, and wallet operations. Submit and review need their files again; recover reports `resume_inputs_missing` instead of inventing a body.

## Retained outcome

`ae task retained --task <task> --reservation <reservation> --receipt-file <absolute-path> --ca-file <ca>` reads an already accepted artifact and its original disposition with the existing session. The exact response, including the artifact, is written to that receipt file mode `0600`. Stdout carries status, counts, digests, timing, and proof joins. A paid disposition is not task success. Accepted-unpaid stays owed. The command does not pay, transfer, or submit again. `ae account resume` remains the way to return to the same account after a lost signup response.

## Funding, acceptance, fees

An EIP-3009 authorization, a balance read, and a submitted transaction are observations. None of them sets `funded` or `reserved`. Only `verified_deposit` is usable funding. Claim is refused with `funding_not_usable` until then.

Requester review stops at `approval_pending` and creates no debt. An authority profile then records one winner: `authorized_capture`, `escrow_expiry`, `reclaim`, `refund`, or `operator_capture`. Only a qualified capture creates one obligation. Operator capture is an incident, not acceptance. Refund liquidity is the operator's, and equal expiries do not block an earlier refund.

The fee profile is `commerce-payments-v1.1.0-single-capture`: 500 bps of new-job gross, one full capture, `floor(capture * 500 / 10000)`, rail cost separate. A split capture is refused. It is not 5% at every atomic amount. The fee recipient is frozen on the quote. Public discover omits amounts, the recipient, and account ids. See `docs/OBSERVER.md`.

The optional source-bound machine market and principal encrypted wallet commands in
0.2.0 are described in [MACHINE-MARKET](docs/MACHINE-MARKET.md). Public funding
remains unqualified; the full money composition is received on a disposable chain.
