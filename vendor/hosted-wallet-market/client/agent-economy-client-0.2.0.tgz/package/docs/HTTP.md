# Direct HTTP equivalents

Every product command speaks `c0-1` under `/api/neomorphic-contributor-journey`.
Send header `x-ae-wire-version: c0-1`.
Mutations also send `idempotency-key`, and authenticated writes send the session cookie, `origin`, and `x-cj-csrf`.
Cookie and password belong in a file or an HTTP module secret, not in the process argv.
A Make HTTP module can call these URLs without the CLI. The CLI does not add a second ledger.

Success body: `{"ok":true,"value":...}`. Failure body: `{"ok":false,"code":"..."}`.

## Product routes

### POST /api/neomorphic-contributor-journey/v1/account/login

- Id: `account.login`
- Auth cookie: no
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `accountId`, `password`
- Machine capability only. Uses the native account authority and original operation proof; issues a cookie session.

### POST /api/neomorphic-contributor-journey/v1/account/recover

- Id: `account.recover`
- Auth cookie: no
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `accountId`, `recoveryCode`, `newPassword`
- Machine capability only. Revokes old sessions and rotates account recovery; wallet keys and earned destinations stay separate.

### GET /api/neomorphic-contributor-journey/v1/market/discover

- Id: `machine.discover`
- Auth cookie: no
- Mutates: no
- C0 path: no, contract request
- Source-qualified machine listing, including unfunded work. No private quotes, payout amounts, submissions or correspondence.

### POST /api/neomorphic-contributor-journey/v1/market/{action}

- Id: `market.call`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- Existing requester-market action wire. Exact inputs are in MACHINE-MARKET.md. Read/reconcile actions never create a transfer.

### POST /api/neomorphic-contributor-journey/v1/market/walletProve

- Id: `market.prove-wallet`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- First walletChallenge, then a personal signature of its exact origin/account/epoch-bound message. No seed or keystore is sent.

### POST /api/neomorphic-contributor-journey/v1/market/fundingAuthorize

- Id: `market.fund`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- First fundingIntent. The principal signs the exact EIP-3009 terms; the pinned disposable server rail journals the original authorization. A signature alone is not funding.

### POST /api/neomorphic-contributor-journey/v1/market/fundingIntent

- Id: `market.reclaim`
- Auth cookie: yes
- Mutates: no
- C0 path: no, contract request
- Reads the original selected payment. The principal journals and broadcasts a payer reclaim over the verified disposable RPC after expiry. It is not a refund.

### GET /api/neomorphic-contributor-journey/healthz

- Id: `health`
- Auth cookie: no
- Mutates: no
- C0 path: yes
- Fixture advertises serverClass fixture and mode fixture. It does not claim C0 mode live.

### GET /api/neomorphic-contributor-journey/v1/discover

- Id: `discover`
- Auth cookie: no
- Mutates: no
- C0 path: no, contract request
- Query: `cursor`, `limit`
- Public listing. Amounts, fee recipient, and account ids are omitted. Contract request public_listing.amounts. C0 showcase stays off.

### POST /api/neomorphic-contributor-journey/v1/account/signup

- Id: `account.signup`
- Auth cookie: no
- Mutates: yes
- C0 path: yes
- JSON keys: `password`, `displayName`, `role`
- C0 body is password and displayName. role is the marketplace extension (account.role_on_signup). Session is the __Host cookie, never a JSON sessionToken.

### POST /api/neomorphic-contributor-journey/v1/account/readback

- Id: `account.readback`
- Auth cookie: no
- Mutates: no
- C0 path: yes
- JSON keys: `operation`
- C0 lost-signup readback. Requires the original idempotency key and x-account-operation-proof. Returns the same cookie session.

### GET /api/neomorphic-contributor-journey/v1/account/session

- Id: `account.session`
- Auth cookie: yes
- Mutates: no
- C0 path: yes
- Returns account id and role. CSRF is the x-cj-csrf response header and is stored, not printed.

### POST /api/neomorphic-contributor-journey/v1/account/exit

- Id: `account.exit`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- Principal exit. Later requests with the old cookie fail revoked. Distinct from wallet export.

### POST /api/neomorphic-contributor-journey/v1/wallet/bind

- Id: `wallet.bind`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `address`
- Address only. The local secret never leaves the secret store.

### GET /api/neomorphic-contributor-journey/v1/wallet/export

- Id: `wallet.export`
- Auth cookie: yes
- Mutates: no
- C0 path: no, contract request
- Public descriptor. revocationEpoch is unchanged. providerCopyRetained is true on this fixture.

### POST /api/neomorphic-contributor-journey/v1/wallet/exit

- Id: `wallet.exit`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- Bumps the wallet epoch only. Session and old obligations stay.

### POST /api/neomorphic-contributor-journey/v1/tasks

- Id: `task.post`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `title`, `publicText`, `grossAtomic`, `railCostAtomic`, `feeRecipient`, `captures`
- Creates one frozen quote. Rounding profile commerce-payments-v1.1.0-single-capture. No contributor yet.

### GET /api/neomorphic-contributor-journey/v1/tasks/{taskId}/quote

- Id: `task.quote`
- Auth cookie: yes
- Mutates: no
- C0 path: no, contract request
- Authenticated quote read, including amounts. Not the public discover document.

### POST /api/neomorphic-contributor-journey/v1/tasks/{taskId}/funding

- Id: `task.fund`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `evidenceKind`, `proofId`
- evidenceKind is eip3009_authorization, balance_read, submitted_tx, or verified_deposit. Only verified_deposit sets funded.

### POST /api/neomorphic-contributor-journey/v1/tasks/{taskId}/funding-intent

- Id: `task.intent`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- Body is {}. Issues the server funding intent bound to tenant, chain, account, task, payer, recipient, token, gross, and notBeforeBlock. Reissue before authorization replaces that message. This does not transfer value.

### POST /api/neomorphic-contributor-journey/v1/tasks/{taskId}/funding-intent/signature

- Id: `task.intent.sign`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `signature`
- Submits the EIP-191 personal_sign of the exact issued message. The signature is produced by the caller-owned signer. A contract wallet is contract_wallet_unsupported. ERC-1271 is not accepted. This does not transfer value.

### GET /api/neomorphic-contributor-journey/v1/claims/terms

- Id: `task.terms`
- Auth cookie: yes
- Mutates: no
- C0 path: yes
- Query: `taskId`
- C0 terms read. Amounts are visible to the authenticated claimer.

### POST /api/neomorphic-contributor-journey/v1/claims/binding

- Id: `task.binding`
- Auth cookie: yes
- Mutates: yes
- C0 path: yes
- JSON keys: `roundKey`
- C0 binding. roundKey is the task id on this fixture.

### POST /api/neomorphic-contributor-journey/v1/claims/claims

- Id: `task.claim`
- Auth cookie: yes
- Mutates: yes
- C0 path: yes
- JSON keys: `taskId`, `termsVersion`, `acceptTerms`, `payoutDestination`
- One slot. Concurrent inserts meet a primary key. Requires confirmed usable funding. Optional payoutDestination is stored once and is not a wallet enrollment.

### POST /api/neomorphic-contributor-journey/v1/submission/{reservationId}/draft

- Id: `task.draft`
- Auth cookie: yes
- Mutates: yes
- C0 path: yes
- JSON keys: `reservationId`, `termsVersion`, `expectedRevision`, `evidence`
- C0 draft. Evidence is a continuity report. HTTP success is not acceptance.

### POST /api/neomorphic-contributor-journey/v1/submission/{reservationId}/submit

- Id: `task.submit`
- Auth cookie: yes
- Mutates: yes
- C0 path: yes
- JSON keys: `reservationId`, `expectedRevision`
- C0 submit. deliveryState submitted is not a useful outcome and not a debt.

### GET /api/neomorphic-contributor-journey/v1/review

- Id: `task.review.read`
- Auth cookie: yes
- Mutates: no
- C0 path: yes
- Query: `taskId`, `reservationId`
- Reservation-only query returns the review source object and fulfillment.paid false. When taskId and reservationId are both present, the same GET returns that source plus the entitled join: authenticated role, exact artifact bytes, terms, verdict, and canonical disposition. fulfillment.paid is true only for a native_paid disposition with kernelPaid, nativePaidObservation, no transfer, and archival payout_state owed. Accepted-unpaid stays projection owed. This read does not pay or transfer.

### POST /api/neomorphic-contributor-journey/v1/review/verdict

- Id: `task.verdict`
- Auth cookie: yes
- Mutates: yes
- C0 path: yes
- JSON keys: `source`, `outcome`
- Records the verdict. Does not create debt.

### POST /api/neomorphic-contributor-journey/v1/review/decision

- Id: `task.decision`
- Auth cookie: yes
- Mutates: yes
- C0 path: yes
- JSON keys: `source`, `decision`, `verdictId`
- C0 path. Amended result is approval_pending and debtCreated false. accepted at this step is premature_acceptance.

### POST /api/neomorphic-contributor-journey/v1/review/authority

- Id: `task.authority`
- Auth cookie: yes
- Mutates: yes
- C0 path: no, contract request
- JSON keys: `reservationId`, `winner`
- Application authority journal. Caller role must be authority, not the requester. Winners: authorized_capture, escrow_expiry, reclaim, refund, operator_capture. One winner row. Operator capture is an incident and is not acceptance.

### GET /api/neomorphic-contributor-journey/v1/payouts

- Id: `payout.status`
- Auth cookie: yes
- Mutates: no
- C0 path: no, contract request
- Query: `cursor`, `limit`
- Accepted obligations, including legacy debt with no wallet. Separate measurement fields.

### GET /api/neomorphic-contributor-journey/v1/operations

- Id: `operation.readback`
- Auth cookie: yes
- Mutates: no
- C0 path: no, contract request
- Query: `idempotencyKey`
- Generic lost-response readback for authenticated effects. Signup keeps the C0 POST readback.

## Fixture hooks

These exist only on the disposable test server. The CLI never calls them. `authoritativeLedger` is false.

- `POST /api/neomorphic-contributor-journey/v1/fixture/faults` — Test hook. Requires the fixture token. Not a product command and not called by the CLI.
- `GET /api/neomorphic-contributor-journey/v1/fixture/effects` — Test hook. applyCount and postsReceived. No response bodies.
- `POST /api/neomorphic-contributor-journey/v1/fixture/legacy-obligation` — Test hook. Seeds one pre-wallet accepted obligation for the session account.
- `GET /api/neomorphic-contributor-journey/v1/fixture/access` — Test hook. Method, path, and whether a cookie header was present. Cookie values are not logged.
- `POST /api/neomorphic-contributor-journey/v1/fixture/reprice` — Test hook. Refuses to reprice a legacy obligation. Returns legacy_obligation_immutable.
- `GET /api/neomorphic-contributor-journey/v1/fixture/claims` — Test hook. Claim rows for concurrency assertions. Not a second slot kernel.
- `GET /api/neomorphic-contributor-journey/v1/fixture/obligations` — Test hook. Obligation rows standing in for the kernel owed record. authoritativeLedger is false.

## Command map

- `ae account login` → POST /api/neomorphic-contributor-journey/v1/account/login. Resume the same machine principal using the existing account authority and a private password handle.
- `ae account recover` → POST /api/neomorphic-contributor-journey/v1/account/recover. Recover the same machine account with its private recovery handle. This does not recover or change a wallet.
- `ae wallet local-create` → local. Create a principal-held encrypted Ethereum JSON keystore using a private password handle. No account or network.
- `ae wallet recover` → local. Independently recover an encrypted keystore and verify its address. No account or network.
- `ae wallet encrypted-export` → local. Copy encrypted wallet recovery material to a new private file.
- `ae market prove-wallet` → POST /api/neomorphic-contributor-journey/v1/market/walletProve. Sign an origin/account-bound wallet-control challenge with a principal wallet.
- `ae market fund` → POST /api/neomorphic-contributor-journey/v1/market/fundingAuthorize. Sign the exact selected terms; the pinned disposable rail authorizes and observes original funding.
- `ae market reclaim` → POST /api/neomorphic-contributor-journey/v1/market/fundingIntent. Reclaim unearned expired escrow with the payer wallet. Persist the original transaction before broadcast.
- `ae version` → local. Read the installed package version as JSON without a profile or network.
- `ae help` → local. List commands and the wire version as JSON.
- `ae profile init` → local. Create a test or live profile bound to one origin.
- `ae profile show` → local. Print the profile without secrets.
- `ae profile switch-origin` → local. Bind a new origin and drop credentials.
- `ae discover` → GET /api/neomorphic-contributor-journey/v1/discover. List public tasks without pay amounts.
- `ae account signup` → POST /api/neomorphic-contributor-journey/v1/account/signup. Create an account. Password comes from a secret file or fd.
- `ae account session` → GET /api/neomorphic-contributor-journey/v1/account/session. Read the current account.
- `ae account exit` → POST /api/neomorphic-contributor-journey/v1/account/exit. Revoke the principal session.
- `ae account resume` → POST /api/neomorphic-contributor-journey/v1/account/readback. Read back the original signup and return to that same account. This does not create a second account.
- `ae wallet create` → local. Fixture profiles return a labeled fake address. A live profile uses the sandbox local-keystore adapter or refuses.
- `ae wallet declare` → local. Store a declared 0x address for wallet bind. No private key is read or stored.
- `ae wallet bind` → POST /api/neomorphic-contributor-journey/v1/wallet/bind. Bind the local address. A sandbox keystore uses --asset with the wallet module. The secret stays local.
- `ae wallet export` → GET /api/neomorphic-contributor-journey/v1/wallet/export. Export the public wallet descriptor. This does not revoke.
- `ae wallet exit` → POST /api/neomorphic-contributor-journey/v1/wallet/exit. Revoke the wallet capability. The session and old debt remain.
- `ae task post` → POST /api/neomorphic-contributor-journey/v1/tasks. Post a task and freeze one quote.
- `ae task quote` → GET /api/neomorphic-contributor-journey/v1/tasks/{taskId}/quote. Read the frozen quote.
- `ae task intent` → POST /api/neomorphic-contributor-journey/v1/tasks/{taskId}/funding-intent. Issue the server funding intent. With --signer-module, sign that exact EIP-191 message and submit it. A contract wallet is refused. This does not transfer value.
- `ae task intent sign` → POST /api/neomorphic-contributor-journey/v1/tasks/{taskId}/funding-intent/signature. Sign one journaled funding intent and submit that signature. This does not issue a new intent and does not transfer value.
- `ae task fund` → POST /api/neomorphic-contributor-journey/v1/tasks/{taskId}/funding. Record a funding observation. A signature is not funding.
- `ae task claim` → POST /api/neomorphic-contributor-journey/v1/claims/claims. Bind and claim one funded slot.
- `ae task submit` → POST /api/neomorphic-contributor-journey/v1/submission/{reservationId}/submit. Draft and submit evidence. Completion is not acceptance.
- `ae task review` → POST /api/neomorphic-contributor-journey/v1/review/decision. Record an explicit review. The state stays approval_pending.
- `ae task authority` → POST /api/neomorphic-contributor-journey/v1/review/authority. Record the capture, expiry, reclaim, refund, or operator-capture winner.
- `ae payout status` → GET /api/neomorphic-contributor-journey/v1/payouts. List payable obligations. A wallet is not required.
- `ae operation recover` → local. Read back unknown operations and retransmit only when the effect is absent.
- `ae account service-signup` → local. Sign up on the loopback Neo account service. The bearer and recovery code stay in the secret store.
- `ae market call` → POST /api/neomorphic-contributor-journey/v1/market/{action}. Use the existing market actions over certificate-verified account HTTP or the original loopback bearer route. HTTP 200 is not useful work.
- `ae network bind` → local. Discover the hosted-wallet market chain from health and record the H1 binding identity. The database URL stays in the binding file.
- `ae task receipt` → local. Fetch the unpaid quote and write a receipt file. Funding, signature, and capture stay unused.
- `ae task retained` → GET /api/neomorphic-contributor-journey/v1/review. Read an already accepted artifact and its original disposition. The exact response is written to a mode 0600 receipt. This does not buy, pay, or submit again. Paid is not task success.
- `ae job submit` → configured machine-gateway. Submit one https URL on url.extract. The body key and gateway key are journaled before the POST. This does not fund.
- `ae job poll` → configured machine-gateway. Poll one job on the configured free machine-gateway route. This does not fund or submit.
- `ae job result` → configured machine-gateway. Read one job result and its exact artifact bytes on the configured free machine-gateway route.
- `ae job receipt` → configured machine-gateway. Read one machine-gateway receipt by id from the configured endpoint.
