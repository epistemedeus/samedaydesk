import {readFile} from 'node:fs/promises';
import {AeError, EXIT} from './errors.mjs';
import {PREFIX} from './c0/participant-wire.mjs';
import {sessionCookie} from './c0/participant-wire.mjs';
import {WIRE_HEADER, WIRE_VERSION} from './catalog.mjs';
import {transport} from './transport.mjs';
import {readProfile, readSecret, writeSecret, requireHome} from './profile.mjs';
import {evidenceFromFault, evidenceFromResponse, formatOf, safeCode, transportKind, wireOf} from './failure-evidence.mjs';

const TRANSPORT = new Set(['timeout', 'https_transport_unknown', 'response_interrupted', 'response_oversize']);

export async function loadContext({ca, timeoutMs = 15000} = {}) {
  const home = await requireHome();
  const profile = await readProfile(home);
  const secret = await readSecret(home, profile);
  return {home, profile, secret, ca, timeoutMs};
}

export async function call(ctx, {method = 'GET', path, query, body, auth = false, idempotencyKey, proof}) {
  const headers = {[WIRE_HEADER]: WIRE_VERSION};
  if (method !== 'GET') headers.origin = ctx.profile.origin;
  if (auth) {
    if (!ctx.secret?.cookie) throw new AeError('unauthenticated', 3);
    headers.cookie = ctx.secret.cookie;
    if (method !== 'GET') {
      headers.origin = ctx.profile.origin;
      headers['x-cj-csrf'] = ctx.secret.csrf;
    }
  }
  if (idempotencyKey) headers['idempotency-key'] = idempotencyKey;
  if (proof) headers['x-account-operation-proof'] = proof;
  const suffix = query ? `${path}?${new URLSearchParams(query)}` : path;
  let response;
  try {
    response = await transport(ctx.profile.origin, PREFIX + suffix, {method, body, headers, ca: ctx.ca, timeoutMs: ctx.timeoutMs});
  } catch (error) {
    if (error instanceof AeError) throw error;
    const code = TRANSPORT.has(error.message) ? error.message : 'https_transport_unknown';
    const facts = error?.facts || {};
    const kind = facts.timedOut ? 'timeout' : facts.oversize ? null : transportKind(facts.cause);
    const evidence = evidenceFromFault({
      method,
      code,
      httpStatus: facts.httpStatus ?? null,
      wire: facts.wire || 'unknown',
      format: facts.oversize ? 'oversize' : 'unknown',
      transport: facts.oversize ? null : kind,
      elapsedMs: facts.elapsedMs,
      deadlineMs: facts.deadlineMs ?? ctx.timeoutMs,
    });
    throw Object.assign(new AeError(code, 2, evidence), facts.httpStatus == null ? {} : {status: facts.httpStatus});
  }
  const wire = wireOf(response.headers?.[WIRE_HEADER], WIRE_VERSION);
  const format = formatOf({contentType: response.contentType, parsed: response.body, empty: response.empty === true});
  const base = {method, status: response.status, wire, format, elapsedMs: response.elapsedMs, deadlineMs: ctx.timeoutMs};
  if (response.status >= 300 && response.status < 400) refuse(method, 'redirect_refused', 1, response, base);
  if (response.headers[WIRE_HEADER] !== WIRE_VERSION) refuse(method, 'wire_version_unsupported', 1, response, base);
  if (!response.verified) refuse(method, 'verified_same_origin_required', 1, response, base);
  // Every C0 success envelope carries an object value. A truncated/partial
  // success after a mutation is still an unknown effect, never confirmation.
  const value = response.body?.value;
  if (response.body?.ok !== true || !value || typeof value !== 'object' || Array.isArray(value)) {
    const code = response.body?.ok === true ? 'api_refused' : safeCode(response.body?.code) || 'api_refused';
    refuse(method, code, EXIT[code] ?? 1, response, base);
  }
  return response;
}

function refuse(method, code, exit, response, base) {
  const evidence = evidenceFromResponse({...base, method, code});
  throw Object.assign(new AeError(code, exit, evidence), {status: response.status});
}

export async function negotiate(ctx) {
  const response = await call(ctx, {method: 'GET', path: '/healthz'});
  const value = response.body.value;
  if (ctx.profile.kind === 'test' && value.serverClass !== 'fixture') throw new AeError('profile_server_mismatch', 4);
  if (ctx.profile.kind === 'live' && value.serverClass !== 'live') throw new AeError('profile_server_mismatch', 4);
  if (value.serverClass === 'fixture' && value.authoritativeLedger !== false) throw new AeError('ledger_claim_refused', 1);
  return value;
}

export async function captureSession(ctx, response, {password, proof, role, displayName, recoveryRequired = true}) {
  const value = response.body?.value;
  if (value?.sessionDelivery !== 'cookie' || Object.hasOwn(value, 'sessionToken')) throw new AeError('cookie_delivery_required', 1);
  let cookie;
  try { cookie = sessionCookie(response.headers); }
  catch { throw new AeError('cookie_boundary_mismatch', 1); }
  const csrf = response.headers['x-cj-csrf'];
  if (!/^[a-f0-9]{64}$/.test(csrf || '')) throw new AeError('csrf_required', 1);
  if (!/^acc_[A-Za-z0-9_-]{16}$/.test(value.account?.accountId || '')) throw new AeError('account_refused', 1);
  if (value.account.role && value.account.role !== role) throw new AeError('profile_server_mismatch',4);
  if (recoveryRequired && (typeof value.recoveryCode !== 'string' || value.recoveryCode.length < 16)) throw new AeError('recovery_code_refused', 1);
  ctx.secret = {
    ...ctx.secret,
    schema: 'ae.secret.v1',
    origin: ctx.profile.origin,
    cookie,
    csrf,
    accountId: value.account.accountId,
    recoveryCode: value.recoveryCode ?? ctx.secret?.recoveryCode,
    proof,
    password,
    role,
    displayName,
    address: ctx.secret?.address,
    localSecret: ctx.secret?.localSecret,
    custody: ctx.secret?.custody,
    fixture: ctx.secret?.fixture,
  };
  await writeSecret(ctx.home, ctx.secret);
  return ctx.secret;
}

export async function readCa(file) {
  if (!file) throw new AeError('ca_required', 1);
  return readFile(file);
}

export function valueOf(response) {
  return response.body.value;
}
