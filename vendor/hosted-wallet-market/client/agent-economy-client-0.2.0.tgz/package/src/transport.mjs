import https from 'node:https';
import {need} from './c0/participant-wire.mjs';
import {WIRE_HEADER, WIRE_VERSION} from './catalog.mjs';
import {wireOf} from './failure-evidence.mjs';

const MAX_BODY = 1024 * 1024;

function fault(code, facts) {
  const error = new Error(code);
  error.facts = facts;
  return error;
}

// Same TLS rules as the C0 transport: verified HTTPS, same origin, no
// NODE_TLS_REJECT_UNAUTHORIZED=0. The caller timeout stays distinct from a
// lost response. A redirect is not followed. Fault facts stay off the success
// value and never include the response body.
export async function transport(origin, route, {method = 'GET', body, headers = {}, ca, timeoutMs = 15000} = {}) {
  const url = new URL(route, origin);
  need(url.origin === origin && url.protocol === 'https:' && process.env.NODE_TLS_REJECT_UNAUTHORIZED !== '0', 'verified_same_origin_required');
  const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
  const startedAt = new Date().toISOString();
  const started = Date.now();
  return new Promise((resolve, reject) => {
    let settled = false;
    let httpStatus = null;
    let contentType = null;
    let wire = 'unknown';
    let oversize = false;
    let timedOut = false;
    const facts = (extra = {}) => ({
      httpStatus,
      contentType,
      wire,
      elapsedMs: Date.now() - started,
      deadlineMs: timeoutMs,
      oversize,
      timedOut,
      ...extra,
    });
    const fail = error => {
      if (settled) return;
      settled = true;
      reject(error);
    };
    const ok = value => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const q = https.request(url, {
      method,
      agent: false,
      rejectUnauthorized: true,
      ...(ca ? {ca} : {}),
      timeout: timeoutMs,
      headers: {
        connection: 'close',
        ...(data ? {'content-type': 'application/json', 'content-length': String(data.length)} : {}),
        ...headers,
      },
    }, res => {
      httpStatus = res.statusCode;
      const typed = res.headers['content-type'];
      contentType = Array.isArray(typed) ? null : (typed || '');
      wire = wireOf(res.headers[WIRE_HEADER], WIRE_VERSION);
      const verified = res.socket.authorized === true;
      let bytes = 0;
      const chunks = [];
      res.on('data', chunk => {
        bytes += chunk.length;
        // Destroy settles through the error/abort handlers. Keep the flag
        // first so whichever event wins is still the oversize fault.
        if (bytes > MAX_BODY) {
          oversize = true;
          const error = fault('response_oversize', facts());
          q.destroy();
          fail(error);
          return;
        }
        chunks.push(chunk);
      });
      res.on('error', () => fail(fault(oversize ? 'response_oversize' : 'response_interrupted', facts({cause: 'closed'}))));
      res.on('aborted', () => fail(fault(oversize ? 'response_oversize' : timedOut ? 'timeout' : 'response_interrupted', facts({cause: timedOut ? 'timeout' : 'closed'}))));
      res.on('end', () => {
        if (oversize || timedOut) return;
        let parsed;
        const raw = Buffer.concat(chunks);
        try { parsed = JSON.parse(raw.toString()); } catch { parsed = undefined; }
        ok({
          status: res.statusCode,
          headers: res.headers,
          body: parsed,
          verified,
          startedAt,
          receivedAt: new Date().toISOString(),
          elapsedMs: Date.now() - started,
          empty: raw.length === 0,
          contentType,
        });
      });
    });
    q.on('error', error => {
      if (oversize) fail(fault('response_oversize', facts()));
      else if (timedOut) fail(fault('timeout', facts({cause: 'timeout'})));
      // A status line already arrived. A later socket error is an interrupted
      // response, not a transport reset and not a failed effect.
      else if (httpStatus == null) fail(fault('https_transport_unknown', facts({cause: error?.code || null})));
      else fail(fault('response_interrupted', facts({cause: 'closed'})));
    });
    q.on('timeout', () => {
      timedOut = true;
      q.destroy();
      fail(fault('timeout', facts({cause: 'timeout'})));
    });
    q.end(data ?? undefined);
  });
}
