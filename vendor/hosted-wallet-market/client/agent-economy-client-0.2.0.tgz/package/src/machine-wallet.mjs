// Principal-held JSON keystores use ethers' standard encrypted wallet format.
// Passwords enter through the existing private file/fd reader, never argv.
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {open} from 'node:fs/promises';
import {Wallet,JsonRpcProvider,Interface,keccak256,verifyTypedData} from './vendor/ethers.mjs';
import {privateRead,ownedDirectory} from './c0/participant-wire.mjs';
import {digest} from './canonical.mjs';
import {AeError} from './errors.mjs';
import {call,valueOf} from './api.mjs';
const fail=code=>{throw new AeError(code,6);};
const absolute=v=>{if(typeof v!=='string'||!path.isAbsolute(v))fail('usage');return v;};
async function writeNew(file,value){await ownedDirectory(path.dirname(file));const handle=await open(file,'wx',0o600);try{await handle.writeFile(JSON.stringify(value)+'\n');await handle.sync();}finally{await handle.close();}}
async function vault(file){const v=await privateRead(absolute(file));if(v.version!==3||!(v.crypto||v.Crypto)||typeof v.address!=='string')fail('wallet_keystore_refused');return v;}
export async function localWallet(action,flags,password){
 const file=absolute(flags.keystore);
 if(action==='local-create'){
  const wallet=Wallet.createRandom();const encrypted=JSON.parse(await wallet.encrypt(password));
  await writeNew(file,encrypted);return {address:wallet.address.toLowerCase(),custody:'principal_encrypted_keystore',format:'ethereum-json-v3',file,recoverable:true,sent:false};
 }
 const saved=await vault(file);
 if(action==='recover'){
  let wallet;try{wallet=await Wallet.fromEncryptedJson(JSON.stringify(saved),password);}catch{fail('wallet_unlock_refused');}
  // Recovery deliberately needs neither a marketplace account nor its profile.
  if(flags.out)await writeNew(absolute(flags.out),saved);
  return {address:wallet.address.toLowerCase(),recovered:true,format:'ethereum-json-v3',...(flags.out?{file:flags.out}:{}),sent:false};
 }
 if(action==='encrypted-export'){await writeNew(absolute(flags.out),saved);return {file:flags.out,encrypted:true,format:'ethereum-json-v3',sent:false};}
 fail('usage');
}
async function signer(flags,password,declared){
 if(flags['signer-module']){
  if(flags.keystore)fail('one_signer_required');
  let s;try{s=await import(pathToFileURL(absolute(flags['signer-module'])).href);}catch{fail('signer_refused');}
  const address=(s.address||declared||'').toLowerCase();
  if(s.accountKind!=='eoa'||!/^0x[0-9a-f]{40}$/.test(address))fail('signer_refused');
  return {...s,address};
 }
 let w;try{w=await Wallet.fromEncryptedJson(JSON.stringify(await vault(flags.keystore)),password);}catch{fail('wallet_unlock_refused');}
 return {address:w.address.toLowerCase(),personalSign:message=>w.signMessage(message),signTypedData:td=>w.signTypedData(td.domain,td.types,td.message),signTransaction:tx=>w.signTransaction(tx)};
}
async function market(ctx,action,body,operation){return valueOf(await call(ctx,{method:'POST',path:'/v1/market/'+action,body,auth:true,idempotencyKey:operation})).result;}
function profileIntent(ctx,intent,expected){
 const cap=ctx.profile.machine;
 if(!cap||cap.profile!=='machine-market'||cap.money!=='sandbox'||intent.profile!=='machine-market'||intent.sourceSha256!==cap.sourceSha256||intent.hostSha256!==cap.hostSha256||intent.origin!==ctx.profile.origin)fail('machine_profile_refused');
 if(ctx.profile.network?.class!=='sandbox'||ctx.profile.network?.chain!=='eip155:31337'||intent.networkClass!=='sandbox'||intent.chain!=='eip155:31337'||intent.contracts?.chain!=='eip155:31337')fail('public_money_unqualified_source_drift');
 const q=intent.quote,p=intent.payment,c=intent.contracts,td=intent.typedData;
 if(intent.quoteDigest!==expected||digest(q)!==expected||q.asset.chain!==intent.chain||q.asset.token!==c.token||q.fundingTarget!==c.escrow||q.payoutDestination!==p.receiver||q.feeRecipient!==p.feeReceiver||p.minFeeBps!==500||p.maxFeeBps!==500||BigInt(q.platformFee)!==BigInt(q.gross)/20n||BigInt(q.contributorNet)!==BigInt(q.gross)-BigInt(q.platformFee)||p.maxAmount!==q.gross||q.rail.costCap!=='0'||q.subsidy!=='0')fail('funding_intent_refused');
 if(td.domain?.chainId!==31337||td.domain.verifyingContract!==c.token||td.domain.name!=='USD Coin'||td.domain.version!=='2'||td.primaryType!=='ReceiveWithAuthorization'||td.message.from!==p.payer||td.message.to!==c.collector||td.message.value!==q.gross||td.message.validBefore!==String(p.preApprovalExpiry)||td.message.validAfter!=='0')fail('funding_intent_refused');
}
async function checkedProvider(flags,intent){
 const u=new URL(flags['chain-url']);if(u.protocol!=='http:'||u.hostname!=='127.0.0.1'||u.username||u.password||u.hash)fail('sandbox_rpc_required');
 const provider=new JsonRpcProvider(u.href,undefined,{batchMaxCount:1,cacheTimeout:-1});
 try{
  if((await provider.getNetwork()).chainId!==31337n)fail('chain_identity_mismatch');
  for(const target of new Set([intent.contracts.escrow,intent.contracts.collector,intent.contracts.refundCollector,intent.contracts.token,...Object.keys(intent.contracts.codeHashes)])){
   const code=await provider.getCode(target);if(code==='0x'||keccak256(code)!==intent.contracts.codeHashes[target])fail('contract_runtime_pin');
  }
  return provider;
 }catch(e){provider.destroy();throw e;}
}
export async function machineWallet(ctx,action,flags,password){
 if(!ctx.secret?.cookie)fail('unauthenticated');
 const s=await signer(flags,password,ctx.secret.address),operation=flags.operation;
 if(!/^[a-z0-9][a-z0-9-]{7,63}$/.test(operation||''))fail('operation_required');
 if(action==='prove-wallet'){
  const c=await market(ctx,'walletChallenge',{address:s.address},operation);
  if(c.challenge.origin!==ctx.profile.origin||c.challenge.accountId!==ctx.secret.accountId||c.challenge.address!==s.address||'pilot.machine-wallet-control.v1:'+digest(c.challenge)!==c.message)fail('wallet_challenge_refused');
  let signature;try{const signed=await s.personalSign(c.message);signature=signed?.signature||signed;if(signed?.address&&signed.address.toLowerCase()!==s.address)fail('signer_refused');}catch{fail('signer_refused');}
  return market(ctx,'walletProve',{signature,challengeDigest:digest(c.challenge)},operation);
 }
 const taskId=flags.task,quoteDigest=flags['quote-digest'];
 if(typeof taskId!=='string'||!/^market-[a-f0-9]{64}$/.test(taskId)||!(/^[a-f0-9]{64}$/).test(quoteDigest||''))fail('usage');
 const intent=await market(ctx,'fundingIntent',{taskId,quoteDigest},operation);
 profileIntent(ctx,intent,quoteDigest);if(s.address!==intent.payment.payer)fail('payer_mismatch');
 const provider=await checkedProvider(flags,intent);
 try{
  if(action==='fund'){
   let signature;try{const signed=await s.signTypedData(intent.typedData);signature=signed?.signature||signed;}catch{fail('signer_refused');}
   if(verifyTypedData(intent.typedData.domain,intent.typedData.types,intent.typedData.message,signature).toLowerCase()!==s.address)fail('wallet_control_required');
   // The server rail persists its original signed transaction before broadcast.
   // Repeating this operation recovers that same hash and canonical reservation.
   return market(ctx,'fundingAuthorize',{taskId,quoteDigest,proofId:intent.proofId,signature},operation);
  }
  if(action==='reclaim'){
   if(typeof s.signTransaction!=='function')fail('signer_refused');
   const file=path.join(ctx.home,'reclaim-'+digest({origin:ctx.profile.origin,taskId,quoteDigest})+'.json');
   const binding=digest({taskId,quoteDigest,payer:s.address,contracts:intent.contracts,payment:intent.payment});
   let record;try{record=await privateRead(file);}catch(e){if(e.code!=='ENOENT')throw e;}
   if(record&&record.binding!==binding)fail('immutable_operation_input_changed');
   if(!record){
    const latest=await provider.getBlock('latest');if(latest.timestamp<Number(intent.payment.authorizationExpiry))fail('authorization_not_expired');
    const data=new Interface(intent.contracts.abi).encodeFunctionData('reclaim',[intent.payment]);
    const tx={chainId:31337,to:intent.contracts.escrow,data,value:0n,nonce:await provider.getTransactionCount(s.address,'pending'),gasLimit:await provider.estimateGas({from:s.address,to:intent.contracts.escrow,data}),gasPrice:await provider.send('eth_gasPrice',[]),type:0};
    const raw=await s.signTransaction(tx);record={schema:'ae.original-transaction.v1',binding,transactionHash:keccak256(raw),raw};await writeNew(file,record);
   }
   let receipt;
   try {
    receipt=await provider.getTransactionReceipt(record.transactionHash);
    if(!receipt){if(!await provider.getTransaction(record.transactionHash))await provider.broadcastTransaction(record.raw);receipt=await provider.waitForTransaction(record.transactionHash,1,ctx.timeoutMs);}
   } catch { throw new AeError('unknown_outcome_quarantined',2); }
   if(!receipt)fail('unknown_outcome_quarantined');if(receipt.status!==1)fail('reclaim_lost_race');
   return {state:'reclaimed_on_chain',transactionHash:record.transactionHash,accepted:false,postCaptureRefund:false};
  }
  fail('usage');
 }finally{provider.destroy();}
}
