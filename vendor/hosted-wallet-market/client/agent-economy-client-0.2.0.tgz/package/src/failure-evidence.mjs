// Bounded facts for a caller. This object never carries response text, headers,
// cookies, tokens, query strings, or server error fields.
export {safeCode} from './error-codes.mjs';

const PHASE = new Set(['transport', 'response']);
const FORMAT = new Set(['api_json', 'json', 'non_object', 'html', 'empty', 'malformed_json', 'oversize', 'unknown']);
const NEXT = new Set(['read_again', 'recover_stored', 'stop', 'unknown']);
const TRANSPORT = new Set(['tls', 'connect', 'timeout', 'closed', 'reset']);
const WIRE = new Set(['match', 'missing', 'mismatch', 'unknown']);
const OPERATION = /^[A-Za-z0-9][A-Za-z0-9_.:#-]{0,160}$/;

function statusOk(value) {
  return Number.isInteger(value) && value >= 100 && value <= 599 ? value : undefined;
}

function msOk(value) {
  return Number.isInteger(value) && value >= 0 && value <= 600000 ? value : undefined;
}

function deadlineOk(value) {
  return Number.isInteger(value) && value >= 100 && value <= 120000 ? value : undefined;
}

export function wireOf(value, expected) {
  if (value === undefined) return 'missing';
  if (value === expected) return 'match';
  return 'mismatch';
}

export function formatOf({contentType, parsed, empty = false, oversize = false} = {}) {
  if (oversize) return 'oversize';
  if (empty) return 'empty';
  if (parsed === undefined) {
    const type = String(contentType || '').toLowerCase();
    if (type.startsWith('text/html') || type.startsWith('application/xhtml')) return 'html';
    return 'malformed_json';
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return 'non_object';
  if (typeof parsed.ok === 'boolean') return 'api_json';
  return 'json';
}

export function transportKind(cause) {
  const code = typeof cause === 'string' ? cause : '';
  if (code === 'timeout') return 'timeout';
  if (code === 'closed' || code === 'aborted') return 'closed';
  if (code.startsWith('CERT_') || code.startsWith('ERR_TLS') || code.includes('CERT') || code.includes('SSL')) return 'tls';
  if (['ECONNREFUSED', 'ENOTFOUND', 'EAI_AGAIN', 'EHOSTUNREACH', 'ENETUNREACH', 'EADDRNOTAVAIL'].includes(code)) return 'connect';
  if (['ECONNRESET', 'EPIPE', 'ECONNABORTED'].includes(code)) return 'reset';
  return null;
}

function read(method) {
  return method === 'GET' || method === 'HEAD';
}

export function nextAction({method, phase, httpStatus, code, transport}) {
  if (code === 'redirect_refused' || code === 'wire_version_unsupported' || code === 'verified_same_origin_required') return 'stop';
  if (phase === 'transport' || httpStatus == null) return read(method) ? 'read_again' : 'recover_stored';
  if (httpStatus >= 300 && httpStatus < 400) return 'stop';
  if (httpStatus >= 400 && httpStatus < 500) return 'stop';
  if (httpStatus >= 500) return read(method) ? 'read_again' : 'recover_stored';
  if (transport === 'timeout' || code === 'timeout' || code === 'response_interrupted' || code === 'response_oversize' || code === 'api_refused') {
    return read(method) ? 'read_again' : 'recover_stored';
  }
  if (httpStatus != null && code && code !== 'api_refused') return 'stop';
  return 'unknown';
}

function build(fields) {
  return publicEvidence({schema: 'ae.failure-evidence.v1', operationId: null, ...fields});
}

export function evidenceFromResponse({method, status, wire, format, elapsedMs, deadlineMs, code}) {
  const httpStatus = statusOk(status) ?? null;
  return build({
    phase: 'response',
    httpStatus,
    format: FORMAT.has(format) ? format : 'unknown',
    wire: WIRE.has(wire) ? wire : 'unknown',
    transport: null,
    elapsedMs: msOk(elapsedMs) ?? null,
    deadlineMs: deadlineOk(deadlineMs) ?? null,
    next: nextAction({method, phase: 'response', httpStatus, code, transport: null}),
  });
}

export function evidenceFromFault({method, code, httpStatus, wire = 'unknown', format = 'unknown', transport, elapsedMs, deadlineMs}) {
  const status = httpStatus == null ? null : statusOk(httpStatus) ?? null;
  const phase = status == null ? 'transport' : 'response';
  const kind = transport === undefined ? null : transport;
  return build({
    phase,
    httpStatus: status,
    format: FORMAT.has(format) ? format : 'unknown',
    wire: WIRE.has(wire) ? wire : 'unknown',
    transport: kind,
    elapsedMs: msOk(elapsedMs) ?? null,
    deadlineMs: deadlineOk(deadlineMs) ?? null,
    next: nextAction({method, phase, httpStatus: status, code, transport: kind}),
  });
}

export function publicEvidence(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  if (value.schema !== 'ae.failure-evidence.v1') return null;
  if (!PHASE.has(value.phase) || !FORMAT.has(value.format) || !NEXT.has(value.next) || !WIRE.has(value.wire)) return null;
  const httpStatus = value.httpStatus === null ? null : statusOk(value.httpStatus);
  if (httpStatus === undefined) return null;
  const elapsedMs = value.elapsedMs === null ? null : msOk(value.elapsedMs);
  if (elapsedMs === undefined) return null;
  const deadlineMs = value.deadlineMs === null ? null : deadlineOk(value.deadlineMs);
  if (deadlineMs === undefined) return null;
  const transport = value.transport === null ? null : (TRANSPORT.has(value.transport) ? value.transport : undefined);
  if (transport === undefined) return null;
  const operationId = value.operationId == null ? null : (OPERATION.test(value.operationId) ? value.operationId : undefined);
  if (operationId === undefined) return null;
  return {
    schema: 'ae.failure-evidence.v1',
    phase: value.phase,
    httpStatus,
    format: value.format,
    wire: value.wire,
    transport,
    elapsedMs,
    deadlineMs,
    next: value.next,
    operationId,
  };
}
