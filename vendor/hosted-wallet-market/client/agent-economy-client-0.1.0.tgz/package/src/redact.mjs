const SECRET_KEYS = new Set([
  'password', 'cookie', 'csrf', 'recoveryCode', 'proof', 'localSecret',
  'seed', 'privateKey', 'signature', 'sessionToken', 'authorization', 'bearer', 'unlockKey',
]);

export function redact(value) {
  if (Array.isArray(value)) return value.map(redact);
  if (value && typeof value === 'object') {
    const out = {};
    for (const [key, child] of Object.entries(value)) {
      // Account operation proofs are strings. A funding receipt is an object
      // whose key is also `proof`; dropping it hides the public escrow state.
      if (SECRET_KEYS.has(key) && !(key === 'proof' && child && typeof child === 'object')) continue;
      out[key] = redact(child);
    }
    return out;
  }
  return value;
}

export function containsSecret(value, secret) {
  if (!secret) return false;
  return JSON.stringify(value ?? null).includes(secret);
}
