// Local join for an already delivered result. A viewer string, HTTP 200, or a
// paid boolean is not the result. Accepted-unpaid stays owed.
import {createHash} from 'node:crypto';
import {AeError} from './errors.mjs';

const ID = /^[A-Za-z0-9_.:-]{1,200}$/;
const DIGEST = /^[0-9a-f]{64}$/;
const TERMS = /^sha256:[0-9a-f]{64}$/;

function refuse(code) {
  throw new AeError(code, 1);
}

function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

function paidJoin(disposition) {
  return Boolean(disposition)
    && disposition.projection === 'native_paid'
    && disposition.kernelPaid === true
    && disposition.nativePaidObservation === true
    && disposition.transferInitiated === false
    && disposition.payoutState === 'owed'
    && disposition.payable === false
    && disposition.newPayable === false;
}

export function assessEntitled(value, {taskId, reservationId}) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) refuse('entitled_join_refused');
  const entitled = value.entitled;
  const paidFlag = value.fulfillment?.paid === true || entitled?.fulfillment?.paid === true;
  const disposition = entitled?.disposition;
  const joined = paidJoin(disposition);
  if (paidFlag && !joined) refuse('paid_bool_unjoined');
  if (!entitled || typeof entitled !== 'object' || Array.isArray(entitled)) refuse('entitled_join_refused');
  if (entitled.schema !== 'pilot.root239.entitled-result.v1') refuse('entitled_join_refused');
  if (!['requester', 'contributor'].includes(entitled.role) || value.viewer !== entitled.role) refuse('entitled_join_refused');
  if (!ID.test(taskId || '') || !ID.test(reservationId || '') || taskId.includes('..') || reservationId.includes('..')) refuse('usage');
  if (entitled.taskId !== taskId || entitled.reservationId !== reservationId) refuse('mismatch');
  if (value.source?.taskId !== entitled.taskId || value.source?.reservationId !== entitled.reservationId || value.source?.termsVersion !== entitled.termsVersion) {
    refuse('entitled_join_refused');
  }
  if (!TERMS.test(entitled.termsVersion || '') || disposition?.termsVersion !== entitled.termsVersion) refuse('terms_unbound');
  const artifact = entitled.artifact;
  if (!artifact || typeof artifact.body !== 'string' || !DIGEST.test(artifact.digestSha256 || '') || !Number.isInteger(artifact.bytes) || artifact.bytes < 1) {
    refuse('artifact_absent');
  }
  if (!['utf8', 'base64'].includes(artifact.encoding)) refuse('artifact_absent');
  const raw = artifact.encoding === 'base64' ? Buffer.from(artifact.body, 'base64') : Buffer.from(artifact.body, 'utf8');
  if (raw.length !== artifact.bytes || sha256(raw) !== artifact.digestSha256 || disposition.artifactDigestSha256 !== artifact.digestSha256) {
    refuse('artifact_digest_mismatch');
  }
  if (!entitled.verdict || typeof entitled.verdict.outcome !== 'string' || !entitled.verdict.id) refuse('incomplete_evidence');
  if (disposition.reservationId !== reservationId || disposition.taskId !== taskId || typeof disposition.obligationId !== 'string' || !disposition.obligationId) {
    refuse('incomplete_evidence');
  }
  if (value.fulfillment?.paid !== entitled.fulfillment?.paid || value.fulfillment?.state !== entitled.fulfillment?.state) refuse('entitled_join_refused');
  let status;
  if (joined) {
    if (entitled.fulfillment?.paid !== true || entitled.fulfillment?.state !== 'verified_paid') refuse('entitled_join_refused');
    status = 'native_paid';
  } else if (disposition.projection === 'owed' && disposition.kernelPaid === false && disposition.nativePaidObservation === false && disposition.transferInitiated === false && disposition.payoutState === 'owed' && entitled.fulfillment?.paid === false && entitled.fulfillment?.state === 'not_observed') {
    status = 'owed';
  } else {
    refuse('entitled_join_refused');
  }
  return {
    status,
    role: entitled.role,
    taskId: entitled.taskId,
    reservationId: entitled.reservationId,
    termsVersion: entitled.termsVersion,
    artifactBytes: artifact.bytes,
    artifactDigestSha256: artifact.digestSha256,
    verdictOutcome: entitled.verdict.outcome,
    businessStatus: typeof entitled.businessStatus === 'string' ? entitled.businessStatus : null,
    dispositionProjection: disposition.projection,
    fulfillmentState: entitled.fulfillment.state,
    fulfillmentPaid: entitled.fulfillment.paid === true,
    payoutState: disposition.payoutState,
    payable: disposition.payable === true,
    newPayable: disposition.newPayable === true,
    holdReason: typeof disposition.holdReason === 'string' ? disposition.holdReason : null,
    usefulOutcome: typeof entitled.usefulOutcome === 'string' ? entitled.usefulOutcome : null,
    obligationId: disposition.obligationId,
    proofJoins: ['role', 'task', 'reservation', 'terms', 'artifact', 'verdict', 'disposition'],
  };
}
