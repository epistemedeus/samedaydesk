import {createHash} from 'node:crypto';
import {readFileSync, statSync} from 'node:fs';
import path from 'node:path';
import {AeError} from './errors.mjs';

// N3's selected public networks. A sandbox label does not exempt them.
const PUBLIC_CHAINS = new Set(['eip155:8453', 'eip155:84532']);
const CHAIN = /^eip155:([1-9][0-9]*)$/;

function chainIdOf(chain) {
  const match = typeof chain === 'string' ? CHAIN.exec(chain) : null;
  if (!match) return null;
  const chainId = Number(match[1]);
  if (!Number.isSafeInteger(chainId) || String(chainId) !== match[1]) return null;
  return chainId;
}

function receiptRefused() {
  throw new AeError('network_receipt_refused', 1);
}

function readAdmittedReceipt(chain, receipt) {
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt)) receiptRefused();
  const keys = Object.keys(receipt);
  if (keys.length !== 2 || !Object.hasOwn(receipt, 'path') || !Object.hasOwn(receipt, 'digest')) receiptRefused();
  if (typeof receipt.path !== 'string' || !path.isAbsolute(receipt.path)) receiptRefused();
  if (typeof receipt.digest !== 'string' || !/^[0-9a-f]{64}$/.test(receipt.digest)) receiptRefused();
  let info;
  let bytes;
  try {
    info = statSync(receipt.path);
    bytes = readFileSync(receipt.path);
  } catch {
    receiptRefused();
  }
  if (!info.isFile()) receiptRefused();
  const digest = createHash('sha256').update(bytes).digest('hex');
  if (digest !== receipt.digest) receiptRefused();
  let body;
  try {
    body = JSON.parse(bytes.toString('utf8'));
  } catch {
    receiptRefused();
  }
  if (!body || typeof body !== 'object' || Array.isArray(body)) receiptRefused();
  if (body.schema !== 'ae14.network-admission.v1') receiptRefused();
  if (body.verdict !== 'admitted') receiptRefused();
  if (body.subject?.network !== chain) receiptRefused();
}

export function resolveNetworkIdentity(config) {
  const network = config?.network;
  if (!network || typeof network !== 'object' || Array.isArray(network)) throw new AeError('network_identity_required', 1);
  if (network.class !== 'sandbox' && network.class !== 'public') throw new AeError('network_identity_required', 1);
  const chainId = chainIdOf(network.chain);
  if (chainId === null) throw new AeError('network_identity_required', 1);
  const publicIdentity = network.class === 'public' || PUBLIC_CHAINS.has(network.chain);
  if (!publicIdentity) {
    return {class: 'sandbox', chain: network.chain, chainId};
  }
  if (config.networkReceipt == null) throw new AeError('public_identity_refused', 1);
  readAdmittedReceipt(network.chain, config.networkReceipt);
  return {class: 'public', chain: network.chain, chainId};
}
