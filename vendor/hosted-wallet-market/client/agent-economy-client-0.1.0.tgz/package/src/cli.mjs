import {COMMANDS, WIRE_VERSION} from './catalog.mjs';
import {AeError, asAeError} from './errors.mjs';
import {requireHome, readProfile, readSecret} from './profile.mjs';
import {withLock} from './profile.mjs';
import {readCa} from './api.mjs';
import {dispatch} from './commands.mjs';
import {redact} from './redact.mjs';

const FORBIDDEN = new Set(['password', 'cookie', 'token', 'secret', 'recovery-code', 'recoverycode', 'private-key', 'privatekey', 'seed', 'csrf', 'session', 'session-token']);

const ALLOWED = {
  help: [],
  'profile.init': ['name', 'kind', 'role', 'origin', 'network', 'network-class', 'network-receipt', 'network-receipt-digest'],
  'profile.show': [],
  'profile.switch-origin': ['origin'],
  discover: ['cursor', 'limit', 'ca-file', 'timeout-ms'],
  'account.signup': ['display-name', 'operation', 'secret-file', 'secret-fd', 'ca-file', 'timeout-ms'],
  'account.session': ['ca-file', 'timeout-ms'],
  'account.resume': ['operation', 'ca-file', 'timeout-ms'],
  'account.exit': ['operation', 'ca-file', 'timeout-ms'],
  'wallet.create': ['wallet-module', 'chain-url', 'store', 'tenant', 'actor', 'wallet-id'],
  'wallet.declare': ['address'],
  'wallet.bind': ['operation', 'ca-file', 'timeout-ms', 'asset', 'wallet-module', 'chain-url', 'store'],
  'wallet.export': ['ca-file', 'timeout-ms'],
  'wallet.exit': ['operation', 'ca-file', 'timeout-ms'],
  'task.post': ['operation', 'title', 'public-text', 'gross', 'rail-cost', 'fee-recipient', 'captures', 'ca-file', 'timeout-ms'],
  'task.quote': ['task', 'ca-file', 'timeout-ms'],
  'task.intent': ['operation', 'task', 'settlement-token', 'signer-module', 'out', 'ca-file', 'timeout-ms'],
  'task.intent.sign': ['operation', 'task', 'settlement-token', 'issue-operation', 'signer-module', 'out', 'ca-file', 'timeout-ms'],
  'task.fund': ['operation', 'task', 'evidence', 'proof-id', 'ca-file', 'timeout-ms'],
  'task.claim': ['operation', 'task', 'destination', 'ca-file', 'timeout-ms'],
  'task.submit': ['operation', 'reservation', 'evidence-file', 'ca-file', 'timeout-ms'],
  'task.review': ['operation', 'reservation', 'review-file', 'ca-file', 'timeout-ms'],
  'task.authority': ['operation', 'reservation', 'winner', 'ca-file', 'timeout-ms'],
  'payout.status': ['cursor', 'limit', 'ca-file', 'timeout-ms'],
  'operation.recover': ['ca-file', 'timeout-ms'],
  'account.service-signup': ['base-url', 'display-name', 'operation', 'secret-file', 'secret-fd', 'timeout-ms'],
  'market.call': ['action', 'body-file', 'operation', 'origin', 'timeout-ms'],
  'network.bind': ['binding', 'ca-file', 'timeout-ms'],
  'task.receipt': ['task', 'out', 'ca-file', 'timeout-ms'],
  'task.retained': ['task', 'reservation', 'receipt-file', 'ca-file', 'timeout-ms'],
  'job.submit': ['url', 'config', 'idempotency-key', 'timeout-ms'],
  'job.poll': ['job', 'config', 'timeout-ms'],
  'job.result': ['job', 'config', 'timeout-ms'],
  'job.receipt': ['receipt', 'config', 'timeout-ms'],
};

export function parseArgv(argv) {
  const positionals = [];
  const flags = {};
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      positionals.push(token);
      continue;
    }
    const eq = token.indexOf('=');
    const name = (eq === -1 ? token.slice(2) : token.slice(2, eq)).toLowerCase();
    if (FORBIDDEN.has(name)) throw new AeError('secret_in_argv_refused', 1);
    const value = eq === -1 ? argv[++i] : token.slice(eq + 1);
    if (!name || value === undefined || value.startsWith('--') || Object.hasOwn(flags, name)) throw new AeError('usage', 1);
    flags[name] = value;
  }
  return {positionals, flags};
}

function findCommand(positionals) {
  return COMMANDS.find(command => command.argv.length === positionals.length && command.argv.every((part, index) => part === positionals[index]));
}

function helpValue() {
  return {
    wireVersion: WIRE_VERSION,
    noninteractive: true,
    commands: COMMANDS.map(command => ({id: command.id, argv: command.argv, help: command.help})),
  };
}

async function contextFor(command, flags) {
  const home = await requireHome();
  const timeoutMs = flags['timeout-ms'] ? Number(flags['timeout-ms']) : 15000;
  if (!Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 120000) throw new AeError('timeout_refused', 1);
  if (command.transport === 'gateway') return {home, profile: null, secret: null, ca: undefined, timeoutMs};
  const ca = flags['ca-file'] ? await readCa(flags['ca-file']) : undefined;
  if (command.id === 'profile.init') return {home, ca, timeoutMs, profile: null, secret: null};
  const profile = await readProfile(home);
  const secret = await readSecret(home, profile);
  return {home, profile, secret, ca, timeoutMs};
}

export async function run(argv, io = {stdout: process.stdout, stderr: process.stderr}) {
  try {
    const {positionals, flags} = parseArgv(argv);
    if (positionals.length === 0 || (positionals.length === 1 && positionals[0] === 'help')) {
      await write(io.stdout, {ok: true, command: 'help', wireVersion: WIRE_VERSION, result: helpValue()});
      return 0;
    }
    const command = findCommand(positionals);
    if (!command) throw new AeError('usage', 1);
    const allowed = new Set(ALLOWED[command.id] || []);
    for (const name of Object.keys(flags)) {
      if (!allowed.has(name)) throw new AeError('usage', 1);
    }
    if (command.local && command.id !== 'operation.recover' && !['profile.show', 'profile.switch-origin', 'wallet.create', 'wallet.declare', 'profile.init'].includes(command.id) && command.id !== 'help') {
      throw new AeError('usage', 1);
    }
    const localWalletBind = command.id === 'wallet.bind' && flags.asset && flags['wallet-module'];
    const loopbackCommand = command.id === 'market.call' || command.id === 'account.service-signup';
    const jobCommand = command.transport === 'gateway';
    const needsNetwork = (!command.local || command.id === 'operation.recover') && !localWalletBind && !loopbackCommand && !jobCommand;
    if (needsNetwork && !flags['ca-file']) throw new AeError('ca_required', 1);
    const ctx = await contextFor(command, flags);
    const execute = () => dispatch(ctx, command, flags);
    const result = ctx.home ? await withLock(ctx.home, execute) : await execute();
    await write(io.stdout, {ok: true, command: command.id, wireVersion: WIRE_VERSION, result: redact(result)});
    return 0;
  } catch (error) {
    const wrapped = asAeError(error);
    await write(io.stderr, {ok: false, code: wrapped.code, exit: wrapped.exit});
    return wrapped.exit;
  }
}

function write(stream, value) {
  return new Promise(resolve => stream.write(JSON.stringify(value) + '\n', () => resolve()));
}
