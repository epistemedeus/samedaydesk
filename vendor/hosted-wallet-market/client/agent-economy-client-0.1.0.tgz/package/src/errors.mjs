export class AeError extends Error {
  constructor(code, exit = 1, detail) {
    super(code);
    this.name = 'AeError';
    this.code = code;
    this.exit = exit;
    this.detail = detail;
  }
}

export const EXIT = Object.freeze({
  ok: 0,
  usage: 1,
  contract_refused: 1,
  wire_version_unsupported: 1,
  premature_acceptance: 1,
  next_consumer_receipt_not_issued: 1,
  amount_in_public_text: 1,
  timeout: 2,
  https_transport_unknown: 2,
  response_interrupted: 2,
  unknown_outcome_quarantined: 2,
  unauthenticated: 3,
  revoked: 3,
  profile_server_mismatch: 4,
  origin_credential_mismatch: 4,
  origin_changed: 4,
  not_found: 5,
  slot_taken: 6,
  conflict: 6,
  immutable_operation_input_changed: 6,
  funding_intent_locked: 6,
  funding_intent_refused: 1,
  contract_wallet_unsupported: 1,
  funding_refused: 1,
  recovery_expired: 1,
  signer_refused: 1,
  winner_already_recorded: 6,
  funding_proof_reused: 6,
  recipient_frozen: 6,
  legacy_obligation_immutable: 6,
  funding_not_usable: 7,
});

export function asAeError(error) {
  if (error instanceof AeError) return error;
  const code = typeof error?.message === 'string' && /^[a-z0-9_]+$/.test(error.message) ? error.message : 'contract_refused';
  const exit = EXIT[code] ?? 1;
  return new AeError(code, exit);
}

export function throwCode(code, exit = EXIT[code] ?? 1) {
  throw new AeError(code, exit);
}
