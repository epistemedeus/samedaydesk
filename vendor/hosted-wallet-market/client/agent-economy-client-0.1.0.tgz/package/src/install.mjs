import {access, writeFile} from 'node:fs/promises';
import path from 'node:path';

// npm 10.9.8 throws Tracker "idealTree" already exists when `npm install <tgz>`
// runs in a directory that has no package.json. The same install succeeds once
// a package.json exists. The file is an empty private manifest, not a dependency.
export async function ensureInstallPackageJson(dir) {
  const file = path.join(dir, 'package.json');
  try {
    await access(file);
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    await writeFile(file, '{}\n', {flag: 'wx', mode: 0o644});
  }
}
