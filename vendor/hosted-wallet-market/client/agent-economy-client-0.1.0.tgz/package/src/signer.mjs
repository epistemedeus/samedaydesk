import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {AeError} from './errors.mjs';
import {recoverPersonalSigner} from './eip191.mjs';

// Caller-owned signer. The module exports scheme, accountKind, and personalSign.
// This process never reads a private key. Contract wallets stop here.
export async function loadCallerSigner(modulePath) {
  if (typeof modulePath !== 'string' || !path.isAbsolute(modulePath)) throw new AeError('usage', 1);
  let loaded;
  try {
    loaded = await import(pathToFileURL(modulePath).href);
  } catch {
    throw new AeError('signer_refused', 1);
  }
  if (loaded.scheme !== 'eip191') throw new AeError('signer_refused', 1);
  if (loaded.accountKind === 'contract') throw new AeError('contract_wallet_unsupported', 1);
  if (loaded.accountKind !== 'eoa' || typeof loaded.personalSign !== 'function') throw new AeError('signer_refused', 1);
  return loaded;
}

export async function signExactIntent(signer, message, payer) {
  let signed;
  try {
    signed = await signer.personalSign(message);
  } catch (error) {
    if (error?.code === 'contract_wallet_unsupported') throw error;
    throw Object.assign(new AeError('funding_intent_refused', 1), {status: 409});
  }
  const signature = signed?.signature;
  const address = typeof signed?.address === 'string' ? signed.address.toLowerCase() : '';
  if (address !== payer || recoverPersonalSigner(message, signature) !== payer || !/^0x[0-9a-f]{130}$/.test(signature || '')) {
    throw Object.assign(new AeError('funding_intent_refused', 1), {status: 409});
  }
  return signature;
}
