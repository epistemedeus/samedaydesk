// Standalone wire primitives. Only standard Node builtins; no server imports.
import path from 'node:path';
import https from 'node:https';
import {open,mkdir,lstat,rename,unlink} from 'node:fs/promises';
import {constants} from 'node:fs';
import {randomBytes,createHash} from 'node:crypto';
export const PREFIX='/api/neomorphic-contributor-journey';
const COOKIE='__Host-neo_contributor';
export const need=(ok,code='contract_refused')=>{if(!ok)throw new Error(code);};
export const hash=x=>createHash('sha256').update(typeof x==='string'||Buffer.isBuffer(x)?x:JSON.stringify(x)).digest('hex');
export const nonce=()=>randomBytes(32).toString('base64url');
export async function privateRead(file){
  const h=await open(file,constants.O_RDONLY|constants.O_NOFOLLOW);
  try{const s=await h.stat();need(s.isFile()&&s.uid===process.getuid()&&(s.mode&0o077)===0&&s.size<2*1024*1024,'private_file_refused');return JSON.parse(await h.readFile('utf8'));}finally{await h.close();}
}
export async function privateWrite(file,value){
  // A killed writer may leave an uncommitted sibling. Never promote or delete
  // that evidence, and never let its fixed name block authoritative readback.
  const temp=file+'.new-'+process.pid+'-'+randomBytes(16).toString('hex');
  const h=await open(temp,constants.O_WRONLY|constants.O_CREAT|constants.O_EXCL|constants.O_NOFOLLOW,0o600);
  try{
    try{await h.writeFile(JSON.stringify(value,null,2)+'\n');await h.sync();}finally{await h.close();}
    await rename(temp,file);
    const parent=await open(path.dirname(file),constants.O_RDONLY|constants.O_DIRECTORY|constants.O_NOFOLLOW);
    try{await parent.sync();}finally{await parent.close();}
  }finally{await unlink(temp).catch(e=>{if(e.code!=='ENOENT')throw e;});}
}
export async function ownedDirectory(dir){
  need(path.isAbsolute(dir),'absolute_private_directory_required');await mkdir(dir,{recursive:true,mode:0o700});
  const s=await lstat(dir);need(s.isDirectory()&&!s.isSymbolicLink()&&s.uid===process.getuid()&&(s.mode&0o077)===0,'private_directory_refused');
}
export async function lock(dir,kind){
  const file=path.join(dir,kind+'.lock');const h=await open(file,constants.O_WRONLY|constants.O_CREAT|constants.O_EXCL|constants.O_NOFOLLOW,0o600);
  await h.writeFile(JSON.stringify({pid:process.pid,startedAt:new Date().toISOString()}));await h.close();return ()=>unlink(file);
}
export async function removeDeadLock(dir,kind){
  const file=path.join(dir,kind+'.lock');let record;try{record=await privateRead(file);}catch(e){if(e.code==='ENOENT')return;throw e;}
  need(Number.isInteger(record.pid)&&record.pid>1,'lock_refused');let dead=false;
  try{process.kill(record.pid,0);}catch(e){if(e.code==='ESRCH')dead=true;else throw e;}
  need(dead,'existing_writer_alive');await unlink(file);
}
export function args(argv){const result={action:argv[0]};for(let i=1;i<argv.length;i+=2){need(argv[i]?.startsWith('--')&&argv[i+1]&&!Object.hasOwn(result,argv[i].slice(2)),'arguments_refused');result[argv[i].slice(2)]=argv[i+1];}return result;}

export async function transport(origin,route,{method='GET',body,headers={},ca}={}){
  const url=new URL(route,origin);need(url.origin===origin&&url.protocol==='https:'&&process.env.NODE_TLS_REJECT_UNAUTHORIZED!=='0','verified_same_origin_required');
  const data=body===undefined?null:Buffer.from(JSON.stringify(body)),startedAt=new Date().toISOString();
  return new Promise((resolve,reject)=>{
    const q=https.request(url,{method,agent:false,rejectUnauthorized:true,...(ca?{ca}:{}),timeout:15000,
      headers:{connection:'close',...(data?{'content-type':'application/json','content-length':String(data.length)}:{}),...headers}},res=>{
      const verified=res.socket.authorized===true;let bytes=0;const chunks=[];
      res.on('data',c=>{bytes+=c.length;if(bytes>1024*1024)q.destroy();else chunks.push(c);});res.on('error',()=>reject(new Error('response_interrupted')));res.on('aborted',()=>reject(new Error('response_interrupted')));
      res.on('end',()=>{let body;try{body=JSON.parse(Buffer.concat(chunks).toString());}catch{}
        resolve({status:res.statusCode,headers:res.headers,body,verified,startedAt,receivedAt:new Date().toISOString()});});
    });q.on('error',()=>reject(new Error('https_transport_unknown')));q.on('timeout',()=>q.destroy());q.end(data??undefined);
  });
}
export function sessionCookie(headers,{cleared=false}={}){
  const cookies=headers['set-cookie']??[];
  const matches=cookies.filter(c=>c.startsWith(COOKIE+'='));
  need(matches.length===1,'one session cookie required');
  const [pair,...fields]=matches[0].split(';').map(s=>s.trim());
  const flags=new Map(fields.map(f=>{const i=f.indexOf('=');return [i<0?f:f.slice(0,i),i<0?true:f.slice(i+1)];}));
  need(flags.get('Path')==='/'&&flags.get('Secure')===true&&flags.get('HttpOnly')===true&&flags.get('SameSite')==='Strict'&&!flags.has('Domain'),'cookie boundary mismatch');
  need(cleared?pair===COOKIE+'='&&flags.get('Max-Age')==='0':/^__Host-neo_contributor=acs_[A-Za-z0-9_-]{43}$/.test(pair)&&Number(flags.get('Max-Age'))>0,'cookie lifetime mismatch');
  return pair;
}
export function continuityEvidence(e){
  const structured=e?.resultOrReason&&typeof e.resultOrReason==='object'&&!Array.isArray(e.resultOrReason)&&Object.keys(e.resultOrReason).length>0;
  need(e?.schema==='pilot.continuity-report.v1'&&['completed','refused','failed','unresolved'].includes(e.businessStatus)&&typeof e.commandID==='string'&&e.commandID.length>0&&(e.httpStatus===null||Number.isInteger(e.httpStatus)&&e.httpStatus>=100&&e.httpStatus<=599)&&(structured||typeof e.resultOrReason==='string'&&e.resultOrReason.length>0)&&e.executionRef?.length>0&&e.inputRef?.length>0&&e.outputRef?.length>0&&e.versions?.length>0&&Number.isFinite(e.effortMinutes)&&e.effortMinutes>0&&e.effortMinutes<=20&&Number.isInteger(e.clarifications)&&e.clarifications>=0&&e.clarifications<=1&&['measured','unmeasured'].includes(e.directComparison?.status),'new_owned_runtime_evidence_required');
  const retained=e.storedReadbackRef?.length>0,used=e.nextStep?.reference?.length>0&&e.nextStep?.decision?.length>0;
  if(e.httpStatus===null)need(e.businessStatus!=='completed'&&e.failureStage?.evidenceRef?.length>0&&e.failureStage?.reason?.length>0,'truthful_missing_http_evidence_required');
  if(!retained||!used){need(e.businessStatus!=='completed'&&e.failureStage?.evidenceRef?.length>0&&e.failureStage?.reason?.length>0,'missing_stage_evidence_required');
    if(!retained)need(['not_reached','refused','unknown'].includes(e.storageOutcome),'truthful_storage_outcome_required');
    if(!used)need(e.nextStep?.state==='not_reached'&&e.nextStep.reason?.length>0,'truthful_next_step_outcome_required');}
  if(e.directComparison.status==='measured')need(e.directComparison.sameInputRef===e.inputRef&&e.directComparison.resultRef?.length>0,'same_direct_input_required');
  else need(e.directComparison.reason?.length>0,'unmeasured_reason_required');
  need(e.observed===true&&e.sanitizedOwnedInput===true,'observed_owned_evidence_required');return e;
}
export async function journalMutation(j,name,body,save,write,{afterMutation}={}){
  let op=j.operations[name];if(op){need(op.bodyHash===hash(body),'immutable_operation_input_changed');need(op.state==='confirmed','unknown_outcome_quarantined');return op.result;}
  op={key:'funded-'+j.operation+'-'+name,body,bodyHash:hash(body),state:'in_flight',startedAt:new Date().toISOString()};j.operations[name]=op;await save();
  try{op.result=await write(op.key);await afterMutation?.(name,op.result);op.state='confirmed';op.finishedAt=new Date().toISOString();await save();return op.result;}
  catch{op.state='unknown';op.failedAt=new Date().toISOString();await save();throw new Error('unknown_outcome_quarantined');}
}
