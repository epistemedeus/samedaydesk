import {AeError} from './errors.mjs';
import {FEE_BPS, ROUNDING_PROFILE, feePerCapture} from './fee.mjs';

// Read-only pins. Validators are F1's exported freezeQuote and checked, injected
// by the caller. This module does not copy schema bytes or hard-code f1Ready.
export const F1_SOURCE = Object.freeze({
  received: 'fe2f7b8ac2440ec526ceca713f0c26fa7bc1d612',
  commit: 'e16f7812c7eaa563c3effcbbbb99c8f42df3cdbc',
  schemaV2: 'foundation.v2',
  schemaV3: 'foundation.v3',
  feeProfile: ROUNDING_PROFILE,
});

// Historical request ids. Status lives in packages/C/CONTRACT-REQUESTS.md.
export const MISMATCHES = Object.freeze([
  {id: 'fee.rounding', status: 'satisfied'},
  {id: 'funding.state', status: 'obsolete'},
  {id: 'acceptance.approval_pending', status: 'satisfied'},
  {id: 'quote.contributor_before_selection', status: 'obsolete'},
  {id: 'obligation.read_without_wallet', status: 'satisfied'},
  {id: 'actor.not_request_json', status: 'satisfied'},
  {id: 'operation.kind', status: 'satisfied'},
  {id: 'public_listing.amounts', status: 'satisfied'},
  {id: 'refund.earlier_than_shared_expiry', status: 'satisfied'},
  {id: 'wallet.export_is_not_revocation', status: 'satisfied'},
  {id: 'operator_capture_is_not_acceptance', status: 'satisfied'},
  {id: 'measurements.separate', status: 'satisfied'},
  {id: 'claim.authority', status: 'satisfied'},
  {id: 'one_proof_one_allocation', status: 'satisfied'},
]);

export function mismatchIds() {
  return MISMATCHES.map(row => row.id);
}

export function singleCaptureQuote(f1, {gross, railCost = '0'} = {}) {
  if (!f1?.BASE_USDC || !f1?.COMMERCE_PAYMENTS_PIN) throw new AeError('f1_validator_required', 1);
  const fee = feePerCapture(gross);
  const net = (BigInt(gross) - BigInt(fee) - BigInt(railCost)).toString();
  return {
    schemaVersion: 'pilot.agent-economy.v2',
    quoteId: 'quote-c',
    tenantId: 'tenant-a',
    taskId: 'task-c',
    canonicalTaskId: 'kernel-c',
    taskVersion: 1,
    termsVersion: 'terms-c',
    requesterId: 'requester',
    evaluatorId: 'evaluator',
    contributorId: 'contributor',
    payoutDestination: '0x2222222222222222222222222222222222222222',
    fundingAuthorityId: 'funding-authority',
    settlementAuthorityId: 'settlement-authority',
    asset: {...f1.BASE_USDC},
    gross,
    contributorNet: net,
    platformFee: fee,
    subsidy: '0',
    feeRecipient: '0x1111111111111111111111111111111111111111',
    fee: {
      schemaVersion: 'pilot.agent-economy.v2',
      bps: FEE_BPS,
      basis: 'new_job_gross',
      profile: {
        id: ROUNDING_PROFILE,
        rounding: 'per_capture_floor',
        mode: 'single_capture',
        escrow: {...f1.COMMERCE_PAYMENTS_PIN},
      },
    },
    rail: {mode: 'platform_subsidy', costCap: railCost},
    fundingTarget: '0x3333333333333333333333333333333333333333',
    expiresAt: '2099-01-01T00:00:00.000Z',
    rules: {
      partial: 'accepted_gross_only',
      refund: 'unaccepted_gross_only',
      dispute: 'hold_until_authoritative_resolution',
      reversal: 'reconcile_without_repricing_earned_obligation',
      rightsTermsRef: 'terms:rights-v1',
    },
  };
}

export function projectQuote(quote, f1, assets) {
  if (!f1 || typeof f1.freezeQuote !== 'function' || typeof f1.checked !== 'function') {
    throw new AeError('f1_validator_required', 1);
  }
  try {
    const frozen = assets ? f1.freezeQuote(quote, assets) : f1.freezeQuote(quote);
    f1.checked('QuoteV2', frozen);
    return {f1Ready: true, reason: null, quote: frozen, profile: ROUNDING_PROFILE};
  } catch (error) {
    const reason = typeof error?.code === 'string' && /^[a-z0-9_]+$/.test(error.code) ? error.code : 'f1_rejected';
    return {f1Ready: false, reason, quote, profile: ROUNDING_PROFILE};
  }
}
