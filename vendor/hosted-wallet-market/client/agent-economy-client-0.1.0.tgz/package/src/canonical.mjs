import {hash, need} from './c0/participant-wire.mjs';

// Same canonical JSON as tools/ops/funded-continuation/participant.mjs at 9a4be483.
// Used so a resumed operation rebuilds one body hash independent of key order.
export function canonicalJson(x) {
  if (x === null || typeof x === 'boolean' || typeof x === 'string') return JSON.stringify(x);
  if (typeof x === 'number') {
    need(Number.isFinite(x) && Number.isInteger(x), 'canonical_integer_required');
    return JSON.stringify(x);
  }
  if (Array.isArray(x)) return '[' + x.map(canonicalJson).join(',') + ']';
  need(x && typeof x === 'object', 'canonical_object_required');
  return '{' + Object.keys(x).sort().filter(k => x[k] !== undefined).map(k => JSON.stringify(k) + ':' + canonicalJson(x[k])).join(',') + '}';
}

export function digest(value) {
  return hash(canonicalJson(value));
}
