import {createHash, randomBytes} from 'node:crypto';
import {constants} from 'node:fs';
import {open} from 'node:fs/promises';
import http from 'node:http';
import https from 'node:https';
import path from 'node:path';
import {AeError} from './errors.mjs';
import {openJobJournal, saveJobSubmit} from './journal.mjs';
import {assertOrigin} from './profile.mjs';

// Configured read of a free machine-gateway job route. The origin, bearer
// file, route prefix, and mount come from the caller. Nothing here picks a
// loopback, sends a payment header, funds a job, or replays a submit.
const CONFIG_KEYS = new Set(['origin', 'tokenFile', 'routePrefix', 'basePath', 'caFile', 'mode']);
const JOB_KEYS = Object.freeze([
  'schema', 'mode', 'qualification', 'railJoin', 'evidence', 'operation', 'jobId', 'state',
  'completion', 'complete', 'resultReady', 'paymentAttempts', 'newPayment', 'gap',
  'paymentCompleted', 'artifact',
]);
const SCHEMA_KEYS = new Set([
  'type', 'const', 'enum', 'pattern', 'minLength', 'maxLength', 'minimum', 'maximum', 'properties', 'required',
  'additionalProperties', 'anyOf', 'items', 'minItems', 'maxItems',
]);
const JOB_ID = /^j[a-f0-9]{32}$/;
const RECEIPT_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const ROUTE_PREFIX = /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,54}$/;
const BASE_PATH = /^\/(?:[a-z0-9-]+\/?)+$/;
const TOKEN = /^[A-Za-z0-9_-]{32,256}$/;
const SAFE_PATTERN = /^[A-Za-z0-9^[\]{}$|+*?().\\_-]{1,80}$/;
// 0.1.1 is the discovery version the mounted gateway emits. Anything else stays refused.
const DISCOVERY_VERSIONS = new Set(['0.1.0', '0.1.1']);
const BODY_KEY = /^[A-Za-z0-9_.-]{8,128}$/;
const URL_EXTRACT_READ_KEYS = Object.freeze([
  'jobId', 'title', 'status', 'requestedUrl', 'fetch_mode', 'completion', 'digest', 'state',
  'reason', 'attempts', 'paymentAttempts', 'newPayment', 'verdict', 'code',
]);

export function artifactDigest({kind, body}) {
  const canonical = JSON.stringify({body, kind});
  return createHash('sha256').update(canonical).digest('hex');
}

async function readPrivate(file, {max}) {
  if (typeof file !== 'string' || !path.isAbsolute(file)) throw new AeError('config_refused', 1);
  const handle = await open(file, constants.O_RDONLY | constants.O_NOFOLLOW);
  try {
    const stat = await handle.stat();
    if (!stat.isFile() || stat.uid !== process.getuid() || (stat.mode & 0o077) !== 0 || stat.size < 1 || stat.size > max) {
      throw new AeError('private_file_refused', 1);
    }
    return handle.readFile();
  } finally {
    await handle.close();
  }
}

export async function readJobConfig(file) {
  let parsed;
  try {
    parsed = JSON.parse((await readPrivate(file, {max: 65536})).toString('utf8'));
  } catch (error) {
    if (error instanceof AeError) throw error;
    throw new AeError('config_refused', 1);
  }
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new AeError('config_refused', 1);
  for (const key of Object.keys(parsed)) {
    if (!CONFIG_KEYS.has(key)) throw new AeError('config_refused', 1);
  }
  if (parsed.mode !== undefined && (typeof parsed.mode !== 'string' || !/^[a-z][a-z0-9_-]{0,31}$/.test(parsed.mode))) {
    throw new AeError('config_refused', 1);
  }
  let origin;
  try { origin = assertOrigin(parsed.origin); } catch (error) {
    if (error instanceof AeError) throw error;
    throw new AeError('origin_refused', 1);
  }
  if (typeof parsed.routePrefix !== 'string' || !ROUTE_PREFIX.test(parsed.routePrefix)) throw new AeError('config_refused', 1);
  if (typeof parsed.basePath !== 'string' || !BASE_PATH.test(parsed.basePath) || parsed.basePath.endsWith('/')) {
    throw new AeError('config_refused', 1);
  }
  const httpsOrigin = origin.startsWith('https:');
  if (httpsOrigin && !parsed.caFile) throw new AeError('ca_required', 1);
  if (!httpsOrigin && parsed.caFile) throw new AeError('config_refused', 1);
  const token = (await readPrivate(parsed.tokenFile, {max: 512})).toString('utf8').trim();
  if (!TOKEN.test(token)) throw new AeError('gateway_credential_required', 1);
  const ca = httpsOrigin ? await readPrivate(parsed.caFile, {max: 1024 * 1024}) : undefined;
  return {origin, token, routePrefix: parsed.routePrefix, basePath: parsed.basePath, ca};
}

function assertSupported(schema, depth = 0) {
  if (depth > 6 || !schema || typeof schema !== 'object' || Array.isArray(schema)) throw new AeError('capability_schema_unsupported', 1);
  for (const key of Object.keys(schema)) {
    if (!SCHEMA_KEYS.has(key)) throw new AeError('capability_schema_unsupported', 1);
  }
  if (schema.type !== undefined && typeof schema.type !== 'string') throw new AeError('capability_schema_unsupported', 1);
  if (schema.type === 'object' && schema.additionalProperties !== false) throw new AeError('capability_schema_refused', 1);
  if (schema.pattern !== undefined && (typeof schema.pattern !== 'string' || !SAFE_PATTERN.test(schema.pattern))) {
    throw new AeError('capability_schema_unsupported', 1);
  }
  if (schema.anyOf !== undefined) {
    if (!Array.isArray(schema.anyOf) || schema.anyOf.length < 1 || schema.anyOf.length > 8) throw new AeError('capability_schema_unsupported', 1);
    for (const branch of schema.anyOf) assertSupported(branch, depth + 1);
  }
  if (schema.properties !== undefined) {
    if (!schema.properties || typeof schema.properties !== 'object' || Array.isArray(schema.properties)) {
      throw new AeError('capability_schema_unsupported', 1);
    }
    for (const child of Object.values(schema.properties)) assertSupported(child, depth + 1);
  }
  if (schema.items !== undefined) assertSupported(schema.items, depth + 1);
}

function typeOk(type, value) {
  if (type === 'string') return typeof value === 'string';
  if (type === 'boolean') return typeof value === 'boolean';
  if (type === 'null') return value === null;
  if (type === 'integer') return typeof value === 'number' && Number.isInteger(value);
  if (type === 'object') return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
  if (type === 'array') return Array.isArray(value);
  return false;
}

function matches(schema, value) {
  if (schema.anyOf) return schema.anyOf.some(branch => matches(branch, value));
  if (Object.hasOwn(schema, 'const') && !Object.is(schema.const, value)) return false;
  if (schema.enum && (!Array.isArray(schema.enum) || !schema.enum.some(item => Object.is(item, value)))) return false;
  if (schema.type && !typeOk(schema.type, value)) return false;
  if (typeof value === 'string') {
    if (schema.minLength !== undefined && value.length < schema.minLength) return false;
    if (schema.maxLength !== undefined && value.length > schema.maxLength) return false;
    if (schema.pattern && !new RegExp(schema.pattern).test(value)) return false;
  }
  if (schema.type === 'object') {
    const properties = schema.properties || {};
    if (schema.required) {
      for (const key of schema.required) if (!Object.hasOwn(value, key)) return false;
    }
    for (const key of Object.keys(value)) {
      if (!Object.hasOwn(properties, key) || !matches(properties[key], value[key])) return false;
    }
  }
  return true;
}

function gatewayPath(basePath, value) {
  if (typeof value !== 'string' || !value.startsWith(`${basePath}/`) || value.includes('?') || value.includes('#') || value.includes('://') || value.includes('..')) {
    throw new AeError('capability_mismatch', 1);
  }
  return value;
}

function assertFreeRoute(route, budgetUnit) {
  if (!route || route.executable !== true || route.price?.amount !== 0 || route.price?.unit !== budgetUnit) {
    throw new AeError('free_route_required', 1);
  }
}

function assertInputSchema(schema) {
  assertSupported(schema);
  const keys = schema.properties ? Object.keys(schema.properties) : [];
  const job = schema.properties?.jobId;
  if (schema.type !== 'object' || keys.length !== 1 || keys[0] !== 'jobId' || !Array.isArray(schema.required) || schema.required.length !== 1 || schema.required[0] !== 'jobId') {
    throw new AeError('capability_schema_refused', 1);
  }
  if (job?.type !== 'string' || job.pattern !== '^j[a-f0-9]{32}$') throw new AeError('capability_schema_refused', 1);
}

function assertOutputSchema(schema) {
  assertSupported(schema);
  if (schema.type !== 'object' || !Array.isArray(schema.required) || schema.required.length !== JOB_KEYS.length) {
    throw new AeError('capability_schema_refused', 1);
  }
  const required = new Set(schema.required);
  if (!JOB_KEYS.every(key => required.has(key))) throw new AeError('capability_schema_refused', 1);
}

function projectJob(output) {
  if (output.paymentAttempts !== 0 || output.newPayment !== false || output.paymentCompleted !== false) {
    throw new AeError('payment_refused', 1);
  }
  const artifact = output.artifact === null ? null : {
    kind: output.artifact.kind,
    digest: output.artifact.digest,
    body: output.artifact.body,
  };
  if (artifact && artifact.digest !== artifactDigest(artifact)) throw new AeError('artifact_digest_mismatch', 1);
  return {
    schema: output.schema,
    mode: output.mode,
    qualification: output.qualification,
    railJoin: output.railJoin,
    evidence: output.evidence,
    operation: output.operation,
    jobId: output.jobId,
    state: output.state,
    completion: output.completion,
    complete: output.complete,
    resultReady: output.resultReady,
    paymentAttempts: output.paymentAttempts,
    newPayment: output.newPayment,
    gap: output.gap,
    paymentCompleted: output.paymentCompleted,
    artifact,
  };
}

function present(operation, receipt, job) {
  const artifact = job?.artifact ?? null;
  const evidence = job?.evidence;
  return {
    schema: 'ae.job-read.v1',
    operation,
    fixture: evidence === 'synthetic-fixture' || evidence === 'disposable-stand-in' ? true : job ? false : null,
    gateway: {
      schema: receipt.schema,
      id: receipt.id,
      status: receipt.status,
      routeId: receipt.routeId,
      priceAmount: receipt.price.amount,
      priceUnit: receipt.price.unit,
      paymentState: receipt.payment.state,
      errorCode: receipt.error ? receipt.error.code : null,
      readbackPath: receipt.readbackPath,
    },
    job,
    bytes: artifact ? artifact.body : null,
    digest: artifact ? artifact.digest : null,
  };
}

function requestJson(origin, pathname, {method = 'GET', body, ca, token, idempotencyKey, timeoutMs}) {
  const url = new URL(pathname, origin);
  if (url.origin !== origin || url.search || url.hash || url.username || url.password) throw new AeError('origin_refused', 1);
  if (url.protocol === 'https:' && process.env.NODE_TLS_REJECT_UNAUTHORIZED === '0') throw new AeError('verified_same_origin_required', 1);
  const payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
  const headers = {
    accept: 'application/json',
    connection: 'close',
    authorization: `Bearer ${token}`,
  };
  if (payload) {
    headers['content-type'] = 'application/json';
    headers['content-length'] = String(payload.length);
  }
  if (idempotencyKey) headers['idempotency-key'] = idempotencyKey;
  return new Promise((resolve, reject) => {
    let settled = false;
    const fail = error => {
      if (settled) return;
      settled = true;
      reject(error);
    };
    const transport = url.protocol === 'https:' ? https : http;
    const req = transport.request(url, {
      method,
      agent: false,
      ...(ca ? {ca, rejectUnauthorized: true} : {}),
      timeout: timeoutMs,
      headers,
    }, res => {
      const chunks = [];
      let size = 0;
      res.on('data', chunk => {
        size += chunk.length;
        if (size > 262144) {
          req.destroy();
          fail(new AeError('response_too_large', 1));
        } else chunks.push(chunk);
      });
      res.on('error', () => fail(new AeError('response_interrupted', 2)));
      res.on('aborted', () => fail(new AeError('response_interrupted', 2)));
      res.on('end', () => {
        if (settled) return;
        settled = true;
        if (res.statusCode >= 300 && res.statusCode < 400) {
          reject(new AeError('redirect_refused', 1));
          return;
        }
        const type = String(res.headers['content-type'] || '');
        if (!/^application\/json(?:;|$)/i.test(type)) {
          reject(new AeError('invalid_json', 1));
          return;
        }
        let document;
        try { document = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
        catch { reject(new AeError('invalid_json', 1)); return; }
        resolve({status: res.statusCode, body: document});
      });
    });
    req.on('error', () => fail(new AeError(url.protocol === 'https:' ? 'https_transport_unknown' : 'transport_failed', 2)));
    req.on('timeout', () => {
      req.destroy();
      fail(new AeError('timeout', 2));
    });
    req.end(payload ?? undefined);
  });
}

function failHttp(response) {
  const code = response.body?.error?.code;
  if (typeof code === 'string' && /^[a-z][a-z0-9_]*$/.test(code)) {
    const exit = response.status === 401 ? 3 : response.status === 404 ? 5 : 1;
    throw new AeError(code, exit);
  }
  throw new AeError('gateway_refused', 1);
}

function assertReceipt(receipt, {basePath, routeId, budgetUnit}) {
  if (!receipt || receipt.schema !== 'neomorphic.machine-gateway.receipt.v1' || !RECEIPT_ID.test(receipt.id || '')) {
    throw new AeError('receipt_refused', 1);
  }
  if (!['running', 'completed', 'failed', 'uncertain'].includes(receipt.status)) throw new AeError('receipt_refused', 1);
  if (routeId && receipt.routeId !== routeId) throw new AeError('receipt_route_refused', 1);
  if (receipt.price?.amount !== 0 || receipt.price?.unit !== budgetUnit) throw new AeError('free_route_required', 1);
  if (receipt.payment?.state !== 'not_required') throw new AeError('payment_refused', 1);
  if (receipt.error !== null && (typeof receipt.error?.code !== 'string' || !/^[a-z][a-z0-9_]*$/.test(receipt.error.code))) {
    throw new AeError('receipt_refused', 1);
  }
  if (receipt.readbackPath !== `${basePath}/v1/receipts/${receipt.id}`) throw new AeError('receipt_refused', 1);
}

function checkedJob(output, schema, {operation, jobId}) {
  if (!matches(schema, output)) throw new AeError('job_output_refused', 1);
  const job = projectJob(output);
  if (operation !== 'receipt') {
    if (job.operation !== operation || job.jobId !== jobId || job.gap !== null) throw new AeError('job_binding_refused', 1);
  }
  if (job.operation === 'result' && job.complete === true && job.artifact === null) throw new AeError('job_output_refused', 1);
  return job;
}

function assertUrlExtractReadSchema(schema) {
  assertSupported(schema);
  if (schema.type !== 'object' || !Array.isArray(schema.required) || schema.required.length !== URL_EXTRACT_READ_KEYS.length) {
    throw new AeError('capability_schema_refused', 1);
  }
  const required = new Set(schema.required);
  if (!URL_EXTRACT_READ_KEYS.every(key => required.has(key))) throw new AeError('capability_schema_refused', 1);
}

function assertUrlExtractSubmitSchema(schema) {
  const idem = schema?.properties?.idempotencyKey;
  // The published quantifier is `{8,128}`. A comma is not in the general pattern
  // allowlist, so accept only this exact charset and check the rest normally.
  if (idem?.pattern !== '^[A-Za-z0-9_.-]{8,128}$') throw new AeError('capability_schema_refused', 1);
  assertSupported({
    ...schema,
    properties: { ...schema.properties, idempotencyKey: { ...idem, pattern: '^[A-Za-z0-9_.-]{8}$' } },
  });
  const keys = schema.properties ? Object.keys(schema.properties) : [];
  if (schema.type !== 'object' || !Array.isArray(schema.required) || schema.required.length !== 2) {
    throw new AeError('capability_schema_refused', 1);
  }
  const required = new Set(schema.required);
  if (!required.has('url') || !required.has('idempotencyKey') || keys.length !== 2) throw new AeError('capability_schema_refused', 1);
}

function projectUrlExtract(output, jobId) {
  if (!output || typeof output !== 'object') throw new AeError('job_output_refused', 1);
  if (output.paymentAttempts !== 0 || output.newPayment !== false) throw new AeError('payment_refused', 1);
  if (typeof output.jobId !== 'string' || !JOB_ID.test(output.jobId)) throw new AeError('job_output_refused', 1);
  if (jobId && output.jobId !== jobId) throw new AeError('job_binding_refused', 1);
  if (!['pending', 'ready', 'failed'].includes(output.completion)) throw new AeError('job_output_refused', 1);
  if (output.digest !== null && (typeof output.digest !== 'string' || !/^[a-f0-9]{64}$/.test(output.digest))) {
    throw new AeError('digest_mismatch', 1);
  }
  return output;
}

function presentUrlExtract(operation, receipt, job) {
  return {
    schema: 'ae.job-read.v1',
    operation,
    jobId: job?.jobId ?? null,
    completion: job?.completion ?? null,
    digest: job?.digest ?? null,
    receiptId: receipt.id,
    gateway: {
      schema: receipt.schema,
      id: receipt.id,
      status: receipt.status,
      routeId: receipt.routeId,
      errorCode: receipt.error ? receipt.error.code : null,
      readbackPath: receipt.readbackPath,
    },
    job,
  };
}

function httpsUrl(value) {
  let url;
  try { url = new URL(value); } catch { throw new AeError('usage', 1); }
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash || url.href.length > 2048) {
    throw new AeError('usage', 1);
  }
  return url.href;
}

export async function submitJob({home, configPath, url, idempotencyKey, timeoutMs}) {
  if (!Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 120000) throw new AeError('timeout_refused', 1);
  const target = httpsUrl(url);
  const bodyKey = idempotencyKey === undefined ? randomBytes(18).toString('hex') : idempotencyKey;
  if (!BODY_KEY.test(bodyKey)) throw new AeError('usage', 1);
  const config = await readJobConfig(configPath);
  if (config.routePrefix !== 'url.extract') throw new AeError('capability_not_offered', 1);
  const call = (pathname, options = {}) => requestJson(config.origin, pathname, {token: config.token, ca: config.ca, timeoutMs, ...options});
  const discovered = await call(`${config.basePath}/v1/discover`);
  if (discovered.status !== 200) failHttp(discovered);
  const discovery = discovered.body;
  if (discovery?.schema !== 'neomorphic.machine-gateway.discovery.v1' || !DISCOVERY_VERSIONS.has(discovery.version) || discovery.basePath !== config.basePath) {
    throw new AeError('capability_mismatch', 1);
  }
  if (discovery.paths?.quote !== `${config.basePath}/v1/quote` || discovery.paths?.execute !== `${config.basePath}/v1/execute` || discovery.paths?.receipt !== `${config.basePath}/v1/receipts/{id}`) {
    throw new AeError('capability_mismatch', 1);
  }
  const route = discovery.routes?.find(item => item.id === 'url.extract.submit');
  if (!route) throw new AeError('capability_not_offered', 1);
  assertFreeRoute(route, discovery.budgetUnit);
  const inputSchema = await call(gatewayPath(config.basePath, route.inputSchemaPath));
  if (inputSchema.status !== 200) failHttp(inputSchema);
  assertUrlExtractSubmitSchema(inputSchema.body);
  const outputSchema = await call(gatewayPath(config.basePath, route.outputSchemaPath));
  if (outputSchema.status !== 200) failHttp(outputSchema);
  assertSupported(outputSchema.body);
  const tokenDigest = createHash('sha256').update(config.token).digest('hex');
  const opened = await openJobJournal(home, config.origin);
  const id = `${tokenDigest}:${bodyKey}`;
  const prior = opened.journal.entries[id];
  const gatewayKey = prior?.gatewayKey || randomBytes(16).toString('hex');
  if (prior && (prior.url !== target || prior.bodyKey !== bodyKey)) throw new AeError('immutable_operation_input_changed', 6);
  // Durable before the quote or execute POST. A lost response resends this pair.
  await saveJobSubmit(opened.file, opened.journal, id, {bodyKey, gatewayKey, url: target, jobId: prior?.jobId ?? null, quoteId: prior?.quoteId ?? null});
  if (prior?.jobId) return {schema: 'ae.job-read.v1', operation: 'submit', jobId: prior.jobId, completion: null, digest: null, receiptId: prior.receiptId ?? null, replayed: true};
  const input = {url: target, idempotencyKey: bodyKey};
  let quoteId = prior?.quoteId ?? null;
  if (!quoteId) {
    const quote = await call(discovery.paths.quote, {method: 'POST', body: {routeId: route.id, input}});
    if (quote.status !== 200) failHttp(quote);
    const quoted = quote.body;
    if (quoted?.schema !== 'neomorphic.machine-gateway.quote.v1' || quoted.routeId !== route.id || quoted.tenantBound !== true || quoted.executable !== true || quoted.requirements !== null || quoted.price?.amount !== 0 || quoted.price?.unit !== discovery.budgetUnit || !RECEIPT_ID.test(quoted.quoteId || '')) {
      throw new AeError('free_route_required', 1);
    }
    quoteId = quoted.quoteId;
    await saveJobSubmit(opened.file, opened.journal, id, {bodyKey, gatewayKey, url: target, quoteId, jobId: null});
  }
  const executed = await call(discovery.paths.execute, {
    method: 'POST',
    idempotencyKey: gatewayKey,
    body: {quoteId, input, maxUnits: 0},
  });
  if (executed.status !== 200 && executed.status !== 202) failHttp(executed);
  const receipt = executed.body;
  assertReceipt(receipt, {basePath: config.basePath, routeId: route.id, budgetUnit: discovery.budgetUnit});
  const job = projectUrlExtract(receipt.output);
  await saveJobSubmit(opened.file, opened.journal, id, {bodyKey, gatewayKey, url: target, quoteId, jobId: job.jobId, receiptId: receipt.id});
  return presentUrlExtract('submit', receipt, job);
}

export async function receiveJob({operation, configPath, jobId, receiptId, timeoutMs, home}) {
  if (!['poll', 'result', 'receipt'].includes(operation)) throw new AeError('usage', 1);
  if (!Number.isInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 120000) throw new AeError('timeout_refused', 1);
  if (operation === 'receipt') {
    if (!RECEIPT_ID.test(receiptId || '')) throw new AeError('invalid_receipt_id', 1);
  } else if (!JOB_ID.test(jobId || '')) throw new AeError('invalid_job_id', 1);
  const config = await readJobConfig(configPath);
  const call = (pathname, options = {}) => requestJson(config.origin, pathname, {token: config.token, ca: config.ca, timeoutMs, ...options});
  const discovered = await call(`${config.basePath}/v1/discover`);
  if (discovered.status !== 200) failHttp(discovered);
  const discovery = discovered.body;
  if (discovery?.schema !== 'neomorphic.machine-gateway.discovery.v1' || !DISCOVERY_VERSIONS.has(discovery.version) || discovery.basePath !== config.basePath) {
    throw new AeError('capability_mismatch', 1);
  }
  if (discovery.paths?.quote !== `${config.basePath}/v1/quote` || discovery.paths?.execute !== `${config.basePath}/v1/execute` || discovery.paths?.receipt !== `${config.basePath}/v1/receipts/{id}`) {
    throw new AeError('capability_mismatch', 1);
  }
  if (!Array.isArray(discovery.routes) || typeof discovery.budgetUnit !== 'string') throw new AeError('capability_mismatch', 1);
  const routeFor = id => discovery.routes.find(route => route.id === id);
  const schemas = new Map();
  const loadOutput = async route => {
    if (schemas.has(route.id)) return schemas.get(route.id);
    assertFreeRoute(route, discovery.budgetUnit);
    const outputPath = gatewayPath(config.basePath, route.outputSchemaPath);
    const response = await call(outputPath);
    if (response.status !== 200) failHttp(response);
    (config.routePrefix === 'url.extract' ? assertUrlExtractReadSchema : assertOutputSchema)(response.body);
    schemas.set(route.id, response.body);
    return response.body;
  };
  if (operation === 'receipt') {
    const response = await call(`${config.basePath}/v1/receipts/${receiptId}`);
    if (response.status !== 200) failHttp(response);
    const receipt = response.body;
    const route = routeFor(receipt?.routeId);
    if (!route || !route.id.startsWith(`${config.routePrefix}.`)) throw new AeError('receipt_route_refused', 1);
    assertReceipt(receipt, {basePath: config.basePath, routeId: route.id, budgetUnit: discovery.budgetUnit});
    const outputSchema = await loadOutput(route);
    const urlExtract = config.routePrefix === 'url.extract';
    const job = receipt.output === null ? null : (urlExtract ? projectUrlExtract(receipt.output) : checkedJob(receipt.output, outputSchema, {operation}));
    return urlExtract ? presentUrlExtract(operation, receipt, job) : present(operation, receipt, job);
  }
  const urlExtract = config.routePrefix === 'url.extract';
  if (operation === 'result' && urlExtract && home) {
    const tokenDigest = createHash('sha256').update(config.token).digest('hex');
    const opened = await openJobJournal(home, config.origin);
    const slot = `${tokenDigest}:result:${jobId}`;
    const prior = opened.journal.entries[slot];
    if (prior?.receiptId) {
      const stored = await call(`${config.basePath}/v1/receipts/${prior.receiptId}`);
      if (stored.status !== 200) failHttp(stored);
      const receipt = stored.body;
      const storedRoute = routeFor(receipt?.routeId);
      if (!storedRoute || !storedRoute.id.startsWith(`${config.routePrefix}.`)) throw new AeError('receipt_route_refused', 1);
      assertReceipt(receipt, {basePath: config.basePath, routeId: storedRoute.id, budgetUnit: discovery.budgetUnit});
      const job = projectUrlExtract(receipt.output, jobId);
      return presentUrlExtract(operation, receipt, job);
    }
  }
  const route = routeFor(`${config.routePrefix}.${operation}`);
  if (!route) throw new AeError('capability_not_offered', 1);
  assertFreeRoute(route, discovery.budgetUnit);
  const inputPath = gatewayPath(config.basePath, route.inputSchemaPath);
  const inputSchema = await call(inputPath);
  if (inputSchema.status !== 200) failHttp(inputSchema);
  assertInputSchema(inputSchema.body);
  const outputSchema = await loadOutput(route);
  const input = {jobId};
  const quote = await call(discovery.paths.quote, {method: 'POST', body: {routeId: route.id, input}});
  if (quote.status !== 200) failHttp(quote);
  const quoted = quote.body;
  if (quoted?.schema !== 'neomorphic.machine-gateway.quote.v1' || quoted.routeId !== route.id || quoted.tenantBound !== true || quoted.executable !== true || quoted.requirements !== null || quoted.price?.amount !== 0 || quoted.price?.unit !== discovery.budgetUnit || !RECEIPT_ID.test(quoted.quoteId || '')) {
    throw new AeError('free_route_required', 1);
  }
  const executed = await call(discovery.paths.execute, {
    method: 'POST',
    idempotencyKey: randomBytes(24).toString('hex'),
    body: {quoteId: quoted.quoteId, input, maxUnits: 0},
  });
  if (executed.status !== 200 && executed.status !== 202) failHttp(executed);
  const receipt = executed.body;
  assertReceipt(receipt, {basePath: config.basePath, routeId: route.id, budgetUnit: discovery.budgetUnit});
  // A forbidden read is a failed receipt, not an HTTP error. Surface that code.
  if (receipt.error && (receipt.error.code === 'e08_job_forbidden' || receipt.error.code === 'route_forbidden')) {
    throw new AeError(receipt.error.code, 1);
  }
  const job = receipt.status === 'completed'
    ? (urlExtract ? projectUrlExtract(receipt.output, jobId) : checkedJob(receipt.output, outputSchema, {operation, jobId}))
    : null;
  if (receipt.status === 'completed' && receipt.output === null) throw new AeError('job_output_refused', 1);
  if (operation === 'result' && urlExtract && home && receipt.id) {
    const tokenDigest = createHash('sha256').update(config.token).digest('hex');
    const opened = await openJobJournal(home, config.origin);
    await saveJobSubmit(opened.file, opened.journal, `${tokenDigest}:result:${jobId}`, {jobId, receiptId: receipt.id});
  }
  return urlExtract ? presentUrlExtract(operation, receipt, job) : present(operation, receipt, job);
}
