import {lstatSync, readFileSync} from 'node:fs';
import path from 'node:path';
import {AeError} from './errors.mjs';

const SCHEMA_NAME = /^[a-z][a-z0-9_]{0,62}$/;
const IDENTIFIER = /^[0-9]{1,20}$/;

// Reads the H1 0600 binding and returns the identity the client may store.
// The database URL, certificate paths, and passwords stay in the file.
export function readBindingIdentity(file) {
  if (typeof file !== 'string' || !path.isAbsolute(file)) throw new AeError('resolved_binding_required', 1);
  let info;
  try {
    info = lstatSync(file);
  } catch {
    throw new AeError('resolved_binding_required', 1);
  }
  if (!info.isFile() || (info.mode & 0o777) !== 0o600) throw new AeError('resolved_binding_mode', 1);
  let body;
  try {
    body = JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    throw new AeError('resolved_binding_refused', 1);
  }
  const database = body?.database;
  if (!database || typeof database !== 'object' || Array.isArray(database)) throw new AeError('resolved_binding_refused', 1);
  if (database.capability !== 'verify-full' || typeof database.url !== 'string') throw new AeError('resolved_binding_refused', 1);
  if (!SCHEMA_NAME.test(database.schema || '') || database.schema === 'public' || database.schema.startsWith('pg_')) {
    throw new AeError('resolved_binding_refused', 1);
  }
  if (!IDENTIFIER.test(database.systemIdentifier || '')) throw new AeError('resolved_binding_refused', 1);
  let parsed;
  try {
    parsed = new URL(database.url);
  } catch {
    throw new AeError('resolved_binding_refused', 1);
  }
  if (!['postgresql:', 'postgres:'].includes(parsed.protocol) || parsed.hash) throw new AeError('resolved_binding_refused', 1);
  if (parsed.password || parsed.searchParams.has('password')) throw new AeError('resolved_binding_refused', 1);
  if (parsed.hostname !== '127.0.0.1' && parsed.hostname !== 'localhost') throw new AeError('resolved_binding_refused', 1);
  const port = Number(parsed.port);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new AeError('resolved_binding_refused', 1);
  if (parsed.searchParams.get('sslmode') !== 'verify-full') throw new AeError('resolved_binding_refused', 1);
  for (const key of ['sslrootcert', 'sslcert', 'sslkey']) {
    const certPath = parsed.searchParams.get(key);
    if (typeof certPath !== 'string' || !path.isAbsolute(certPath)) throw new AeError('resolved_binding_refused', 1);
  }
  return {
    schema: database.schema,
    port,
    systemIdentifier: database.systemIdentifier,
    capability: 'verify-full',
    sslmode: 'verify-full',
  };
}
