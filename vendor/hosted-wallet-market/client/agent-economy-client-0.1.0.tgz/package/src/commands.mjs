import {createHash, randomBytes} from 'node:crypto';
import {readFileSync, fstatSync} from 'node:fs';
import {AeError} from './errors.mjs';
import {digest} from './canonical.mjs';
import {lstat, readFile} from 'node:fs/promises';
import path from 'node:path';
import {continuityEvidence, privateRead, privateWrite, nonce} from './c0/participant-wire.mjs';
import {quoteEconomics, ROUNDING_PROFILE} from './fee.mjs';
import {effectKey, openJournal, runOperation} from './journal.mjs';
import {writeProfile, writeSecret, dropSecret, assertOrigin, readProfile} from './profile.mjs';
import {call, negotiate, captureSession, valueOf} from './api.mjs';
import {assertLoopbackHttp, loopbackJson} from './loopback.mjs';
import {redact} from './redact.mjs';
import {bindLocalAsset, createLocalWallet} from './wallet-adapter.mjs';
import {resolveNetworkIdentity} from './network-identity.mjs';
import {receiveJob, submitJob} from './job-gateway.mjs';
import {readBindingIdentity} from './hosted-binding.mjs';
import {assertBoundIntent} from './eip191.mjs';
import {loadCallerSigner, signExactIntent} from './signer.mjs';
import {assessEntitled} from './retained-outcome.mjs';

export const STEP = Object.freeze({
  signup: 'signup', post: 'post', fund: 'fund', binding: 'binding', claim: 'claim',
  draft: 'draft', submit: 'submit', verdict: 'verdict', decision: 'decision',
  authority: 'authority', exit: 'exit', bind: 'bind', walletExit: 'wallet-exit',
  issue: 'issue', confirm: 'confirm',
});

function flag(flags, name, {required = true, pattern} = {}) {
  const value = flags[name];
  if (value === undefined) {
    if (required) throw new AeError('usage', 1);
    return undefined;
  }
  if (pattern && !pattern.test(value)) throw new AeError('usage', 1);
  return value;
}

async function passwordFrom(flags) {
  if (flags['secret-file'] && flags['secret-fd']) throw new AeError('one_secret_handle', 1);
  if (flags['secret-file']) {
    const parsed = await privateRead(flags['secret-file']);
    if (parsed?.schema !== 'ae.password-file.v1' || typeof parsed.password !== 'string' || parsed.password.length < 16) {
      throw new AeError('secret_handle_refused', 1);
    }
    return parsed.password;
  }
  if (flags['secret-fd']) {
    const fd = Number(flags['secret-fd']);
    if (!Number.isInteger(fd) || fd < 3) throw new AeError('secret_handle_refused', 1);
    const stat = fstatSync(fd);
    if (stat.isFile() && (stat.uid !== process.getuid() || (stat.mode & 0o077) !== 0)) throw new AeError('private_file_refused', 1);
    if (!stat.isFile() && !stat.isFIFO()) throw new AeError('secret_handle_refused', 1);
    const parsed = JSON.parse(readFileSync(fd, 'utf8'));
    if (parsed?.schema !== 'ae.password-file.v1' || typeof parsed.password !== 'string' || parsed.password.length < 16) {
      throw new AeError('secret_handle_refused', 1);
    }
    return parsed.password;
  }
  throw new AeError('secret_handle_required', 1);
}

async function operate(ctx, {operationId, name, body, meta, steps}) {
  const opened = await openJournal(ctx.home, ctx.profile.origin);
  return runOperation({
    file: opened.file,
    journal: opened.journal,
    operationId,
    name,
    bodyHash: digest(body),
    meta: redact(meta),
    steps,
  });
}

function authenticatedReadback(ctx) {
  return async key => {
    const response = await call(ctx, {method: 'GET', path: '/v1/operations', query: {idempotencyKey: key}, auth: true});
    return valueOf(response);
  };
}

export function signupSteps(ctx, {password, proof, displayName, role}) {
  const body = {password, displayName, role};
  const capture = async response => {
    await captureSession(ctx, response, {password, proof, role, displayName});
    const value = valueOf(response);
    return {sessionDelivery: value.sessionDelivery, account: value.account};
  };
  return {
    body,
    steps: [{
      name: STEP.signup,
      readback: async key => {
        try {
          const response = await call(ctx, {method: 'POST', path: '/v1/account/readback', body: {operation: 'signup'}, idempotencyKey: key, proof});
          return {state: 'recorded', response: await capture(response)};
        } catch (error) {
          if (error.code === 'not_found') return {state: 'absent'};
          throw error;
        }
      },
      write: async key => capture(await call(ctx, {method: 'POST', path: '/v1/account/signup', body, idempotencyKey: key, proof})),
    }],
  };
}

export async function profileInit(ctx, flags) {
  const name = flag(flags, 'name', {pattern: /^[a-z][a-z0-9-]{1,32}$/});
  const kind = flag(flags, 'kind', {pattern: /^(test|live)$/});
  const role = flag(flags, 'role', {pattern: /^(requester|contributor|authority)$/});
  const origin = assertOrigin(flag(flags, 'origin'));
  const networkChain = flag(flags, 'network', {required: false, pattern: /^eip155:[1-9][0-9]*$/});
  const networkClass = flag(flags, 'network-class', {required: false, pattern: /^(sandbox|public)$/});
  if (Boolean(networkChain) !== Boolean(networkClass)) throw new AeError('usage', 1);
  const receiptPath = flags['network-receipt'];
  const receiptDigest = flags['network-receipt-digest'];
  if ((receiptPath === undefined) !== (receiptDigest === undefined)) throw new AeError('usage', 1);
  let networkReceipt;
  if (receiptPath !== undefined) {
    if (!path.isAbsolute(receiptPath) || !/^[0-9a-f]{64}$/.test(receiptDigest)) throw new AeError('usage', 1);
    networkReceipt = {path: receiptPath, digest: receiptDigest};
  }
  let existing = null;
  try { existing = await readProfile(ctx.home); } catch (error) {
    if (error.code !== 'profile_required') throw error;
  }
  const profile = {schema: 'ae.profile.v1', name, kind, role, origin};
  if (networkChain) profile.network = {class: networkClass, chain: networkChain};
  if (networkReceipt) profile.networkReceipt = networkReceipt;
  if (existing && digest(existing) !== digest(profile)) throw new AeError('profile_exists', 6);
  if (!existing) await writeProfile(ctx.home, profile);
  return {profile};
}

export async function profileShow(ctx) {
  return {profile: ctx.profile};
}

export async function profileSwitchOrigin(ctx, flags) {
  const origin = assertOrigin(flag(flags, 'origin'));
  if (origin === ctx.profile.origin) throw new AeError('origin_unchanged', 1);
  await dropSecret(ctx.home);
  const profile = {...ctx.profile, origin};
  await writeProfile(ctx.home, profile);
  return {profile, credentialsDropped: true};
}

export async function discover(ctx, flags) {
  await negotiate(ctx);
  const query = {};
  if (flags.cursor) query.cursor = flags.cursor;
  if (flags.limit) query.limit = flags.limit;
  const response = await call(ctx, {method: 'GET', path: '/v1/discover', query});
  return valueOf(response);
}

export async function accountSignup(ctx, flags) {
  await negotiate(ctx);
  const displayName = flag(flags, 'display-name', {pattern: /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,40}$/});
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const password = await passwordFrom(flags);
  const proof = ctx.secret?.proof || nonce();
  ctx.secret = {
    schema: 'ae.secret.v1',
    origin: ctx.profile.origin,
    password,
    proof,
    role: ctx.profile.role,
    displayName,
    address: ctx.secret?.address,
    localSecret: ctx.secret?.localSecret,
    custody: ctx.secret?.custody,
    fixture: ctx.secret?.fixture,
  };
  await writeSecret(ctx.home, ctx.secret);
  const planned = signupSteps(ctx, {password, proof, displayName, role: ctx.profile.role});
  const run = await operate(ctx, {operationId, name: 'account.signup', body: planned.body, meta: {displayName, role: ctx.profile.role}, steps: planned.steps});
  return publicAccount(run.result);
}

function publicAccount(value) {
  return {accountId: value.account.accountId, role: value.account.role, sessionDelivery: 'cookie', recoveryCodeStored: true};
}

export async function accountSession(ctx) {
  await negotiate(ctx);
  const response = await call(ctx, {method: 'GET', path: '/v1/account/session', auth: true});
  const value = valueOf(response);
  if (/^[a-f0-9]{64}$/.test(response.headers['x-cj-csrf'] || '')) {
    ctx.secret.csrf = response.headers['x-cj-csrf'];
    await writeSecret(ctx.home, ctx.secret);
  }
  return {accountId: value.account.accountId, role: value.account.role, walletEpoch: value.walletEpoch};
}

export async function accountExit(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const body = {};
  const run = await operate(ctx, {
    operationId, name: 'account.exit', body, meta: {},
    steps: [{name: STEP.exit, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: '/v1/account/exit', body, auth: true, idempotencyKey: key}))}],
  });
  return run.result;
}

const ACTOR = /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/;

export async function walletCreate(ctx, flags) {
  if (ctx.secret?.address) throw new AeError('wallet_exists', 6);
  if (flags['wallet-module']) {
    const actor = {tenantId: flag(flags, 'tenant', {pattern: ACTOR}), actorId: flag(flags, 'actor', {pattern: ACTOR})};
    const walletId = flag(flags, 'wallet-id', {required: false, pattern: /^[a-z0-9][a-z0-9-]{7,63}$/}) || `w-${randomBytes(8).toString('hex')}`;
    const storePath = flag(flags, 'store', {required: false}) || path.join(ctx.home, 'wallet.sqlite');
    if (!path.isAbsolute(storePath)) throw new AeError('usage', 1);
    const identity = resolveNetworkIdentity(ctx.profile);
    const created = await createLocalWallet({
      modulePath: flags['wallet-module'],
      chainUrl: flag(flags, 'chain-url'),
      storePath,
      actor,
      walletId,
      identity,
    });
    ctx.secret = {
      ...(ctx.secret || {schema: 'ae.secret.v1', origin: ctx.profile.origin}),
      schema: 'ae.secret.v1',
      origin: ctx.profile.origin,
      address: created.address,
      walletId: created.walletId,
      custody: 'local_keystore',
      fixture: false,
      unlockKey: created.unlockKey,
      tenantId: actor.tenantId,
      actorId: actor.actorId,
      storePath,
      chainUrl: flags['chain-url'],
    };
    await writeSecret(ctx.home, ctx.secret);
    return {fixture: false, custody: 'local_keystore', address: created.address, chain: created.chain, walletId: created.walletId, storedLocally: true, sent: false};
  }
  if (ctx.profile?.kind !== 'test') throw new AeError('wallet_adapter_required', 1);
  const address = `fixture:receive:${randomBytes(8).toString('hex')}`;
  ctx.secret = {...(ctx.secret || {schema: 'ae.secret.v1', origin: ctx.profile.origin}), schema: 'ae.secret.v1', origin: ctx.profile.origin, address, custody: 'fake_provider_root', fixture: true};
  await writeSecret(ctx.home, ctx.secret);
  return {fixture: true, custody: 'fake_provider_root', address, storedLocally: false, sent: false};
}

export async function walletBind(ctx, flags) {
  if (flags.asset && flags['wallet-module']) {
    if (ctx.secret?.custody !== 'local_keystore' || !ctx.secret.unlockKey) throw new AeError('wallet_create_required', 1);
    if (!/^0x[a-fA-F0-9]{40}$/.test(flags.asset)) throw new AeError('usage', 1);
    const identity = resolveNetworkIdentity(ctx.profile);
    const bound = await bindLocalAsset({
      modulePath: flags['wallet-module'],
      chainUrl: flag(flags, 'chain-url'),
      storePath: ctx.secret.storePath,
      actor: {tenantId: ctx.secret.tenantId, actorId: ctx.secret.actorId},
      walletId: ctx.secret.walletId,
      token: flags.asset,
      unlockKey: ctx.secret.unlockKey,
      identity,
    });
    return {fixture: false, custody: 'local_keystore', address: ctx.secret.address, chain: bound.chain, token: bound.token, sent: false};
  }
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  if (!/^(?:0x[a-fA-F0-9]{40}|fixture:receive:[a-f0-9]{16})$/.test(ctx.secret?.address || '')) throw new AeError('wallet_create_required', 1);
  const body = {address: ctx.secret.address};
  const run = await operate(ctx, {
    operationId, name: 'wallet.bind', body, meta: body,
    steps: [{name: STEP.bind, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: '/v1/wallet/bind', body, auth: true, idempotencyKey: key}))}],
  });
  return run.result;
}

export async function walletExport(ctx) {
  await negotiate(ctx);
  const response = await call(ctx, {method: 'GET', path: '/v1/wallet/export', auth: true});
  const value = valueOf(response);
  if (value.secretIncluded !== false) throw new AeError('export_leaked_secret', 1);
  return value;
}

export async function walletExit(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const body = {};
  const run = await operate(ctx, {
    operationId, name: 'wallet.exit', body, meta: {},
    steps: [{name: STEP.walletExit, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: '/v1/wallet/exit', body, auth: true, idempotencyKey: key}))}],
  });
  return run.result;
}

export async function taskPost(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const captures = flags.captures ? flags.captures.split(',') : [flag(flags, 'gross')];
  const body = {
    title: flag(flags, 'title'),
    publicText: flag(flags, 'public-text'),
    grossAtomic: flag(flags, 'gross'),
    railCostAtomic: flag(flags, 'rail-cost'),
    feeRecipient: flag(flags, 'fee-recipient', {pattern: /^0x[a-f0-9]{40}$/}),
    captures,
  };
  const local = quoteEconomics({gross: body.grossAtomic, railCost: body.railCostAtomic, captures});
  if (local.roundingProfile !== ROUNDING_PROFILE) throw new AeError('rounding_profile_refused', 1);
  const run = await operate(ctx, {
    operationId, name: 'task.post', body, meta: body,
    steps: [{name: STEP.post, readback: authenticatedReadback(ctx), write: async key => {
      const value = valueOf(await call(ctx, {method: 'POST', path: '/v1/tasks', body, auth: true, idempotencyKey: key}));
      if (value.roundingProfile !== ROUNDING_PROFILE || value.platformFeeAtomic !== local.platformFeeAtomic || value.exactFivePercentAtEveryAtomicAmount !== false) {
        throw new AeError('quote_fee_mismatch', 1);
      }
      return value;
    }}],
  });
  return run.result;
}

export async function taskQuote(ctx, flags) {
  await negotiate(ctx);
  const taskId = flag(flags, 'task', {pattern: /^task_[A-Za-z0-9_-]{16}$/});
  const response = await call(ctx, {method: 'GET', path: `/v1/tasks/${taskId}/quote`, auth: true});
  const value = valueOf(response);
  if (value.roundingProfile !== ROUNDING_PROFILE || value.exactFivePercentAtEveryAtomicAmount !== false) throw new AeError('quote_fee_mismatch', 1);
  return value;
}

export async function taskFund(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const taskId = flag(flags, 'task', {pattern: /^task_[A-Za-z0-9_-]{16}$/});
  const evidenceKind = flag(flags, 'evidence', {pattern: /^(eip3009_authorization|balance_read|submitted_tx|verified_deposit)$/});
  const body = {evidenceKind};
  if (flags['proof-id']) body.proofId = flags['proof-id'];
  const run = await operate(ctx, {
    operationId, name: 'task.fund', body, meta: {taskId, ...body},
    steps: [{name: STEP.fund, readback: authenticatedReadback(ctx), write: async key => {
      const value = valueOf(await call(ctx, {method: 'POST', path: `/v1/tasks/${taskId}/funding`, body, auth: true, idempotencyKey: key}));
      if (evidenceKind !== 'verified_deposit' && value.funded !== false) throw new AeError('signature_is_not_funding', 1);
      if (value.reserved !== false) throw new AeError('signature_is_not_funding', 1);
      return value;
    }}],
  });
  return run.result;
}

export async function taskClaim(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const taskId = flag(flags, 'task', {pattern: /^task_[A-Za-z0-9_-]{16}$/});
  const terms = valueOf(await call(ctx, {method: 'GET', path: '/v1/claims/terms', query: {taskId}, auth: true}));
  const bindingBody = {roundKey: taskId};
  const claimBody = {taskId, termsVersion: terms.termsVersion, acceptTerms: true};
  if (flags.destination) claimBody.payoutDestination = flag(flags, 'destination', {pattern: /^0x[a-f0-9]{40}$/});
  const body = {bindingBody, claimBody};
  const run = await operate(ctx, {
    operationId, name: 'task.claim', body, meta: body,
    steps: [
      {name: STEP.binding, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: '/v1/claims/binding', body: bindingBody, auth: true, idempotencyKey: key}))},
      {name: STEP.claim, readback: authenticatedReadback(ctx), write: async key => {
        const value = valueOf(await call(ctx, {method: 'POST', path: '/v1/claims/claims', body: claimBody, auth: true, idempotencyKey: key}));
        if (value.kind !== 'claimed' || value.claim?.canStart !== true) throw new AeError('claim_refused', 1);
        return value;
      }},
    ],
  });
  return run.result;
}

export async function taskSubmit(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const reservationId = flag(flags, 'reservation', {pattern: /^rsv_[A-Za-z0-9_-]{16}$/});
  const report = await privateRead(flag(flags, 'evidence-file'));
  if (report.signedNextConsumerReceipt) throw new AeError('next_consumer_receipt_not_issued', 1);
  continuityEvidence(report);
  const view = valueOf(await call(ctx, {method: 'GET', path: '/v1/review', query: {reservationId}, auth: true}));
  const evidence = {format: 'json', body: JSON.stringify(report), sourceReferences: []};
  const draftBody = {reservationId, termsVersion: view.source.termsVersion, expectedRevision: 0, evidence};
  const submitBody = {reservationId, expectedRevision: 1};
  const run = await operate(ctx, {
    operationId, name: 'task.submit', body: {draftBody, submitBody}, meta: {reservationId, evidenceHash: digest(report)},
    steps: [
      {name: STEP.draft, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: `/v1/submission/${reservationId}/draft`, body: draftBody, auth: true, idempotencyKey: key}))},
      {name: STEP.submit, readback: authenticatedReadback(ctx), write: async key => {
        const value = valueOf(await call(ctx, {method: 'POST', path: `/v1/submission/${reservationId}/submit`, body: submitBody, auth: true, idempotencyKey: key}));
        if (value.accepted !== false || value.httpStatusIsAcceptance !== false || value.nextConsumerReceipt !== null) throw new AeError('premature_acceptance', 1);
        return value;
      }},
    ],
  });
  return run.result;
}

export async function taskReview(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const reservationId = flag(flags, 'reservation', {pattern: /^rsv_[A-Za-z0-9_-]{16}$/});
  const decisionFile = await privateRead(flag(flags, 'review-file'));
  if (decisionFile?.schema !== 'pilot.funded-review.v1' || decisionFile.outcome !== 'pass' || decisionFile.decision !== 'accept' || !(decisionFile.reviewEvidenceRef?.length > 5)) {
    throw new AeError('explicit_current_source_review_required', 1);
  }
  const view = valueOf(await call(ctx, {method: 'GET', path: '/v1/review', query: {reservationId}, auth: true}));
  if (digest(decisionFile.source) !== digest(view.source)) throw new AeError('explicit_current_source_review_required', 1);
  const verdictBody = {source: view.source, outcome: 'pass'};
  const run = await operate(ctx, {
    operationId,
    name: 'task.review',
    body: {verdictBody, decision: decisionFile.decision, reviewEvidenceRef: decisionFile.reviewEvidenceRef},
    meta: {reservationId, reviewEvidenceRef: decisionFile.reviewEvidenceRef},
    steps: [
      {name: STEP.verdict, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: '/v1/review/verdict', body: verdictBody, auth: true, idempotencyKey: key}))},
      {name: STEP.decision, readback: authenticatedReadback(ctx), write: async key => {
        const verdict = (await openJournal(ctx.home, ctx.profile.origin)).journal.operations[operationId].steps[STEP.verdict].result;
        const decisionBody = {source: view.source, decision: 'accept', verdictId: verdict.view.verdict.id};
        const value = valueOf(await call(ctx, {method: 'POST', path: '/v1/review/decision', body: decisionBody, auth: true, idempotencyKey: key}));
        if (value.view?.state !== 'approval_pending' || value.view?.debtCreated !== false) throw new AeError('premature_acceptance', 1);
        return value;
      }},
    ],
  });
  return run.result;
}

export async function taskAuthority(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const reservationId = flag(flags, 'reservation', {pattern: /^rsv_[A-Za-z0-9_-]{16}$/});
  const winner = flag(flags, 'winner', {pattern: /^(authorized_capture|escrow_expiry|reclaim|refund|operator_capture)$/});
  const body = {reservationId, winner};
  const run = await operate(ctx, {
    operationId, name: 'task.authority', body, meta: body,
    steps: [{name: STEP.authority, readback: authenticatedReadback(ctx), write: async key => valueOf(await call(ctx, {method: 'POST', path: '/v1/review/authority', body, auth: true, idempotencyKey: key}))}],
  });
  if (run.result.contributorFundsPulled !== false) throw new AeError('contributor_funds_pulled', 1);
  return run.result;
}

export async function payoutStatus(ctx, flags) {
  await negotiate(ctx);
  const query = {};
  if (flags.cursor) query.cursor = flags.cursor;
  if (flags.limit) query.limit = flags.limit;
  const response = await call(ctx, {method: 'GET', path: '/v1/payouts', query, auth: true});
  return valueOf(response);
}

export async function operationRecover(ctx) {
  await negotiate(ctx);
  const opened = await openJournal(ctx.home, ctx.profile.origin);
  const pending = Object.entries(opened.journal.operations).filter(([, op]) => op.state !== 'confirmed' && op.state !== 'failed');
  const recovered = [];
  for (const [operationId, op] of pending) {
    try {
      const again = await resumeNamed(ctx, operationId, op);
      recovered.push({operationId, name: op.name, state: 'confirmed', replayed: again.replayed});
    } catch (error) {
      if (error?.code !== 'resume_inputs_missing') throw error;
      recovered.push({operationId, name: op.name, state: op.state, replayed: false, blocked: 'resume_inputs_missing'});
    }
  }
  return {recovered, transmittedAfterReadback: true};
}

async function resumeNamed(ctx, operationId, op) {
  const flags = {'operation': operationId};
  if (op.name === 'account.signup') {
    if (!ctx.secret?.password || !ctx.secret?.proof) throw new AeError('resume_inputs_missing', 1);
    const planned = signupSteps(ctx, {password: ctx.secret.password, proof: ctx.secret.proof, displayName: op.meta.displayName, role: op.meta.role});
    return operate(ctx, {operationId, name: op.name, body: planned.body, meta: op.meta, steps: planned.steps});
  }
  if (op.name === 'task.claim') return taskClaim(ctx, {...flags, task: op.meta.claimBody.taskId, ...(op.meta.claimBody.payoutDestination ? {destination: op.meta.claimBody.payoutDestination} : {})});
  if (op.name === 'task.post') return taskPost(ctx, {...flags, title: op.meta.title, 'public-text': op.meta.publicText, gross: op.meta.grossAtomic, 'rail-cost': op.meta.railCostAtomic, 'fee-recipient': op.meta.feeRecipient, captures: op.meta.captures.join(',')});
  if (op.name === 'task.fund') return taskFund(ctx, {...flags, task: op.meta.taskId, evidence: op.meta.evidenceKind, ...(op.meta.proofId ? {'proof-id': op.meta.proofId} : {})});
  if (op.name === 'task.authority') return taskAuthority(ctx, {...flags, reservation: op.meta.reservationId, winner: op.meta.winner});
  if (op.name === 'account.exit') return accountExit(ctx, flags);
  if (op.name === 'wallet.bind') return walletBind(ctx, flags);
  if (op.name === 'wallet.exit') return walletExit(ctx, flags);
  if (op.name === 'task.intent') {
    return taskIntent(ctx, {
      ...flags,
      task: op.meta.taskId,
      'settlement-token': op.meta.token,
      ...(op.meta.signerModule ? {'signer-module': op.meta.signerModule} : {}),
      ...(op.meta.out ? {out: op.meta.out} : {}),
    });
  }
  if (op.name === 'task.intent.sign') {
    return taskIntentSign(ctx, {
      ...flags,
      task: op.meta.taskId,
      'settlement-token': op.meta.token,
      'issue-operation': op.meta.issueOperation,
      'signer-module': op.meta.signerModule,
      ...(op.meta.out ? {out: op.meta.out} : {}),
    });
  }
  throw new AeError('resume_inputs_missing', 1);
}

const MARKET_ACTIONS = new Set(['post', 'list', 'interest', 'quote', 'select', 'assent', 'fund', 'claim', 'deliver', 'review', 'approve', 'reconcile', 'payoutDisposition', 'read', 'grantConsumer', 'retained', 'downstreamUse', 'serviceCost', 'repeatPurchase', 'measurement']);

function accountSignupUrl(base) {
  const prefix = base.pathname.endsWith('/') ? base.pathname : `${base.pathname}/`;
  return new URL('signup', `${base.origin}${prefix}`);
}

export async function accountServiceSignup(ctx, flags) {
  const base = assertLoopbackHttp(flag(flags, 'base-url'));
  const displayName = flag(flags, 'display-name');
  const operationId = flag(flags, 'operation', {pattern: /^[A-Za-z0-9_-]{8,120}$/});
  const password = await passwordFrom(flags);
  const proof = nonce();
  const response = await loopbackJson({
    url: accountSignupUrl(base),
    method: 'POST',
    headers: {'idempotency-key': operationId, 'x-account-operation-proof': proof},
    body: {password, displayName},
    timeoutMs: ctx.timeoutMs,
  });
  if (response.status !== 200 || !response.body?.account?.accountId || !response.body.sessionToken) {
    throw new AeError(response.body?.error?.code || 'signup_refused', response.status === 401 ? 3 : 1);
  }
  ctx.secret = {
    schema: 'ae.secret.v1',
    origin: ctx.profile.origin,
    bearer: response.body.sessionToken,
    recoveryCode: response.body.recoveryCode,
    accountId: response.body.account.accountId,
  };
  await writeSecret(ctx.home, ctx.secret);
  return {accountId: response.body.account.accountId, sessionDelivery: 'bearer', recoveryCodeStored: Boolean(response.body.recoveryCode)};
}

export async function marketCall(ctx, flags) {
  const action = flag(flags, 'action', {pattern: /^[A-Za-z]+$/});
  if (!MARKET_ACTIONS.has(action)) throw new AeError('usage', 1);
  const origin = assertLoopbackHttp(flag(flags, 'origin'));
  if (origin.origin !== ctx.profile.origin) throw new AeError('origin_credential_mismatch', 4);
  if (!ctx.secret?.bearer) throw new AeError('unauthenticated', 3);
  const bodyPath = flag(flags, 'body-file');
  if (!path.isAbsolute(bodyPath)) throw new AeError('usage', 1);
  const raw = await readFile(bodyPath, 'utf8');
  if (Buffer.byteLength(raw) > 131072) throw new AeError('usage', 1);
  let body;
  try { body = JSON.parse(raw); } catch { throw new AeError('invalid_json', 1); }
  const operationId = flag(flags, 'operation', {required: false, pattern: /^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/});
  // B's HTTP adapter forwards Idempotency-Key as the method's third argument.
  // assent's third argument is the select flag, so a key would select instead.
  const headerOperation = action === 'assent' ? undefined : operationId;
  const response = await loopbackJson({
    url: new URL(`/v1/market/${action}`, origin.origin),
    method: 'POST',
    headers: {authorization: `Bearer ${ctx.secret.bearer}`, ...(headerOperation ? {'idempotency-key': headerOperation} : {})},
    body,
    timeoutMs: ctx.timeoutMs,
  });
  if (response.status !== 200 || response.body?.ok !== true) {
    const code = response.body?.error?.code || 'market_refused';
    const exit = response.status === 401 ? 3 : response.status === 404 ? 5 : response.status === 409 ? 6 : 1;
    throw new AeError(code, exit);
  }
  return {action, httpStatus: response.status, result: response.body.result, usefulWork: false};
}

const MARKET_SURFACE = 'pilot.root71.hosted-wallet-market.v1';
const PUBLIC_MARKET_CHAINS = new Set(['eip155:8453', 'eip155:84532']);

function unpaidQuote(quote) {
  if (!quote || quote.funded !== false || quote.fundingState !== 'unfunded') throw new AeError('payment_refused', 1);
  if (!/^task_[A-Za-z0-9_-]{16}$/.test(quote.taskId || '')) throw new AeError('quote_refused', 1);
  return quote;
}

export async function networkBind(ctx, flags) {
  const bindingPath = flag(flags, 'binding');
  if (!path.isAbsolute(bindingPath)) throw new AeError('usage', 1);
  const health = await negotiate(ctx);
  if (health?.schema !== MARKET_SURFACE) throw new AeError('market_surface_refused', 1);
  if (health.paymentsActivation !== false || health.fundedTasks !== 'off' || health.humanAssets !== 'off') {
    throw new AeError('payments_refused', 1);
  }
  if (health.storageProfile !== 'verify-full-postgres') throw new AeError('binding_refused', 1);
  const chain = health.chain;
  if (chain === 'eip155:1' || typeof chain !== 'string' || !/^eip155:[1-9][0-9]*$/.test(chain)) throw new AeError('chain_refused', 1);
  const h1 = readBindingIdentity(bindingPath);
  const publicIdentity = health.publicChain === true || PUBLIC_MARKET_CHAINS.has(chain);
  if (publicIdentity) {
    if (ctx.profile.network?.chain !== chain || ctx.profile.network?.class !== 'public') throw new AeError('public_identity_refused', 1);
    const resolved = resolveNetworkIdentity(ctx.profile);
    if (resolved.chain !== chain || resolved.class !== 'public') throw new AeError('public_identity_refused', 1);
  } else if (ctx.profile.network && (ctx.profile.network.chain !== chain || ctx.profile.network.class !== 'sandbox')) {
    throw new AeError('network_mismatch', 1);
  }
  const profile = {
    ...ctx.profile,
    network: publicIdentity ? ctx.profile.network : {class: 'sandbox', chain},
    h1,
  };
  await writeProfile(ctx.home, profile);
  ctx.profile = profile;
  return {
    schema: 'ae.network-binding.v1',
    surface: MARKET_SURFACE,
    chain,
    class: profile.network.class,
    paymentsActivation: false,
    storageProfile: health.storageProfile,
    tenant: health.tenant,
    h1,
  };
}

const TASK_ID = /^task_[A-Za-z0-9_-]{16}$/;
const ADDRESS = /^0x[a-f0-9]{40}$/;

function stuck(code, exit = 1) {
  throw Object.assign(new AeError(code, exit), {status: 409});
}

export async function walletDeclare(ctx, flags) {
  const address = flag(flags, 'address', {pattern: ADDRESS});
  if (ctx.secret?.address && ctx.secret.address !== address) throw new AeError('wallet_exists', 6);
  if (ctx.secret?.address !== address) {
    ctx.secret = {
      ...(ctx.secret || {schema: 'ae.secret.v1', origin: ctx.profile.origin}),
      schema: 'ae.secret.v1',
      origin: ctx.profile.origin,
      address,
      custody: 'declared_address',
      fixture: false,
    };
    await writeSecret(ctx.home, ctx.secret);
  }
  return {fixture: false, custody: 'declared_address', address, storedLocally: false, sent: false};
}

export async function accountResume(ctx, flags) {
  await negotiate(ctx);
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  if (!ctx.secret?.proof || !ctx.secret?.accountId) throw new AeError('resume_inputs_missing', 1);
  const expectedAccount = ctx.secret.accountId;
  const proof = ctx.secret.proof;
  let response;
  try {
    response = await call(ctx, {
      method: 'POST',
      path: '/v1/account/readback',
      body: {operation: 'signup'},
      idempotencyKey: effectKey(operationId, STEP.signup),
      proof,
    });
  } catch (error) {
    if (error.code === 'recovery_expired' || error.code === 'not_found' || error.code === 'revoked') throw error;
    throw error;
  }
  const value = valueOf(response);
  if (value?.account?.accountId !== expectedAccount || value.account.role !== ctx.profile.role) {
    throw new AeError('account_refused', 1);
  }
  await captureSession(ctx, response, {
    password: ctx.secret.password,
    proof,
    role: ctx.profile.role,
    displayName: ctx.secret.displayName,
  });
  if (ctx.secret.accountId !== expectedAccount) throw new AeError('account_refused', 1);
  const session = await accountSession(ctx);
  if (session.accountId !== expectedAccount) throw new AeError('account_refused', 1);
  return {accountId: session.accountId, role: session.role, resumed: true, sameAccount: true, createdAccount: false};
}

async function boundIssue(ctx, value, {taskId, token}) {
  if (value?.authorized !== false || value?.taskId !== taskId || value?.payer !== ctx.secret.address) stuck('funding_intent_refused');
  const health = await negotiate(ctx);
  if (health?.schema !== MARKET_SURFACE || health.publicChain === true || PUBLIC_MARKET_CHAINS.has(health.chain)) {
    stuck('funding_refused');
  }
  if (health.chain !== ctx.profile.network?.chain) stuck('network_mismatch');
  const quote = valueOf(await call(ctx, {method: 'GET', path: `/v1/tasks/${taskId}/quote`, auth: true}));
  if (quote.funded !== false || quote.fundingState !== 'unfunded' || quote.taskId !== taskId) stuck('payment_refused');
  const expected = {
    tenant: health.tenant,
    chain: health.chain,
    account: ctx.secret.accountId,
    task: taskId,
    payer: ctx.secret.address,
    recipient: quote.feeRecipient,
    token,
    gross: quote.grossAtomic,
    notBeforeBlock: String(value.notBeforeBlock),
  };
  assertBoundIntent(value.message, expected);
  return {
    message: value.message,
    taskId,
    payer: value.payer,
    authorized: false,
    notBeforeBlock: String(value.notBeforeBlock),
    chain: health.chain,
    tenant: health.tenant,
    token,
    recipient: quote.feeRecipient,
    grossAtomic: quote.grossAtomic,
  };
}

function publicIntent(value, replayed) {
  return {
    schema: 'ae.funding-intent.v1',
    taskId: value.taskId,
    payer: value.payer,
    authorized: value.authorized === true,
    notBeforeBlock: String(value.notBeforeBlock),
    chain: value.chain,
    tenant: value.tenant,
    token: value.token,
    recipient: value.recipient,
    grossAtomic: value.grossAtomic,
    funded: false,
    payment: 'not_sent',
    signer: value.authorized === true ? 'eip191' : 'not_used',
    replayed,
  };
}

async function writeIntentReceipt(out, body) {
  if (!path.isAbsolute(out)) throw new AeError('usage', 1);
  try {
    const info = await lstat(out);
    if (info) throw new AeError('receipt_exists', 1);
  } catch (error) {
    if (error instanceof AeError) throw error;
    if (error?.code !== 'ENOENT') throw new AeError('receipt_refused', 1);
  }
  const digestHex = createHash('sha256').update(JSON.stringify(body)).digest('hex');
  await privateWrite(out, {...body, digest: digestHex});
  return digestHex;
}

function intentContext(ctx, flags) {
  const taskId = flag(flags, 'task', {pattern: TASK_ID});
  const token = flag(flags, 'settlement-token', {pattern: ADDRESS});
  const operationId = flag(flags, 'operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  if (!ctx.secret?.accountId) throw new AeError('unauthenticated', 3);
  if (!ADDRESS.test(ctx.secret.address || '')) throw new AeError('wallet_create_required', 1);
  if (ctx.profile.network?.class !== 'sandbox' || !ctx.profile.network?.chain) throw new AeError('funding_refused', 1);
  return {taskId, token, operationId};
}

async function journaledIssue(ctx, operationId) {
  const fresh = await openJournal(ctx.home, ctx.profile.origin);
  const issued = fresh.journal.operations[operationId]?.steps?.issue?.result;
  if (!issued?.message) throw new AeError('funding_intent_required', 1);
  return issued;
}

export async function taskIntent(ctx, flags) {
  const {taskId, token, operationId} = intentContext(ctx, flags);
  const signer = flags['signer-module'] ? await loadCallerSigner(flag(flags, 'signer-module')) : null;
  const body = {taskId, token, payer: ctx.secret.address, accountId: ctx.secret.accountId};
  const steps = [{
    name: STEP.issue,
    readback: async key => {
      const seen = await authenticatedReadback(ctx)(key);
      if (seen.state !== 'recorded') return seen;
      return {state: 'recorded', response: await boundIssue(ctx, seen.response, {taskId, token})};
    },
    write: async key => boundIssue(ctx, valueOf(await call(ctx, {
      method: 'POST',
      path: `/v1/tasks/${taskId}/funding-intent`,
      body: {},
      auth: true,
      idempotencyKey: key,
    })), {taskId, token}),
  }];
  if (signer) {
    steps.push({
      name: STEP.confirm,
      readback: async key => {
        const seen = await authenticatedReadback(ctx)(key);
        if (seen.state !== 'recorded') return seen;
        const issued = await journaledIssue(ctx, operationId);
        if (seen.response?.authorized !== true || seen.response.taskId !== taskId || seen.response.payer !== issued.payer) {
          throw new AeError('unknown_outcome_quarantined', 2);
        }
        if (String(seen.response.notBeforeBlock) !== issued.notBeforeBlock) throw new AeError('unknown_outcome_quarantined', 2);
        return {state: 'recorded', response: {...issued, authorized: true, notBeforeBlock: issued.notBeforeBlock}};
      },
      write: async key => {
        const issued = await journaledIssue(ctx, operationId);
        assertBoundIntent(issued.message, {
          tenant: issued.tenant,
          chain: issued.chain,
          account: ctx.secret.accountId,
          task: taskId,
          payer: issued.payer,
          recipient: issued.recipient,
          token,
          gross: issued.grossAtomic,
          notBeforeBlock: issued.notBeforeBlock,
        });
        const signature = await signExactIntent(signer, issued.message, issued.payer);
        let value;
        try {
          value = valueOf(await call(ctx, {
            method: 'POST',
            path: `/v1/tasks/${taskId}/funding-intent/signature`,
            body: {signature},
            auth: true,
            idempotencyKey: key,
          }));
        } catch (error) {
          if (error?.code === 'funding_intent_refused') throw error;
          throw error;
        }
        if (value.authorized !== true || value.taskId !== taskId || value.payer !== issued.payer || String(value.notBeforeBlock) !== issued.notBeforeBlock) {
          stuck('funding_intent_refused');
        }
        return {...issued, authorized: true, notBeforeBlock: String(value.notBeforeBlock)};
      },
    });
  }
  const run = await operate(ctx, {
    operationId,
    name: 'task.intent',
    body,
    meta: {taskId, token, payer: ctx.secret.address, accountId: ctx.secret.accountId, ...(signer ? {signerModule: flags['signer-module']} : {}), ...(flags.out ? {out: flags.out} : {})},
    steps,
  });
  const result = publicIntent(run.result, run.replayed);
  if (flags.out) result.digest = await writeIntentReceipt(flags.out, result);
  return result;
}

export async function taskIntentSign(ctx, flags) {
  const {taskId, token, operationId} = intentContext(ctx, flags);
  const signer = await loadCallerSigner(flag(flags, 'signer-module'));
  const issueOperation = flag(flags, 'issue-operation', {pattern: /^[a-z0-9][a-z0-9-]{7,63}$/});
  const opened = await openJournal(ctx.home, ctx.profile.origin);
  const issuedOp = opened.journal.operations[issueOperation];
  const issued = issuedOp?.steps?.issue?.result;
  if (!issuedOp || issuedOp.name !== 'task.intent' || issuedOp.steps?.issue?.state !== 'confirmed' || !issued?.message) {
    throw new AeError('funding_intent_required', 1);
  }
  if (issued.taskId !== taskId || issued.token !== token || issued.payer !== ctx.secret.address) stuck('funding_intent_refused');
  assertBoundIntent(issued.message, {
    tenant: issued.tenant,
    chain: issued.chain,
    account: ctx.secret.accountId,
    task: taskId,
    payer: issued.payer,
    recipient: issued.recipient,
    token,
    gross: issued.grossAtomic,
    notBeforeBlock: issued.notBeforeBlock,
  });
  const body = {taskId, token, payer: ctx.secret.address, accountId: ctx.secret.accountId, issueOperation, notBeforeBlock: issued.notBeforeBlock};
  const run = await operate(ctx, {
    operationId,
    name: 'task.intent.sign',
    body,
    meta: {taskId, token, payer: ctx.secret.address, accountId: ctx.secret.accountId, issueOperation, signerModule: flags['signer-module'], ...(flags.out ? {out: flags.out} : {})},
    steps: [{
      name: STEP.confirm,
      readback: async key => {
        const seen = await authenticatedReadback(ctx)(key);
        if (seen.state !== 'recorded') return seen;
        if (seen.response?.authorized !== true || seen.response.taskId !== taskId || String(seen.response.notBeforeBlock) !== issued.notBeforeBlock) {
          throw new AeError('unknown_outcome_quarantined', 2);
        }
        return {state: 'recorded', response: {...issued, authorized: true, notBeforeBlock: issued.notBeforeBlock}};
      },
      write: async key => {
        const signature = await signExactIntent(signer, issued.message, issued.payer);
        const value = valueOf(await call(ctx, {
          method: 'POST',
          path: `/v1/tasks/${taskId}/funding-intent/signature`,
          body: {signature},
          auth: true,
          idempotencyKey: key,
        }));
        if (value.authorized !== true || value.taskId !== taskId || value.payer !== issued.payer || String(value.notBeforeBlock) !== issued.notBeforeBlock) {
          stuck('funding_intent_refused');
        }
        return {...issued, authorized: true, notBeforeBlock: String(value.notBeforeBlock)};
      },
    }],
  });
  const result = publicIntent(run.result, run.replayed);
  if (flags.out) result.digest = await writeIntentReceipt(flags.out, result);
  return result;
}

export async function taskRetained(ctx, flags) {
  await negotiate(ctx);
  const taskId = flag(flags, 'task', {pattern: /^[A-Za-z0-9_.:-]{1,200}$/});
  const reservationId = flag(flags, 'reservation', {pattern: /^[A-Za-z0-9_.:-]{1,200}$/});
  if (taskId.includes('..') || reservationId.includes('..')) throw new AeError('usage', 1);
  const out = flag(flags, 'receipt-file');
  if (!path.isAbsolute(out)) throw new AeError('usage', 1);
  try {
    const info = await lstat(out);
    if (info) throw new AeError('receipt_exists', 1);
  } catch (error) {
    if (error instanceof AeError) throw error;
    if (error?.code !== 'ENOENT') throw new AeError('receipt_refused', 1);
  }
  const started = Date.now();
  const response = await call(ctx, {method: 'GET', path: '/v1/review', query: {taskId, reservationId}, auth: true});
  const summary = assessEntitled(valueOf(response), {taskId, reservationId});
  await privateWrite(out, response.body);
  const receiptBytes = (await readFile(out)).length;
  const receiptDigestSha256 = createHash('sha256').update(await readFile(out)).digest('hex');
  return {
    schema: 'ae.retained-outcome.v1',
    ...summary,
    receiptBytes,
    receiptDigestSha256,
    elapsedMs: Date.now() - started,
  };
}

export async function taskReceipt(ctx, flags) {
  const identity = resolveNetworkIdentity(ctx.profile);
  if (!ctx.profile.h1) throw new AeError('resolved_binding_required', 1);
  const out = flag(flags, 'out');
  if (!path.isAbsolute(out)) throw new AeError('usage', 1);
  try {
    const info = await lstat(out);
    if (info) throw new AeError('receipt_exists', 1);
  } catch (error) {
    if (error instanceof AeError) throw error;
    if (error?.code !== 'ENOENT') throw new AeError('receipt_refused', 1);
  }
  const quote = unpaidQuote(await taskQuote(ctx, flags));
  const body = {
    schema: 'ae.market-job-receipt.v1',
    operation: 'result',
    surface: MARKET_SURFACE,
    taskId: quote.taskId,
    funded: false,
    fundingState: quote.fundingState,
    payment: 'not_sent',
    signer: 'not_exercised',
    termsVersion: quote.termsVersion,
    chain: identity.chain,
    h1: ctx.profile.h1,
  };
  const digestHex = createHash('sha256').update(JSON.stringify(body)).digest('hex');
  await privateWrite(out, {...body, digest: digestHex});
  return {schema: body.schema, taskId: body.taskId, funded: false, payment: 'not_sent', signer: 'not_exercised', digest: digestHex, path: out};
}

async function jobReceive(ctx, operation, flags) {
  const configPath = flag(flags, 'config');
  if (operation === 'receipt') return receiveJob({operation, configPath, receiptId: flag(flags, 'receipt'), timeoutMs: ctx.timeoutMs, home: ctx.home});
  return receiveJob({operation, configPath, jobId: flag(flags, 'job'), timeoutMs: ctx.timeoutMs, home: ctx.home});
}

export async function dispatch(ctx, command, flags) {
  switch (command.id) {
    case 'profile.init': return profileInit(ctx, flags);
    case 'profile.show': return profileShow(ctx);
    case 'profile.switch-origin': return profileSwitchOrigin(ctx, flags);
    case 'discover': return discover(ctx, flags);
    case 'account.signup': return accountSignup(ctx, flags);
    case 'account.service-signup': return accountServiceSignup(ctx, flags);
    case 'account.session': return accountSession(ctx);
    case 'account.resume': return accountResume(ctx, flags);
    case 'account.exit': return accountExit(ctx, flags);
    case 'wallet.create': return walletCreate(ctx, flags);
    case 'wallet.declare': return walletDeclare(ctx, flags);
    case 'wallet.bind': return walletBind(ctx, flags);
    case 'wallet.export': return walletExport(ctx);
    case 'wallet.exit': return walletExit(ctx, flags);
    case 'task.post': return taskPost(ctx, flags);
    case 'task.quote': return taskQuote(ctx, flags);
    case 'task.intent': return taskIntent(ctx, flags);
    case 'task.intent.sign': return taskIntentSign(ctx, flags);
    case 'task.fund': return taskFund(ctx, flags);
    case 'task.claim': return taskClaim(ctx, flags);
    case 'task.submit': return taskSubmit(ctx, flags);
    case 'task.review': return taskReview(ctx, flags);
    case 'task.authority': return taskAuthority(ctx, flags);
    case 'payout.status': return payoutStatus(ctx, flags);
    case 'operation.recover': return operationRecover(ctx);
    case 'market.call': return marketCall(ctx, flags);
    case 'network.bind': return networkBind(ctx, flags);
    case 'task.receipt': return taskReceipt(ctx, flags);
    case 'task.retained': return taskRetained(ctx, flags);
    case 'job.submit': return submitJob({
      home: ctx.home,
      configPath: flag(flags, 'config'),
      url: flag(flags, 'url'),
      idempotencyKey: flag(flags, 'idempotency-key', {required: false, pattern: /^[A-Za-z0-9_.-]{8,128}$/}),
      timeoutMs: ctx.timeoutMs,
    });
    case 'job.poll': return jobReceive(ctx, 'poll', flags);
    case 'job.result': return jobReceive(ctx, 'result', flags);
    case 'job.receipt': return jobReceive(ctx, 'receipt', flags);
    default: throw new AeError('usage', 1);
  }
}

