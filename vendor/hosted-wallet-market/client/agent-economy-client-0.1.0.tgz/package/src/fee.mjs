import {AeError} from './errors.mjs';

// commerce-payments v1.1.0 at 6b0a5ef3f0df973857f558e2d6b5dd645b5e97f9
// docs/Fees.md: each capture validates the fee against that amount with integer
// division. F1's product profile is one full capture.
export const ROUNDING_PROFILE = 'commerce-payments-v1.1.0-single-capture';
export const FEE_BPS = 500;
export const FEE_BASIS = 'new_job_gross';

export function atomic(value) {
  if (typeof value !== 'string' || !/^(0|[1-9][0-9]{0,18})$/.test(value)) {
    throw new AeError('atomic_refused', 1);
  }
  return BigInt(value);
}

export function feePerCapture(amount) {
  return (atomic(amount) * BigInt(FEE_BPS) / 10000n).toString();
}

export function quoteEconomics({gross, railCost, captures}) {
  const grossA = atomic(gross);
  const railA = atomic(railCost);
  if (grossA <= 0n) throw new AeError('gross_refused', 1);
  const parts = captures?.length ? captures : [gross];
  if (parts.length !== 1) throw new AeError('unsupported_partial_capture', 1);
  let sum = 0n;
  let fee = 0n;
  const rows = parts.map(amount => {
    const part = atomic(amount);
    if (part <= 0n) throw new AeError('capture_refused', 1);
    sum += part;
    const partFee = atomic(feePerCapture(amount));
    fee += partFee;
    return {amountAtomic: part.toString(), feeAtomic: partFee.toString()};
  });
  if (sum !== grossA) throw new AeError('captures_must_sum_to_gross', 1);
  if (railA > grossA - fee) throw new AeError('rail_exceeds_net', 1);
  const net = grossA - fee - railA;
  const exactOnThisQuote = fee * 10000n === grossA * BigInt(FEE_BPS);
  return {
    roundingProfile: ROUNDING_PROFILE,
    feeBps: FEE_BPS,
    feeBasis: FEE_BASIS,
    grossAtomic: grossA.toString(),
    railCostAtomic: railA.toString(),
    captures: rows,
    platformFeeAtomic: fee.toString(),
    contributorNetAtomic: net.toString(),
    exactFivePercentAtEveryAtomicAmount: false,
    thisQuoteFeeIsExactFivePercent: exactOnThisQuote,
  };
}

export function cumulativeFloorFee(captures) {
  let gross = 0n;
  for (const amount of captures) gross += atomic(amount);
  return (gross * BigInt(FEE_BPS) / 10000n).toString();
}
