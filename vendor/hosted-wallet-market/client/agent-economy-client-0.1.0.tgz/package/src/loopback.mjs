import http from 'node:http';
import {AeError} from './errors.mjs';

const LOOPBACK = new Set(['127.0.0.1', 'localhost', '[::1]']);

export function assertLoopbackHttp(origin) {
  let url;
  try { url = new URL(origin); } catch { throw new AeError('origin_refused', 1); }
  if (url.protocol !== 'http:' || !LOOPBACK.has(url.hostname) || url.username || url.password || url.search || url.hash) {
    throw new AeError('loopback_required', 1);
  }
  return url;
}

export function loopbackJson({url, method = 'GET', headers = {}, body, timeoutMs = 15000}) {
  const target = url instanceof URL ? url : new URL(url);
  assertLoopbackHttp(target.origin);
  const payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
  return new Promise((resolve, reject) => {
    const req = http.request(target, {
      method,
      agent: false,
      headers: {
        connection: 'close',
        ...headers,
        ...(payload ? {'content-type': 'application/json', 'content-length': String(payload.length)} : {}),
      },
      timeout: timeoutMs,
    }, res => {
      const chunks = [];
      res.on('data', chunk => chunks.push(chunk));
      res.on('end', () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let parsed = {};
        if (text) {
          try { parsed = JSON.parse(text); } catch { reject(new AeError('invalid_json', 1)); return; }
        }
        resolve({status: res.statusCode, body: parsed});
      });
    });
    req.on('timeout', () => { req.destroy(); reject(new AeError('timeout', 2)); });
    req.on('error', () => reject(new AeError('https_transport_unknown', 2)));
    if (payload) req.end(payload);
    else req.end();
  });
}
