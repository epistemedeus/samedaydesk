import {randomBytes} from 'node:crypto';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {AeError} from './errors.mjs';
import {assertLoopbackHttp} from './loopback.mjs';

function adapterError(error) {
  if (error instanceof AeError) return error;
  const code = typeof error?.code === 'string' && /^[a-z0-9_]+$/.test(error.code) ? error.code : 'wallet_adapter_failed';
  return new AeError(code, 1);
}

async function load(modulePath) {
  if (!path.isAbsolute(modulePath) || !modulePath.endsWith(`${path.sep}dist${path.sep}wallet.js`)) {
    throw new AeError('wallet_adapter_required', 1);
  }
  const walletUrl = pathToFileURL(modulePath);
  const railRoot = path.dirname(path.dirname(modulePath));
  const [walletMod, storeMod, viem, foundation] = await Promise.all([
    import(walletUrl.href),
    import(new URL('./store.js', walletUrl).href),
    import(pathToFileURL(path.join(railRoot, 'node_modules', 'viem', '_esm', 'index.js')).href),
    import(new URL('../../agent-economy-foundation/dist/index.js', walletUrl).href),
  ]);
  if (typeof walletMod.LocalWalletCapabilities !== 'function' || typeof storeMod.RailStore !== 'function' || typeof foundation.AssetRegistry !== 'function' || typeof viem.defineChain !== 'function') {
    throw new AeError('wallet_adapter_required', 1);
  }
  return {LocalWalletCapabilities: walletMod.LocalWalletCapabilities, RailStore: storeMod.RailStore, viem, AssetRegistry: foundation.AssetRegistry};
}

function requireIdentity(identity) {
  if (!identity || (identity.class !== 'sandbox' && identity.class !== 'public')) throw new AeError('network_identity_required', 1);
  if (typeof identity.chain !== 'string' || !/^eip155:[1-9][0-9]*$/.test(identity.chain)) throw new AeError('network_identity_required', 1);
  if (!Number.isSafeInteger(identity.chainId) || `eip155:${identity.chainId}` !== identity.chain) throw new AeError('network_identity_required', 1);
  return identity;
}

// A's authority check reads client.chain.id and refuses when it is absent. The RPC chain id is still compared.
function clientFor(viem, chainUrl, chainId) {
  const url = assertLoopbackHttp(chainUrl);
  const chain = viem.defineChain({
    id: chainId,
    name: 'configured network',
    nativeCurrency: {name: 'Ether', symbol: 'ETH', decimals: 18},
    rpcUrls: {default: {http: [url.origin]}},
  });
  return viem.createPublicClient({chain, transport: viem.http(url.origin, {retryCount: 0}), cacheTime: 0});
}

// checkChainIdentity looks up {chain, token, decimals:6, symbol:'USDC'} and does not infer a registry.
function registryFor(AssetRegistry, token, chain) {
  return new AssetRegistry('sandbox', [{
    asset: {chain, token, decimals: 6, symbol: 'USDC'},
    environment: 'sandbox',
    canonical: {asset: 'USDC', network: chain},
  }]);
}

export async function createLocalWallet({modulePath, chainUrl, storePath, actor, walletId, identity}) {
  try {
    const configured = requireIdentity(identity);
    const {LocalWalletCapabilities, RailStore, viem, AssetRegistry} = await load(modulePath);
    const unlock = randomBytes(32);
    const store = new RailStore(storePath);
    const capabilities = new LocalWalletCapabilities(store, unlock, clientFor(viem, chainUrl, configured.chainId), undefined, undefined, undefined, registryFor(AssetRegistry, 'unbound', configured.chain));
    const wallet = await capabilities.create(actor, {
      schemaVersion: 'pilot.agent-economy.v3',
      walletId,
      chain: configured.chain,
      token: 'unbound',
      rootId: actor.actorId,
      recoveryId: actor.actorId,
      custody: 'local_keystore',
    });
    if (wallet.custody !== 'local_keystore' || wallet.chain !== configured.chain || !/^0x[a-fA-F0-9]{40}$/.test(wallet.address)) {
      throw new AeError('wallet_adapter_failed', 1);
    }
    return {address: wallet.address, walletId: wallet.walletId, chain: wallet.chain, custody: wallet.custody, unlockKey: unlock.toString('base64')};
  } catch (error) {
    throw adapterError(error);
  }
}

export async function bindLocalAsset({modulePath, chainUrl, storePath, actor, walletId, token, unlockKey, identity}) {
  try {
    const configured = requireIdentity(identity);
    const {LocalWalletCapabilities, RailStore, viem, AssetRegistry} = await load(modulePath);
    const unlock = Buffer.from(unlockKey, 'base64');
    if (unlock.length !== 32) throw new AeError('wallet_adapter_required', 1);
    const store = new RailStore(storePath);
    const capabilities = new LocalWalletCapabilities(store, unlock, clientFor(viem, chainUrl, configured.chainId), undefined, undefined, undefined, registryFor(AssetRegistry, token, configured.chain));
    await capabilities.bindAsset(actor, walletId, token);
    unlock.fill(0);
    return {token, chain: configured.chain};
  } catch (error) {
    throw adapterError(error);
  }
}
