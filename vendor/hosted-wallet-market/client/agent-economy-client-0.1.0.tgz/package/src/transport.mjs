import https from 'node:https';
import {need} from './c0/participant-wire.mjs';

// Same TLS rules as the C0 transport: verified HTTPS, same origin, no
// NODE_TLS_REJECT_UNAUTHORIZED=0. The only additions are timeoutMs and a
// distinct timeout error so a hung response can be resumed.
export async function transport(origin, route, {method = 'GET', body, headers = {}, ca, timeoutMs = 15000} = {}) {
  const url = new URL(route, origin);
  need(url.origin === origin && url.protocol === 'https:' && process.env.NODE_TLS_REJECT_UNAUTHORIZED !== '0', 'verified_same_origin_required');
  const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
  const startedAt = new Date().toISOString();
  return new Promise((resolve, reject) => {
    let settled = false;
    const fail = error => {
      if (settled) return;
      settled = true;
      reject(error);
    };
    const ok = value => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const q = https.request(url, {
      method,
      agent: false,
      rejectUnauthorized: true,
      ...(ca ? {ca} : {}),
      timeout: timeoutMs,
      headers: {
        connection: 'close',
        ...(data ? {'content-type': 'application/json', 'content-length': String(data.length)} : {}),
        ...headers,
      },
    }, res => {
      const verified = res.socket.authorized === true;
      let bytes = 0;
      const chunks = [];
      res.on('data', chunk => {
        bytes += chunk.length;
        if (bytes > 1024 * 1024) q.destroy();
        else chunks.push(chunk);
      });
      res.on('error', () => fail(new Error('response_interrupted')));
      res.on('aborted', () => fail(new Error('response_interrupted')));
      res.on('end', () => {
        let parsed;
        try { parsed = JSON.parse(Buffer.concat(chunks).toString()); } catch { parsed = undefined; }
        ok({status: res.statusCode, headers: res.headers, body: parsed, verified, startedAt, receivedAt: new Date().toISOString()});
      });
    });
    q.on('error', () => fail(new Error('https_transport_unknown')));
    q.on('timeout', () => {
      q.destroy();
      fail(new Error('timeout'));
    });
    q.end(data ?? undefined);
  });
}
