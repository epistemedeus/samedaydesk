import {createHash} from 'node:crypto';
import path from 'node:path';
import {AeError} from './errors.mjs';
import {privateRead, privateWrite} from './c0/participant-wire.mjs';
import {journalPath} from './profile.mjs';

export function effectKey(operationId, step) {
  return `ae-${operationId}#${step}`;
}

export async function openJournal(home, origin) {
  const file = journalPath(home, origin);
  try {
    const journal = await privateRead(file);
    if (journal.schema !== 'ae.operation-journal.v1' || journal.origin !== origin) throw new AeError('journal_origin_refused', 4);
    journal.operations ??= {};
    return {file, journal};
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    const journal = {schema: 'ae.operation-journal.v1', origin, operations: {}};
    await privateWrite(file, journal);
    return {file, journal};
  }
}

export async function runOperation({file, journal, operationId, name, bodyHash, meta, steps}) {
  if (!/^[a-z0-9][a-z0-9-]{7,63}$/.test(operationId || '')) throw new AeError('operation_required', 1);
  const save = () => privateWrite(file, journal);
  let op = journal.operations[operationId];
  if (!op) {
    op = {key: `ae-${operationId}`, name, bodyHash, meta, state: 'in_flight', steps: {}, startedAt: new Date().toISOString()};
    journal.operations[operationId] = op;
    await save();
  } else {
    if (op.bodyHash !== bodyHash || op.name !== name) throw new AeError('immutable_operation_input_changed', 6);
    if (op.state === 'confirmed') return {result: op.result, replayed: true};
    // A 4xx is a finished refusal. Resume must not retransmit it.
    if (op.state === 'failed') throw new AeError(op.failureCode || 'contract_refused', Number.isInteger(op.failureExit) ? op.failureExit : 1);
  }
  let last;
  for (const step of steps) {
    const slot = op.steps[step.name] ??= {state: 'pending'};
    if (slot.state === 'confirmed') { last = slot.result; continue; }
    const key = effectKey(operationId, step.name);
    let seen;
    try { seen = await step.readback(key); }
    catch (error) {
      slot.state = 'unknown';
      op.state = 'unknown';
      await save();
      throw error;
    }
    if (seen.state === 'recorded') {
      slot.state = 'confirmed';
      slot.result = seen.response;
      last = seen.response;
      await save();
      continue;
    }
    if (seen.state !== 'absent') {
      slot.state = 'unknown';
      op.state = 'unknown';
      await save();
      throw new AeError('unknown_outcome_quarantined', 2);
    }
    slot.state = 'in_flight';
    await save();
    try {
      last = await step.write(key);
      slot.state = 'confirmed';
      slot.result = last;
      await save();
    } catch (error) {
      const status = error?.status;
      if (Number.isInteger(status) && status >= 400 && status < 500) {
        slot.state = 'failed';
        op.state = 'failed';
        op.failureCode = error.code || 'contract_refused';
        op.failureExit = Number.isInteger(error.exit) ? error.exit : 1;
        op.failedAt = new Date().toISOString();
        await save();
        throw error;
      }
      slot.state = 'unknown';
      op.state = 'unknown';
      await save();
      throw error;
    }
  }
  op.state = 'confirmed';
  op.result = last;
  op.finishedAt = new Date().toISOString();
  await save();
  return {result: last, replayed: false};
}

function jobJournalPath(home, origin) {
  const digest = createHash('sha256').update(origin).digest('hex').slice(0, 16);
  return path.join(home, `job-journal-${digest}.json`);
}

/** url.extract submit journal. The pair is durable before any gateway POST. */
export async function openJobJournal(home, origin) {
  const file = jobJournalPath(home, origin);
  try {
    const journal = await privateRead(file);
    if (journal.schema !== 'ae.job-submit-journal.v1' || journal.origin !== origin) throw new AeError('journal_origin_refused', 4);
    journal.entries ??= {};
    return {file, journal};
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error;
    const journal = {schema: 'ae.job-submit-journal.v1', origin, entries: {}};
    await privateWrite(file, journal);
    return {file, journal};
  }
}

export async function saveJobSubmit(file, journal, id, entry) {
  const prior = journal.entries[id];
  if (prior && (prior.url !== entry.url || prior.bodyKey !== entry.bodyKey || prior.gatewayKey !== entry.gatewayKey)) {
    throw new AeError('immutable_operation_input_changed', 6);
  }
  journal.entries[id] = {...prior, ...entry};
  await privateWrite(file, journal);
  return journal.entries[id];
}
