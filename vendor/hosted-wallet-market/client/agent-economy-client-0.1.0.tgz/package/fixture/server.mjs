import https from 'node:https';
import {randomBytes, createHash} from 'node:crypto';
import {PREFIX} from '../src/c0/participant-wire.mjs';
import {digest} from '../src/canonical.mjs';
import {continuityEvidence} from '../src/c0/participant-wire.mjs';
import {quoteEconomics, ROUNDING_PROFILE} from '../src/fee.mjs';
import {WIRE_HEADER, WIRE_VERSION, SERVER_CLASS_HEADER} from '../src/catalog.mjs';
import {connectPg, execSql, quote} from './pg.mjs';
import {localCert} from './tls.mjs';

const SCHEMA = `
CREATE TABLE accounts (
  account_id text PRIMARY KEY,
  role text NOT NULL,
  display_name text NOT NULL,
  proof text NOT NULL UNIQUE,
  recovery_code text NOT NULL,
  revoked_epoch integer NOT NULL DEFAULT 0
);
CREATE TABLE sessions (
  cookie text PRIMARY KEY,
  account_id text NOT NULL REFERENCES accounts(account_id),
  csrf text NOT NULL,
  epoch integer NOT NULL
);
CREATE TABLE tasks (
  task_id text PRIMARY KEY,
  requester_id text NOT NULL REFERENCES accounts(account_id),
  title text NOT NULL,
  public_text text NOT NULL,
  gross_atomic text NOT NULL,
  rail_cost_atomic text NOT NULL,
  fee_recipient text NOT NULL,
  platform_fee_atomic text NOT NULL,
  contributor_net_atomic text NOT NULL,
  rounding_profile text NOT NULL,
  captures text NOT NULL,
  terms_version text NOT NULL,
  funding_state text NOT NULL,
  funded integer NOT NULL DEFAULT 0,
  funding_proof_id text UNIQUE,
  observations text NOT NULL DEFAULT '[]',
  authorization_expiry text NOT NULL,
  refund_expiry text NOT NULL,
  contributor_id text,
  payout_destination text
);
CREATE TABLE bindings (
  task_id text NOT NULL,
  account_id text NOT NULL,
  PRIMARY KEY (task_id, account_id)
);
CREATE TABLE claims (
  task_id text PRIMARY KEY,
  account_id text NOT NULL REFERENCES accounts(account_id),
  reservation_id text NOT NULL UNIQUE,
  idempotency_key text NOT NULL UNIQUE,
  payout_destination text NOT NULL
);
CREATE TABLE submissions (
  reservation_id text PRIMARY KEY,
  task_id text NOT NULL,
  account_id text NOT NULL,
  draft_revision integer NOT NULL DEFAULT 0,
  evidence_hash text,
  evidence_body text,
  business_status text,
  delivery_state text NOT NULL
);
CREATE TABLE reviews (
  reservation_id text PRIMARY KEY,
  task_id text NOT NULL,
  state text NOT NULL,
  verdict_id text,
  verdict_outcome text,
  source_hash text,
  winner text,
  obligation_id text,
  operator_incidents integer NOT NULL DEFAULT 0
);
CREATE TABLE obligations (
  obligation_id text PRIMARY KEY,
  account_id text NOT NULL,
  requester_id text,
  contributor_id text,
  reservation_id text,
  task_id text,
  amount_atomic text NOT NULL,
  destination text NOT NULL,
  terms_version text NOT NULL,
  wallet_required integer NOT NULL DEFAULT 0,
  useful_outcome text NOT NULL,
  fee_base_atomic text,
  confirmed_funding_atomic text,
  service_cost_atomic text,
  repeat_purchase_count integer NOT NULL DEFAULT 0,
  legacy integer NOT NULL DEFAULT 0
);
CREATE TABLE effects (
  idempotency_key text PRIMARY KEY,
  body_hash text NOT NULL,
  account_id text,
  proof text,
  apply_count integer NOT NULL,
  posts_received integer NOT NULL,
  response text NOT NULL
);
CREATE TABLE wallets (
  account_id text PRIMARY KEY REFERENCES accounts(account_id),
  address text NOT NULL,
  revocation_epoch integer NOT NULL DEFAULT 0,
  exported integer NOT NULL DEFAULT 0
);
`;

function httpError(status, code) {
  const error = new Error(code);
  error.http = status;
  error.codeName = code;
  return error;
}
function id(prefix) {
  return prefix + randomBytes(12).toString('base64url');
}
function addressOf(seed) {
  return '0x' + createHash('sha256').update(seed).digest('hex').slice(0, 40);
}
function keysOf(body, allowed) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw httpError(400, 'json_required');
  const keys = Object.keys(body);
  if (keys.some(key => !allowed.includes(key)) || allowed.some(key => body[key] === undefined && key !== 'proofId' && key !== 'payoutDestination')) {
    if (keys.includes('feeRecipient') && !allowed.includes('feeRecipient')) throw httpError(409, 'recipient_frozen');
    if (keys.includes('redirectTo')) throw httpError(409, 'recipient_frozen');
    throw httpError(400, 'body_refused');
  }
}
function must(value, code, status = 400) {
  if (!value) throw httpError(status, code);
}

async function withDb(database, fn) {
  const db = await connectPg(database);
  try { return await fn(db); }
  finally { db.close(); }
}
async function withTx(database, fn) {
  const db = await connectPg(database);
  try {
    await db.query('BEGIN');
    const result = await fn(db);
    await db.query('COMMIT');
    return result;
  } catch (error) {
    try { await db.query('ROLLBACK'); } catch { /* already aborted */ }
    throw error;
  } finally { db.close(); }
}

function mapConstraint(error) {
  if (error?.code !== '23505') return error;
  if (error.constraint === 'claims_pkey') return httpError(409, 'slot_taken');
  if (error.constraint === 'tasks_funding_proof_id_key') return httpError(409, 'funding_proof_reused');
  if (error.constraint === 'accounts_proof_key') return httpError(409, 'proof_reused');
  return error;
}

export async function createDisposableDatabase() {
  const name = 'ae14c' + randomBytes(6).toString('hex');
  await execSql('postgres', `CREATE DATABASE ${name}`);
  return name;
}
export async function dropDisposableDatabase(name) {
  if (!/^ae14c[a-f0-9]+$/.test(name)) throw new Error('drop_refused');
  await execSql('postgres', `DROP DATABASE IF EXISTS ${name} WITH (FORCE)`);
}

export async function startFixture(options = {}) {
  const database = options.database || await createDisposableDatabase();
  const ownedDatabase = !options.database;
  await execSql(database, SCHEMA);
  const tls = localCert();
  const wireVersion = options.wireVersion || WIRE_VERSION;
  const serverClass = options.serverClass || 'fixture';
  const mode = options.mode || 'fixture';
  const authoritativeLedger = options.authoritativeLedger === true;
  const faults = new Map();
  const access = [];
  const token = randomBytes(16).toString('hex');
  const originBox = {origin: ''};

  const send = (res, status, body, extra = {}) => {
    const payload = Buffer.from(JSON.stringify(body));
    res.writeHead(status, {
      'content-type': 'application/json',
      'content-length': String(payload.length),
      connection: 'close',
      'cache-control': 'no-store',
      [WIRE_HEADER]: wireVersion,
      [SERVER_CLASS_HEADER]: serverClass,
      ...extra,
    });
    res.end(payload);
  };

  const readJson = req => new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 1024 * 1024) reject(httpError(400, 'body_too_large'));
      else chunks.push(chunk);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { reject(httpError(400, 'json_required')); }
    });
    req.on('error', () => reject(httpError(400, 'body_interrupted')));
  });

  async function accountFrom(db, req, {write = false} = {}) {
    const cookie = req.headers.cookie?.split(';')[0]?.trim();
    if (!cookie) throw httpError(401, 'unauthenticated');
    const rows = await db.query(`SELECT s.csrf, s.epoch, a.account_id, a.role, a.revoked_epoch, a.display_name FROM sessions s JOIN accounts a ON a.account_id=s.account_id WHERE s.cookie=${quote(cookie)}`);
    const row = rows[0];
    if (!row) throw httpError(401, 'unauthenticated');
    if (Number(row.revoked_epoch) !== Number(row.epoch)) throw httpError(401, 'revoked');
    if (write) {
      if (req.headers.origin !== originBox.origin) throw httpError(401, 'origin_required');
      if (req.headers['x-cj-csrf'] !== row.csrf) throw httpError(401, 'csrf_required');
    }
    return {accountId: row.account_id, role: row.role, displayName: row.display_name, csrf: row.csrf, cookie};
  }

  async function mutate(db, req, body, account, apply) {
    const key = req.headers['idempotency-key'];
    if (typeof key !== 'string' || !/^[A-Za-z0-9][A-Za-z0-9_.:#-]{7,160}$/.test(key)) throw httpError(400, 'idempotency_required');
    const bodyHash = digest(body);
    const existing = await db.query(`SELECT body_hash, response, account_id FROM effects WHERE idempotency_key=${quote(key)} FOR UPDATE`);
    if (existing[0]) {
      await db.query(`UPDATE effects SET posts_received = posts_received + 1 WHERE idempotency_key=${quote(key)}`);
      if (existing[0].body_hash !== bodyHash) throw httpError(409, 'immutable_operation_input_changed');
      return JSON.parse(existing[0].response);
    }
    const response = await apply(db);
    await db.query(`INSERT INTO effects (idempotency_key, body_hash, account_id, proof, apply_count, posts_received, response) VALUES (${quote(key)}, ${quote(bodyHash)}, ${account ? quote(account.accountId) : 'NULL'}, ${req.headers['x-account-operation-proof'] ? quote(req.headers['x-account-operation-proof']) : 'NULL'}, 1, 1, ${quote(JSON.stringify(response))})`);
    return response;
  }

  function cookieHeaders(pair, csrf) {
    return {
      'set-cookie': `${pair}; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=86400`,
      'x-cj-csrf': csrf,
    };
  }

  function publicTask(row) {
    return {taskId: row.task_id, title: row.title, publicText: row.public_text, slotLimit: 1, fundingState: row.funding_state, termsVersion: row.terms_version};
  }
  function quoteValue(row) {
    return {
      quoteId: `quo_${row.task_id.slice(5)}`,
      taskId: row.task_id,
      grossAtomic: row.gross_atomic,
      railCostAtomic: row.rail_cost_atomic,
      feeRecipient: row.fee_recipient,
      platformFeeAtomic: row.platform_fee_atomic,
      contributorNetAtomic: row.contributor_net_atomic,
      roundingProfile: row.rounding_profile,
      captures: JSON.parse(row.captures),
      termsVersion: row.terms_version,
      feeBps: 500,
      feeBasis: 'new_job_gross',
      exactFivePercentAtEveryAtomicAmount: false,
      thisQuoteFeeIsExactFivePercent: BigInt(row.platform_fee_atomic) * 10000n === BigInt(row.gross_atomic) * 500n,
      fundingState: row.funding_state,
      funded: Number(row.funded) === 1,
      reserved: false,
      authorizationExpiry: row.authorization_expiry,
      refundExpiry: row.refund_expiry,
      expiriesEqual: row.authorization_expiry === row.refund_expiry,
      frozen: true,
      contributorId: row.contributor_id,
      payoutDestination: row.payout_destination,
    };
  }
  function obligationValue(row) {
    return {
      obligationId: row.obligation_id,
      accountId: row.account_id,
      reservationId: row.reservation_id,
      taskId: row.task_id,
      amountAtomic: row.amount_atomic,
      destination: row.destination,
      termsVersion: row.terms_version,
      walletRequired: Number(row.wallet_required) === 1,
      legacy: Number(row.legacy) === 1,
      measurements: {
        feeBaseAtomic: row.fee_base_atomic,
        confirmedFundingAtomic: row.confirmed_funding_atomic,
        serviceCostAtomic: row.service_cost_atomic,
        usefulOutcome: row.useful_outcome,
        repeatPurchaseCount: Number(row.repeat_purchase_count),
      },
    };
  }

  async function handler(req, res) {
    const url = new URL(req.url, 'https://127.0.0.1');
    access.push({method: req.method, path: url.pathname, hasCookie: Boolean(req.headers.cookie), hasAuthorization: Boolean(req.headers.authorization)});
    if (access.length > 500) access.shift();
    try {
      if (!url.pathname.startsWith(PREFIX)) return send(res, 404, {ok: false, code: 'not_found'});
      const path = url.pathname.slice(PREFIX.length);
      if (req.headers[WIRE_HEADER] && req.headers[WIRE_HEADER] !== wireVersion && path !== '/healthz') {
        return send(res, 409, {ok: false, code: 'wire_version_unsupported'});
      }
      if (path === '/healthz' && req.method === 'GET') {
        return send(res, 200, {ok: true, value: {
          ready: true, serverClass, mode, wireVersion, storageProfile: 'disposable_postgres',
          publicEnabled: true, authoritativeLedger, kernelDouble: true, production: false,
        }});
      }
      if (path.startsWith('/v1/fixture/')) return await fixture(req, res, path, url);
      const body = req.method === 'GET' ? {} : await readJson(req);
      if (path === '/v1/discover' && req.method === 'GET') return await discover(res, url);
      if (path === '/v1/account/signup' && req.method === 'POST') return await signup(req, res, body);
      if (path === '/v1/account/readback' && req.method === 'POST') return await signupReadback(req, res, body);
      if (path === '/v1/account/session' && req.method === 'GET') return await session(req, res);
      if (path === '/v1/account/exit' && req.method === 'POST') return await exitAccount(req, res, body);
      if (path === '/v1/wallet/bind' && req.method === 'POST') return await bindWallet(req, res, body);
      if (path === '/v1/wallet/export' && req.method === 'GET') return await exportWallet(req, res);
      if (path === '/v1/wallet/exit' && req.method === 'POST') return await exitWallet(req, res, body);
      if (path === '/v1/tasks' && req.method === 'POST') return await postTask(req, res, body);
      const quotePath = path.match(/^\/v1\/tasks\/(task_[A-Za-z0-9_-]{16})\/quote$/);
      if (quotePath && req.method === 'GET') return await readQuote(req, res, quotePath[1]);
      const fundPath = path.match(/^\/v1\/tasks\/(task_[A-Za-z0-9_-]{16})\/funding$/);
      if (fundPath && req.method === 'POST') return await fundTask(req, res, fundPath[1], body);
      if (path === '/v1/claims/terms' && req.method === 'GET') return await terms(req, res, url);
      if (path === '/v1/claims/binding' && req.method === 'POST') return await bindClaim(req, res, body);
      if (path === '/v1/claims/claims' && req.method === 'POST') return await claim(req, res, body);
      const draftPath = path.match(/^\/v1\/submission\/(rsv_[A-Za-z0-9_-]{16})\/draft$/);
      if (draftPath && req.method === 'POST') return await draft(req, res, draftPath[1], body);
      const submitPath = path.match(/^\/v1\/submission\/(rsv_[A-Za-z0-9_-]{16})\/submit$/);
      if (submitPath && req.method === 'POST') return await submitDelivery(req, res, submitPath[1], body);
      if (path === '/v1/review' && req.method === 'GET') return await reviewRead(req, res, url);
      if (path === '/v1/review/verdict' && req.method === 'POST') return await verdict(req, res, body);
      if (path === '/v1/review/decision' && req.method === 'POST') return await decision(req, res, body);
      if (path === '/v1/review/authority' && req.method === 'POST') return await authority(req, res, body);
      if (path === '/v1/payouts' && req.method === 'GET') return await payouts(req, res, url);
      if (path === '/v1/operations' && req.method === 'GET') return await readback(req, res, url);
      return send(res, 404, {ok: false, code: 'not_found'});
    } catch (error) {
      const mapped = mapConstraint(error);
      if (mapped.http) return send(res, mapped.http, {ok: false, code: mapped.codeName});
      if (!res.headersSent) send(res, 500, {ok: false, code: 'storage_failed'});
    }
  }

  function requireFixture(req) {
    if (req.headers['x-ae-fixture-token'] !== token) throw httpError(404, 'not_found');
  }
  async function fixture(req, res, path, url) {
    requireFixture(req);
    if (path === '/v1/fixture/faults' && req.method === 'POST') {
      const body = await readJson(req);
      if (!['hold', 'lose'].includes(body.mode) || typeof body.idempotencyKey !== 'string') throw httpError(400, 'body_refused');
      faults.set(body.idempotencyKey, body.mode);
      return send(res, 200, {ok: true, value: {armed: true}});
    }
    if (path === '/v1/fixture/effects' && req.method === 'GET') {
      const key = url.searchParams.get('idempotencyKey');
      const rows = await withDb(database, db => db.query(`SELECT apply_count, posts_received FROM effects WHERE idempotency_key=${quote(key || '')}`));
      const row = rows[0];
      return send(res, 200, {ok: true, value: row ? {applyCount: Number(row.apply_count), postsReceived: Number(row.posts_received)} : {applyCount: 0, postsReceived: 0}});
    }
    if (path === '/v1/fixture/access' && req.method === 'GET') return send(res, 200, {ok: true, value: {entries: access}});
    if (path === '/v1/fixture/legacy-obligation' && req.method === 'POST') return legacy(req, res);
    if (path === '/v1/fixture/reprice' && req.method === 'POST') return send(res, 409, {ok: false, code: 'legacy_obligation_immutable'});
    if (path === '/v1/fixture/claims' && req.method === 'GET') {
      const rows = await withDb(database, db => db.query('SELECT task_id, account_id, reservation_id FROM claims ORDER BY task_id'));
      return send(res, 200, {ok: true, value: {count: rows.length, claims: rows}});
    }
    if (path === '/v1/fixture/obligations' && req.method === 'GET') {
      const rows = await withDb(database, db => db.query('SELECT obligation_id, legacy, wallet_required, amount_atomic, destination, terms_version, useful_outcome FROM obligations ORDER BY obligation_id'));
      return send(res, 200, {ok: true, value: {count: rows.length, obligations: rows.map(row => ({...row, wallet_required: Number(row.wallet_required), legacy: Number(row.legacy)}))}});
    }
    return send(res, 404, {ok: false, code: 'not_found'});
  }

  async function finish(req, res, value, extra = {}) {
    const key = req.headers['idempotency-key'];
    const mode = key ? faults.get(key) : undefined;
    if (mode === 'lose') { res.destroy(); return; }
    if (mode === 'hold') {
      await new Promise(resolve => {
        req.on('close', resolve);
        res.on('close', resolve);
      });
      return;
    }
    send(res, 200, {ok: true, value}, extra);
  }

  function page(url) {
    const limit = Number(url.searchParams.get('limit') || '20');
    if (!Number.isInteger(limit) || limit < 1 || limit > 50) throw httpError(400, 'limit_refused');
    const raw = url.searchParams.get('cursor');
    let cursor = '';
    if (raw) {
      try { cursor = Buffer.from(raw, 'base64url').toString('utf8'); }
      catch { throw httpError(400, 'cursor_refused'); }
      if (!/^[A-Za-z0-9_-]+$/.test(cursor)) throw httpError(400, 'cursor_refused');
    }
    return {limit, cursor};
  }

  async function discover(res, url) {
    const {limit, cursor} = page(url);
    const rows = await withDb(database, db => db.query(`SELECT task_id, title, public_text, funding_state, terms_version FROM tasks WHERE task_id > ${quote(cursor)} ORDER BY task_id ASC LIMIT ${limit}`));
    const items = rows.map(publicTask);
    const nextCursor = rows.length === limit ? Buffer.from(rows.at(-1).task_id).toString('base64url') : null;
    send(res, 200, {ok: true, value: {items, nextCursor}});
  }

  async function signup(req, res, body) {
    keysOf(body, ['password', 'displayName', 'role']);
    must(typeof body.password === 'string' && body.password.length >= 16, 'password_refused');
    must(typeof body.displayName === 'string' && /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,40}$/.test(body.displayName), 'display_name_refused');
    must(['requester', 'contributor', 'authority'].includes(body.role), 'role_required');
    const proof = req.headers['x-account-operation-proof'];
    must(typeof proof === 'string' && /^[A-Za-z0-9_-]{43}$/.test(proof), 'proof_required');
    const accountId = id('acc_');
    const recoveryCode = randomBytes(24).toString('base64url');
    const csrf = randomBytes(32).toString('hex');
    const pair = `__Host-neo_contributor=acs_${randomBytes(32).toString('base64url')}`;
    const value = await withTx(database, db => mutate(db, req, body, null, async tx => {
      await tx.query(`INSERT INTO accounts (account_id, role, display_name, proof, recovery_code) VALUES (${quote(accountId)}, ${quote(body.role)}, ${quote(body.displayName)}, ${quote(proof)}, ${quote(recoveryCode)})`);
      await tx.query(`INSERT INTO sessions (cookie, account_id, csrf, epoch) VALUES (${quote(pair)}, ${quote(accountId)}, ${quote(csrf)}, 0)`);
      return {sessionDelivery: 'cookie', account: {accountId, role: body.role}, recoveryCode};
    }));
    await finish(req, res, value, cookieHeaders(pair, csrf));
  }

  async function signupReadback(req, res, body) {
    keysOf(body, ['operation']);
    must(body.operation === 'signup', 'operation_refused');
    const key = req.headers['idempotency-key'];
    const proof = req.headers['x-account-operation-proof'];
    const rows = await withDb(database, db => db.query(`SELECT e.response, e.proof, a.account_id, s.cookie, s.csrf FROM effects e JOIN accounts a ON a.proof=e.proof JOIN sessions s ON s.account_id=a.account_id WHERE e.idempotency_key=${quote(key || '')}`));
    const row = rows[0];
    if (!row || row.proof !== proof) throw httpError(404, 'not_found');
    const value = JSON.parse(row.response);
    send(res, 200, {ok: true, value}, cookieHeaders(row.cookie, row.csrf));
  }

  async function session(req, res) {
    const account = await withDb(database, db => accountFrom(db, req));
    const wallet = await withDb(database, db => db.query(`SELECT revocation_epoch FROM wallets WHERE account_id=${quote(account.accountId)}`));
    send(res, 200, {ok: true, value: {account: {accountId: account.accountId, role: account.role}, walletEpoch: wallet[0] ? Number(wallet[0].revocation_epoch) : null}}, {'x-cj-csrf': account.csrf});
  }

  async function exitAccount(req, res, body) {
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        await tx.query(`UPDATE accounts SET revoked_epoch = revoked_epoch + 1 WHERE account_id=${quote(account.accountId)}`);
        return {revoked: true, sessionContinues: false};
      });
    });
    await finish(req, res, value);
  }

  async function bindWallet(req, res, body) {
    keysOf(body, ['address']);
    must(/^(?:0x[a-f0-9]{40}|fixture:receive:[a-f0-9]{16})$/.test(body.address || ''), 'address_refused');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const prior = await tx.query(`SELECT address, revocation_epoch FROM wallets WHERE account_id=${quote(account.accountId)} FOR UPDATE`);
        if (prior[0] && prior[0].address !== body.address) throw httpError(409, 'wallet_already_bound');
        if (!prior[0]) await tx.query(`INSERT INTO wallets (account_id, address, revocation_epoch, exported) VALUES (${quote(account.accountId)}, ${quote(body.address)}, 0, 0)`);
        return {fixture: true, custody: 'fake_provider_root', address: body.address, revocationEpoch: prior[0] ? Number(prior[0].revocation_epoch) : 0, bound: true};
      });
    });
    await finish(req, res, value);
  }

  async function exportWallet(req, res) {
    const account = await withDb(database, db => accountFrom(db, req));
    const rows = await withDb(database, db => db.query(`UPDATE wallets SET exported=1 WHERE account_id=${quote(account.accountId)} RETURNING address, revocation_epoch`));
    // RETURNING may not be parsed as rows if command tag handling differs; re-read.
    const again = await withDb(database, db => db.query(`SELECT address, revocation_epoch, exported FROM wallets WHERE account_id=${quote(account.accountId)}`));
    if (!again[0]) throw httpError(404, 'wallet_required_for_export');
    await withDb(database, db => db.query(`UPDATE wallets SET exported=1 WHERE account_id=${quote(account.accountId)}`));
    send(res, 200, {ok: true, value: {fixture: true, custody: 'fake_provider_root', address: again[0].address, revocationEpoch: Number(again[0].revocation_epoch), exported: true, providerCopyRetained: true, secretIncluded: false}});
    void rows;
  }

  async function exitWallet(req, res, body) {
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const prior = await tx.query(`SELECT revocation_epoch FROM wallets WHERE account_id=${quote(account.accountId)} FOR UPDATE`);
        if (!prior[0]) throw httpError(404, 'wallet_required_for_export');
        const epoch = Number(prior[0].revocation_epoch) + 1;
        await tx.query(`UPDATE wallets SET revocation_epoch=${epoch} WHERE account_id=${quote(account.accountId)}`);
        return {revocationEpoch: epoch, sessionContinues: true, obligationsRewritten: false};
      });
    });
    await finish(req, res, value);
  }

  async function postTask(req, res, body) {
    keysOf(body, ['title', 'publicText', 'grossAtomic', 'railCostAtomic', 'feeRecipient', 'captures']);
    must(typeof body.title === 'string' && body.title.length > 0 && body.title.length <= 120, 'title_refused');
    must(typeof body.publicText === 'string' && body.publicText.length > 0 && body.publicText.length <= 500, 'public_text_refused');
    must(/^0x[a-f0-9]{40}$/.test(body.feeRecipient || ''), 'fee_recipient_refused');
    const captures = body.captures ?? [body.grossAtomic];
    must(Array.isArray(captures) && captures.every(part => typeof part === 'string'), 'capture_refused');
    let economics;
    try { economics = quoteEconomics({gross: body.grossAtomic, railCost: body.railCostAtomic, captures}); }
    catch (error) { throw httpError(400, error.code || 'quote_refused'); }
    const leaked = [economics.grossAtomic, economics.platformFeeAtomic, economics.contributorNetAtomic, body.feeRecipient]
      .filter(part => part && part !== '0');
    if (leaked.some(part => body.publicText.includes(part) || body.title.includes(part))) throw httpError(400, 'amount_in_public_text');
    const termsVersion = digest({...economics, feeRecipient: body.feeRecipient});
    const expiry = new Date(Date.now() + 7 * 86400000).toISOString();
    const taskId = id('task_');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      if (account.role !== 'requester') throw httpError(403, 'requester_required');
      return mutate(db, req, body, account, async tx => {
        await tx.query(`INSERT INTO tasks (task_id, requester_id, title, public_text, gross_atomic, rail_cost_atomic, fee_recipient, platform_fee_atomic, contributor_net_atomic, rounding_profile, captures, terms_version, funding_state, funded, observations, authorization_expiry, refund_expiry) VALUES (${[
          taskId, account.accountId, body.title, body.publicText, economics.grossAtomic, economics.railCostAtomic, body.feeRecipient, economics.platformFeeAtomic, economics.contributorNetAtomic, ROUNDING_PROFILE, JSON.stringify(economics.captures), termsVersion, 'unfunded',
        ].map(quote).join(', ')}, 0, '[]', ${quote(expiry)}, ${quote(expiry)})`);
        const rows = await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(taskId)}`);
        return quoteValue(rows[0]);
      });
    });
    await finish(req, res, value);
  }

  async function readQuote(req, res, taskId) {
    await withDb(database, db => accountFrom(db, req));
    const rows = await withDb(database, db => db.query(`SELECT * FROM tasks WHERE task_id=${quote(taskId)}`));
    if (!rows[0]) throw httpError(404, 'not_found');
    send(res, 200, {ok: true, value: quoteValue(rows[0])});
  }

  async function fundTask(req, res, taskId, body) {
    const allowed = body.proofId === undefined ? ['evidenceKind'] : ['evidenceKind', 'proofId'];
    keysOf(body, allowed);
    const kinds = {
      eip3009_authorization: ['signature_prepared', 0],
      balance_read: ['balance_observed', 0],
      submitted_tx: ['submitted', 0],
      verified_deposit: ['confirmed_usable', 1],
    };
    const mapped = kinds[body.evidenceKind];
    must(mapped, 'evidence_refused');
    if (body.evidenceKind !== 'verified_deposit' && body.proofId) throw httpError(400, 'proof_not_funding');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const rows = await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(taskId)} FOR UPDATE`);
        const task = rows[0];
        if (!task) throw httpError(404, 'not_found');
        if (task.requester_id !== account.accountId) throw httpError(403, 'requester_required');
        if (Number(task.funded) === 1 && mapped[1] !== 1) throw httpError(409, 'funding_already_confirmed');
        let proofId = task.funding_proof_id;
        if (mapped[1] === 1) {
          proofId = body.proofId || task.funding_proof_id || id('proof_');
          if (task.funding_proof_id && body.proofId && body.proofId !== task.funding_proof_id) throw httpError(409, 'funding_proof_reused');
        }
        const observations = JSON.parse(task.observations);
        observations.push({evidenceKind: body.evidenceKind, state: mapped[0], funded: mapped[1] === 1});
        await tx.query(`UPDATE tasks SET funding_state=${quote(mapped[0])}, funded=${mapped[1]}, funding_proof_id=${proofId ? quote(proofId) : 'NULL'}, observations=${quote(JSON.stringify(observations))} WHERE task_id=${quote(taskId)}`);
        return {taskId, evidenceKind: body.evidenceKind, fundingState: mapped[0], funded: mapped[1] === 1, reserved: false, proofId: mapped[1] === 1 ? proofId : null, observations};
      });
    });
    await finish(req, res, value);
  }

  async function terms(req, res, url) {
    const taskId = url.searchParams.get('taskId');
    await withDb(database, db => accountFrom(db, req));
    const rows = await withDb(database, db => db.query(`SELECT * FROM tasks WHERE task_id=${quote(taskId || '')}`));
    if (!rows[0]) throw httpError(404, 'not_found');
    const task = rows[0];
    send(res, 200, {ok: true, value: {termsVersion: task.terms_version, termsId: task.terms_version, task: {rewardAtomic: task.contributor_net_atomic, submissionDeadline: task.authorization_expiry}, quote: quoteValue(task)}});
  }

  async function bindClaim(req, res, body) {
    keysOf(body, ['roundKey']);
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      if (account.role !== 'contributor') throw httpError(403, 'contributor_required');
      return mutate(db, req, body, account, async tx => {
        const tasks = await tx.query(`SELECT requester_id, funded FROM tasks WHERE task_id=${quote(body.roundKey)}`);
        if (!tasks[0]) throw httpError(404, 'not_found');
        if (tasks[0].requester_id === account.accountId) throw httpError(403, 'self_claim_refused');
        await tx.query(`INSERT INTO bindings (task_id, account_id) VALUES (${quote(body.roundKey)}, ${quote(account.accountId)}) ON CONFLICT DO NOTHING`);
        return {roundKey: body.roundKey, bound: true};
      });
    });
    await finish(req, res, value);
  }

  async function claim(req, res, body) {
    keysOf(body, ['taskId', 'termsVersion', 'acceptTerms', 'payoutDestination']);
    must(body.acceptTerms === true, 'terms_not_accepted');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      if (account.role !== 'contributor') throw httpError(403, 'contributor_required');
      return mutate(db, req, body, account, async tx => {
        const tasks = await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(body.taskId)} FOR UPDATE`);
        const task = tasks[0];
        if (!task) throw httpError(404, 'not_found');
        if (task.terms_version !== body.termsVersion) throw httpError(409, 'terms_changed');
        if (Number(task.funded) !== 1) throw httpError(409, 'funding_not_usable');
        const bound = await tx.query(`SELECT 1 AS ok FROM bindings WHERE task_id=${quote(body.taskId)} AND account_id=${quote(account.accountId)}`);
        if (!bound[0]) throw httpError(409, 'binding_required');
        const destination = body.payoutDestination || addressOf(account.accountId);
        must(/^0x[a-f0-9]{40}$/.test(destination), 'destination_refused');
        const reservationId = id('rsv_');
        await tx.query(`INSERT INTO claims (task_id, account_id, reservation_id, idempotency_key, payout_destination) VALUES (${quote(body.taskId)}, ${quote(account.accountId)}, ${quote(reservationId)}, ${quote(req.headers['idempotency-key'])}, ${quote(destination)})`);
        await tx.query(`UPDATE tasks SET contributor_id=${quote(account.accountId)}, payout_destination=${quote(destination)} WHERE task_id=${quote(body.taskId)}`);
        return {kind: 'claimed', claim: {reservationId, taskId: body.taskId, canStart: true, payoutDestination: destination, walletRequired: false}};
      });
    });
    await finish(req, res, value);
  }

  function parseEvidence(evidence) {
    must(evidence?.format === 'json' && typeof evidence.body === 'string', 'evidence_refused');
    let report;
    try { report = JSON.parse(evidence.body); }
    catch { throw httpError(400, 'evidence_refused'); }
    if (report.signedNextConsumerReceipt) throw httpError(400, 'next_consumer_receipt_not_issued');
    try { continuityEvidence(report); }
    catch (error) { throw httpError(400, error.message || 'evidence_refused'); }
    return report;
  }

  async function draft(req, res, reservationId, body) {
    keysOf(body, ['reservationId', 'termsVersion', 'expectedRevision', 'evidence']);
    must(body.reservationId === reservationId && body.expectedRevision === 0, 'revision_refused');
    const report = parseEvidence(body.evidence);
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const claims = await tx.query(`SELECT c.task_id, t.terms_version FROM claims c JOIN tasks t ON t.task_id=c.task_id WHERE c.reservation_id=${quote(reservationId)} AND c.account_id=${quote(account.accountId)}`);
        if (!claims[0]) throw httpError(404, 'not_found');
        if (claims[0].terms_version !== body.termsVersion) throw httpError(409, 'terms_changed');
        const prior = await tx.query(`SELECT delivery_state FROM submissions WHERE reservation_id=${quote(reservationId)}`);
        if (prior[0] && prior[0].delivery_state === 'submitted') throw httpError(409, 'already_submitted');
        const evidenceHash = digest(report);
        if (!prior[0]) {
          await tx.query(`INSERT INTO submissions (reservation_id, task_id, account_id, draft_revision, evidence_hash, evidence_body, business_status, delivery_state) VALUES (${quote(reservationId)}, ${quote(claims[0].task_id)}, ${quote(account.accountId)}, 1, ${quote(evidenceHash)}, ${quote(JSON.stringify(report))}, ${quote(report.businessStatus)}, 'draft')`);
        }
        return {draft: {revision: 1, evidenceHash}, accepted: false, usefulOutcome: null, nextConsumerReceipt: null};
      });
    });
    await finish(req, res, value);
  }

  async function submitDelivery(req, res, reservationId, body) {
    keysOf(body, ['reservationId', 'expectedRevision']);
    must(body.reservationId === reservationId && body.expectedRevision === 1, 'revision_refused');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const rows = await tx.query(`SELECT * FROM submissions WHERE reservation_id=${quote(reservationId)} AND account_id=${quote(account.accountId)} FOR UPDATE`);
        if (!rows[0] || Number(rows[0].draft_revision) !== 1) throw httpError(409, 'draft_required');
        await tx.query(`UPDATE submissions SET delivery_state='submitted' WHERE reservation_id=${quote(reservationId)}`);
        return {deliveryState: 'submitted', authoritative: false, accepted: false, usefulOutcome: null, httpStatusIsAcceptance: false, nextConsumerReceipt: null, businessStatus: rows[0].business_status};
      });
    });
    await finish(req, res, value);
  }

  async function reviewSource(db, reservationId) {
    const rows = await db.query(`SELECT s.*, t.terms_version, t.requester_id FROM submissions s JOIN tasks t ON t.task_id=s.task_id WHERE s.reservation_id=${quote(reservationId)}`);
    return rows[0] || null;
  }
  function sourceOf(row) {
    return {taskId: row.task_id, reservationId: row.reservation_id, termsVersion: row.terms_version, evidenceHash: row.evidence_hash, businessStatus: row.business_status};
  }

  async function reviewRead(req, res, url) {
    const reservationId = url.searchParams.get('reservationId') || '';
    const account = await withDb(database, db => accountFrom(db, req));
    const row = await withDb(database, db => reviewSource(db, reservationId));
    if (!row) {
      const claim = await withDb(database, db => db.query(`SELECT c.account_id, c.task_id, c.reservation_id, t.terms_version, t.requester_id FROM claims c JOIN tasks t ON t.task_id=c.task_id WHERE c.reservation_id=${quote(reservationId)}`));
      const found = claim[0];
      if (!found || (account.role === 'contributor' && found.account_id !== account.accountId) || (account.role === 'requester' && found.requester_id !== account.accountId)) {
        throw httpError(404, 'not_found');
      }
      return send(res, 200, {ok: true, value: {viewer: account.role, state: 'claimed', source: {taskId: found.task_id, reservationId, termsVersion: found.terms_version, evidenceHash: null, businessStatus: null}, debtCreated: false, fulfillment: {paid: false}}});
    }
    if ((account.role === 'requester' && row.requester_id !== account.accountId) || (account.role === 'contributor' && row.account_id !== account.accountId) || account.role === 'authority') {
      if (account.role !== 'authority') throw httpError(404, 'not_found');
    }
    const review = await withDb(database, db => db.query(`SELECT state, obligation_id FROM reviews WHERE reservation_id=${quote(reservationId)}`));
    send(res, 200, {ok: true, value: {viewer: account.role, state: review[0]?.state || 'submitted', source: sourceOf(row), debtCreated: Boolean(review[0]?.obligation_id), fulfillment: {paid: false}}});
  }

  async function verdict(req, res, body) {
    keysOf(body, ['source', 'outcome']);
    must(body.outcome === 'pass', 'outcome_refused');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const row = await reviewSource(tx, body.source?.reservationId || '');
        if (!row || row.requester_id !== account.accountId || account.role !== 'requester') throw httpError(403, 'requester_required');
        if (digest(body.source) !== digest(sourceOf(row))) throw httpError(409, 'source_changed');
        const verdictId = id('ver_');
        const prior = await tx.query(`SELECT verdict_id, state FROM reviews WHERE reservation_id=${quote(row.reservation_id)} FOR UPDATE`);
        if (!prior[0]) {
          await tx.query(`INSERT INTO reviews (reservation_id, task_id, state, verdict_id, verdict_outcome, source_hash) VALUES (${quote(row.reservation_id)}, ${quote(row.task_id)}, 'verdict', ${quote(verdictId)}, 'pass', ${quote(digest(body.source))})`);
        }
        const current = await tx.query(`SELECT verdict_id, state, obligation_id FROM reviews WHERE reservation_id=${quote(row.reservation_id)}`);
        return {view: {verdict: {outcome: 'pass', id: current[0].verdict_id}, state: current[0].state, debtCreated: Boolean(current[0].obligation_id)}};
      });
    });
    await finish(req, res, value);
  }

  async function decision(req, res, body) {
    keysOf(body, ['source', 'decision', 'verdictId']);
    must(body.decision === 'accept', 'decision_refused');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      return mutate(db, req, body, account, async tx => {
        const row = await reviewSource(tx, body.source?.reservationId || '');
        if (!row || row.requester_id !== account.accountId) throw httpError(403, 'requester_required');
        const review = await tx.query(`SELECT * FROM reviews WHERE reservation_id=${quote(row.reservation_id)} FOR UPDATE`);
        if (!review[0] || review[0].verdict_id !== body.verdictId) throw httpError(409, 'verdict_required');
        if (review[0].state === 'verdict') {
          await tx.query(`UPDATE reviews SET state='approval_pending' WHERE reservation_id=${quote(row.reservation_id)}`);
        }
        const current = await tx.query(`SELECT state, obligation_id, verdict_id FROM reviews WHERE reservation_id=${quote(row.reservation_id)}`);
        if (current[0].state === 'accepted') throw httpError(409, 'premature_acceptance');
        return {view: {state: current[0].state, debtCreated: false, fulfillment: {paid: false}, handoff: {verdictId: current[0].verdict_id}}};
      });
    });
    await finish(req, res, value);
  }

  async function authority(req, res, body) {
    keysOf(body, ['reservationId', 'winner']);
    const winners = ['authorized_capture', 'escrow_expiry', 'reclaim', 'refund', 'operator_capture'];
    must(winners.includes(body.winner), 'winner_refused');
    const value = await withTx(database, async db => {
      const account = await accountFrom(db, req, {write: true});
      if (account.role !== 'authority') throw httpError(403, 'authority_required');
      return mutate(db, req, body, account, async tx => {
        const submission = await reviewSource(tx, body.reservationId);
        if (!submission || submission.delivery_state !== 'submitted') throw httpError(409, 'submission_required');
        let review = (await tx.query(`SELECT * FROM reviews WHERE reservation_id=${quote(body.reservationId)} FOR UPDATE`))[0];
        if (!review) {
          await tx.query(`INSERT INTO reviews (reservation_id, task_id, state) VALUES (${quote(body.reservationId)}, ${quote(submission.task_id)}, 'submitted')`);
          review = (await tx.query(`SELECT * FROM reviews WHERE reservation_id=${quote(body.reservationId)} FOR UPDATE`))[0];
        }
        if (review.winner) {
          if (review.winner !== body.winner) throw httpError(409, 'winner_already_recorded');
          const task = (await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(review.task_id)}`))[0];
          return authorityView(review, task, submission);
        }
        if (body.winner === 'operator_capture') {
          await tx.query(`UPDATE reviews SET operator_incidents = operator_incidents + 1 WHERE reservation_id=${quote(body.reservationId)}`);
          const current = (await tx.query(`SELECT * FROM reviews WHERE reservation_id=${quote(body.reservationId)}`))[0];
          const task = (await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(review.task_id)}`))[0];
          return {...authorityView(current, task, submission), incident: true, debtCreated: false, winner: null};
        }
        if (body.winner === 'authorized_capture') {
          if (review.state !== 'approval_pending') throw httpError(409, 'acceptance_required');
          const task = (await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(review.task_id)} FOR UPDATE`))[0];
          const claim = (await tx.query(`SELECT * FROM claims WHERE reservation_id=${quote(body.reservationId)}`))[0];
          const prior = await tx.query(`SELECT count(*) AS n FROM obligations WHERE requester_id=${quote(task.requester_id)} AND contributor_id=${quote(claim.account_id)} AND legacy=0`);
          const obligationId = id('obl_');
          const useful = ['failed', 'refused'].includes(submission.business_status) ? 'no_fit_payable' : 'accepted_payable';
          await tx.query(`INSERT INTO obligations (obligation_id, account_id, requester_id, contributor_id, reservation_id, task_id, amount_atomic, destination, terms_version, wallet_required, useful_outcome, fee_base_atomic, confirmed_funding_atomic, service_cost_atomic, repeat_purchase_count, legacy) VALUES (${[
            obligationId, claim.account_id, task.requester_id, claim.account_id, body.reservationId, task.task_id, task.contributor_net_atomic, claim.payout_destination, task.terms_version, '0', useful, task.gross_atomic, task.gross_atomic, task.rail_cost_atomic, String(Number(prior[0].n)), '0',
          ].map(quote).join(', ')})`);
          await tx.query(`UPDATE reviews SET winner='authorized_capture', state='accepted', obligation_id=${quote(obligationId)} WHERE reservation_id=${quote(body.reservationId)} AND winner IS NULL`);
          const current = (await tx.query(`SELECT * FROM reviews WHERE reservation_id=${quote(body.reservationId)}`))[0];
          if (current.winner !== 'authorized_capture' || current.obligation_id !== obligationId) throw httpError(409, 'winner_already_recorded');
          return authorityView(current, task, submission);
        }
        const task = (await tx.query(`SELECT * FROM tasks WHERE task_id=${quote(review.task_id)}`))[0];
        await tx.query(`UPDATE reviews SET winner=${quote(body.winner)}, state='closed_without_debt' WHERE reservation_id=${quote(body.reservationId)} AND winner IS NULL`);
        const current = (await tx.query(`SELECT * FROM reviews WHERE reservation_id=${quote(body.reservationId)}`))[0];
        if (current.winner !== body.winner) throw httpError(409, 'winner_already_recorded');
        return authorityView(current, task, submission);
      });
    });
    await finish(req, res, value);
  }

  function authorityView(review, task, submission) {
    const earlyRefund = review.winner === 'refund' && Date.parse(task.refund_expiry) > Date.now() && task.refund_expiry === task.authorization_expiry;
    return {
      reservationId: review.reservation_id,
      winner: review.winner,
      state: review.state,
      debtCreated: Boolean(review.obligation_id),
      obligationId: review.obligation_id,
      incident: review.winner === 'operator_capture' || (!review.winner && Number(review.operator_incidents) > 0),
      operatorIncidents: Number(review.operator_incidents),
      feeRecipient: task.fee_recipient,
      liquiditySource: review.winner === 'refund' ? 'operator' : null,
      contributorFundsPulled: false,
      refundBeforeSharedExpiry: earlyRefund,
      usefulOutcome: review.obligation_id ? (['failed', 'refused'].includes(submission.business_status) ? 'no_fit_payable' : 'accepted_payable') : null,
    };
  }

  async function payouts(req, res, url) {
    const {limit, cursor} = page(url);
    const account = await withDb(database, db => accountFrom(db, req));
    const rows = await withDb(database, db => db.query(`SELECT * FROM obligations WHERE account_id=${quote(account.accountId)} AND obligation_id > ${quote(cursor)} ORDER BY obligation_id ASC LIMIT ${limit}`));
    const wallet = await withDb(database, db => db.query(`SELECT account_id FROM wallets WHERE account_id=${quote(account.accountId)}`));
    const nextCursor = rows.length === limit ? Buffer.from(rows.at(-1).obligation_id).toString('base64url') : null;
    send(res, 200, {ok: true, value: {items: rows.map(obligationValue), nextCursor, walletEnrolled: Boolean(wallet[0])}});
  }

  async function readback(req, res, url) {
    const key = url.searchParams.get('idempotencyKey') || '';
    const account = await withDb(database, db => accountFrom(db, req));
    const rows = await withDb(database, db => db.query(`SELECT response, account_id FROM effects WHERE idempotency_key=${quote(key)}`));
    if (!rows[0]) return send(res, 200, {ok: true, value: {state: 'absent'}});
    if (rows[0].account_id && rows[0].account_id !== account.accountId) throw httpError(404, 'not_found');
    send(res, 200, {ok: true, value: {state: 'recorded', response: JSON.parse(rows[0].response)}});
  }

  async function legacy(req, res) {
    const account = await withDb(database, db => accountFrom(db, req));
    const existing = await withDb(database, db => db.query(`SELECT obligation_id FROM obligations WHERE account_id=${quote(account.accountId)} AND legacy=1`));
    if (!existing[0]) {
      const obligationId = id('obl_');
      await withDb(database, db => db.query(`INSERT INTO obligations (obligation_id, account_id, amount_atomic, destination, terms_version, wallet_required, useful_outcome, fee_base_atomic, confirmed_funding_atomic, service_cost_atomic, repeat_purchase_count, legacy) VALUES (${quote(obligationId)}, ${quote(account.accountId)}, '100000', '0x1111111111111111111111111111111111111111', 'legacy-terms-pre-wallet-v0', 0, 'accepted_payable', '100000', '100000', '0', 0, 1)`));
    }
    const rows = await withDb(database, db => db.query(`SELECT * FROM obligations WHERE account_id=${quote(account.accountId)} AND legacy=1`));
    send(res, 200, {ok: true, value: obligationValue(rows[0])});
  }

  const server = https.createServer({key: tls.key, cert: tls.cert}, handler);
  server.requestTimeout = 0;
  server.headersTimeout = 0;
  server.timeout = 0;
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  originBox.origin = `https://127.0.0.1:${server.address().port}`;
  return {
    origin: originBox.origin,
    ca: tls.cert,
    token,
    database,
    async close() {
      server.closeAllConnections?.();
      await new Promise(resolve => server.close(() => resolve()));
      if (ownedDatabase) await dropDisposableDatabase(database);
    },
  };
}
