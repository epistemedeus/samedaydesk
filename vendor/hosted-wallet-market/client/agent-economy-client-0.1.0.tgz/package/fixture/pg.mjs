import net from 'node:net';
import tls from 'node:tls';
import {lstatSync, readFileSync} from 'node:fs';

const IDENT = /^[A-Za-z_][A-Za-z0-9_]{0,62}$/;

function coded(code) {
  return Object.assign(new Error(code), {code});
}

function startup(user, database) {
  const chunks = [Buffer.alloc(4)];
  chunks[0].writeInt32BE(196608, 0);
  for (const [key, value] of [['user', user], ['database', database], ['client_encoding', 'UTF8']]) {
    chunks.push(Buffer.from(`${key}\0${value}\0`));
  }
  chunks.push(Buffer.from([0]));
  const payload = Buffer.concat(chunks);
  const frame = Buffer.alloc(4 + payload.length);
  frame.writeInt32BE(frame.length, 0);
  payload.copy(frame, 4);
  return frame;
}

function parseError(payload) {
  const fields = {};
  let offset = 0;
  while (offset < payload.length) {
    const code = String.fromCharCode(payload[offset]);
    if (code === '\u0000') break;
    const end = payload.indexOf(0, offset + 1);
    fields[code] = payload.toString('utf8', offset + 1, end);
    offset = end + 1;
  }
  return {severity: fields.S, code: fields.C, message: fields.M, constraint: fields.n, table: fields.t, detail: fields.D};
}

function parseRowDescription(payload) {
  const count = payload.readInt16BE(0);
  const names = [];
  let offset = 2;
  for (let i = 0; i < count; i += 1) {
    const end = payload.indexOf(0, offset);
    names.push(payload.toString('utf8', offset, end));
    offset = end + 1 + 18;
  }
  return names;
}

function parseDataRow(payload, names) {
  const count = payload.readInt16BE(0);
  const row = {};
  let offset = 2;
  for (let i = 0; i < count; i += 1) {
    const length = payload.readInt32BE(offset);
    offset += 4;
    row[names[i] || String(i)] = length < 0 ? null : payload.toString('utf8', offset, offset + length);
    if (length > 0) offset += length;
  }
  return row;
}

function bindingFile(explicit) {
  const file = explicit || process.env.AE14_RESOLVED_BINDING;
  if (typeof file !== 'string' || file.trim() === '') throw coded('resolved_binding_required');
  return file;
}

function loadBinding(explicit) {
  const file = bindingFile(explicit);
  let info;
  try {
    info = lstatSync(file);
  } catch {
    throw coded('resolved_binding_required');
  }
  if (!info.isFile() || (info.mode & 0o777) !== 0o600) throw coded('resolved_binding_mode');
  let body;
  try {
    body = JSON.parse(readFileSync(file, 'utf8'));
  } catch {
    throw coded('resolved_binding_refused');
  }
  const database = body?.database;
  if (!database || database.capability !== 'verify-full' || typeof database.url !== 'string') throw coded('resolved_binding_refused');
  let parsed;
  try {
    parsed = new URL(database.url);
  } catch {
    throw coded('resolved_binding_refused');
  }
  if (parsed.protocol !== 'postgresql:' && parsed.protocol !== 'postgres:') throw coded('resolved_binding_refused');
  if (parsed.password || parsed.searchParams.has('password')) throw coded('resolved_binding_refused');
  const host = parsed.hostname;
  if (host !== '127.0.0.1' && host !== 'localhost') throw coded('resolved_binding_refused');
  const port = Number(parsed.port);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw coded('resolved_binding_refused');
  if (parsed.searchParams.get('sslmode') !== 'verify-full') throw coded('resolved_binding_refused');
  const user = decodeURIComponent(parsed.username);
  if (!IDENT.test(user)) throw coded('resolved_binding_refused');
  const files = {};
  for (const key of ['sslrootcert', 'sslcert', 'sslkey']) {
    const certPath = parsed.searchParams.get(key);
    if (typeof certPath !== 'string' || !certPath.startsWith('/')) throw coded('resolved_binding_refused');
    let certInfo;
    try {
      certInfo = lstatSync(certPath);
    } catch {
      throw coded('resolved_binding_refused');
    }
    if (!certInfo.isFile()) throw coded('resolved_binding_refused');
    files[key] = readFileSync(certPath);
  }
  return {host, port, user, ca: files.sslrootcert, cert: files.sslcert, key: files.sslkey};
}

function readOneByte(socket) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => finish(coded('tls_refused')), 15000);
    const onError = () => finish(coded('tls_refused'));
    const onData = chunk => {
      socket.pause();
      finish(null, chunk);
    };
    function finish(error, chunk) {
      clearTimeout(timer);
      socket.off('error', onError);
      socket.off('data', onData);
      if (error) {
        reject(error);
        return;
      }
      if (chunk.length > 1) socket.unshift(chunk.subarray(1));
      resolve(chunk[0]);
    }
    socket.on('error', onError);
    socket.on('data', onData);
  });
}

export function quote(value) {
  if (typeof value !== 'string') throw new Error('quote_string_required');
  if (value.includes('\u0000')) throw new Error('nul_refused');
  return `'${value.replaceAll("'", "''")}'`;
}

export function connectPg(database, options = {}) {
  if (!IDENT.test(database)) return Promise.reject(coded('resolved_binding_refused'));
  let target;
  try {
    target = loadBinding(options.bindingFile);
  } catch (error) {
    return Promise.reject(error);
  }
  return new Promise((resolve, reject) => {
    const tcp = net.connect({host: target.host, port: target.port});
    let secure = null;
    let buf = Buffer.alloc(0);
    let ready = false;
    let current = null;
    const queue = [];
    let failed = false;

    const fail = error => {
      if (failed) return;
      failed = true;
      tcp.destroy();
      if (secure) secure.destroy();
      if (!ready) reject(error);
      else if (current) {
        const job = current;
        current = null;
        job.reject(error);
      }
    };

    const pump = () => {
      while (buf.length >= 5) {
        const tag = String.fromCharCode(buf[0]);
        const length = buf.readInt32BE(1);
        if (length < 4 || buf.length < 1 + length) return;
        const payload = buf.subarray(5, 1 + length);
        buf = buf.subarray(1 + length);
        onMessage(tag, payload);
      }
    };

    const finishJob = () => {
      const job = current;
      current = null;
      const error = job.messages.find(message => message.tag === 'E');
      if (error) {
        const pg = parseError(error.payload);
        job.reject(Object.assign(new Error(pg.message || 'pg_error'), pg));
      } else {
        let names = [];
        const rows = [];
        for (const message of job.messages) {
          if (message.tag === 'T') names = parseRowDescription(message.payload);
          if (message.tag === 'D') rows.push(parseDataRow(message.payload, names));
        }
        job.resolve(rows);
      }
      if (queue.length && !failed) send(queue.shift());
    };

    const onMessage = (tag, payload) => {
      if (!ready) {
        if (tag === 'E') {
          const pg = parseError(payload);
          fail(Object.assign(new Error(pg.message || 'pg_startup_failed'), pg));
        } else if (tag === 'Z') {
          ready = true;
          resolve(api);
        }
        return;
      }
      if (!current) return;
      current.messages.push({tag, payload});
      if (tag === 'Z') finishJob();
    };

    const send = job => {
      current = job;
      const sql = Buffer.from(job.text + '\0');
      const length = Buffer.alloc(4);
      length.writeInt32BE(sql.length + 4, 0);
      secure.write(Buffer.concat([Buffer.from('Q'), length, sql]));
    };

    const api = {
      query(text) {
        return new Promise((resolveQuery, rejectQuery) => {
          const job = {text, messages: [], resolve: resolveQuery, reject: rejectQuery};
          if (!current) send(job);
          else queue.push(job);
        });
      },
      close() {
        if (secure) secure.end();
        else tcp.end();
      },
    };

    const upgrade = async () => {
      try {
        const marker = readOneByte(tcp);
        const request = Buffer.alloc(8);
        request.writeInt32BE(8, 0);
        request.writeInt32BE(80877103, 4);
        tcp.write(request);
        const response = await marker;
        if (response !== 0x53) {
          fail(coded('tls_refused'));
          return;
        }
        tcp.removeAllListeners('timeout');
        tcp.setTimeout(0);
        const tlsOptions = {
          socket: tcp,
          host: target.host,
          ca: target.ca,
          cert: target.cert,
          key: target.key,
          rejectUnauthorized: true,
          minVersion: 'TLSv1.2',
        };
        if (net.isIP(target.host) === 0) tlsOptions.servername = target.host;
        secure = tls.connect(tlsOptions);
        secure.setTimeout(15000, () => fail(coded('tls_refused')));
        secure.once('error', () => fail(coded('tls_refused')));
        secure.on('data', chunk => {
          buf = Buffer.concat([buf, chunk]);
          pump();
        });
        secure.once('secureConnect', () => {
          if (failed) return;
          secure.write(startup(target.user, database));
        });
      } catch {
        fail(coded('tls_refused'));
      }
    };

    tcp.once('error', () => fail(coded('tls_refused')));
    tcp.setTimeout(15000, () => fail(coded('tls_refused')));
    tcp.once('connect', () => { upgrade(); });
  });
}

export async function execSql(database, text, options) {
  const db = await connectPg(database, options);
  try { return await db.query(text); }
  finally { db.close(); }
}
