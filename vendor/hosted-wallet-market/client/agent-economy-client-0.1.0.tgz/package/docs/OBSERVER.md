# What a public observer can learn

`GET /v1/discover` returns `taskId`, `title`, `publicText`, `slotLimit`, `fundingState`, and `termsVersion`. It does not return gross, fee, net, rail cost, fee recipient, account ids, or payout destinations. Posting rejects a title or public text that contains the quoted gross, the platform fee, the contributor net, or the fee recipient. Authenticated quote, terms, and payout reads still show amounts to the parties.

This package does not build, sign, or broadcast a settlement transaction. No chain RPC is called. The fixture never publishes a transaction.

If a later package submits a Commerce Payments capture on a public chain, an observer of that chain can learn what the transaction reveals. The fee document at `https://github.com/base/commerce-payments/blob/6b0a5ef3f0df973857f558e2d6b5dd645b5e97f9/docs/Fees.md` (fetched 2026-10-14) puts the absolute fee and the remaining merchant amount on capture. A public transaction can therefore show the token, the capture amount, the fee amount, the fee receiver, and the merchant receiver. The operator address is part of `PaymentInfo` in that protocol. Those fields are not copied into discover.

`OperatorRefundCollector` at `https://github.com/base/commerce-payments/blob/6b0a5ef3f0df973857f558e2d6b5dd645b5e97f9/src/collectors/OperatorRefundCollector.sol` (same commit, fetched 2026-10-14) pulls the refund with `safeTransferFrom` from `paymentInfo.operator`. That is operator liquidity. The authority result in this client keeps `contributorFundsPulled` false and `liquiditySource` of `operator` on a refund winner. Equal `refundExpiry` and `authorizationExpiry` still allow that earlier refund.

Wallet export on the fixture returns the public address, sets an exported flag, and leaves `revocationEpoch` unchanged. `providerCopyRetained` is true because a provider export is not deletion of the provider's copy. Principal exit is `account exit`, which bumps the session epoch. The next request with the old cookie is `revoked`. Old obligation rows are not rewritten.
