# Runtime floor

This package declares `engines.node` of `>=22.12.0` and has no `dependencies`.

The floor is copied from Commander 15, not from a dependency on it. Research pin `f593a13c87b1fa34efc1e3d2772d8bdd3d89be64` (`overview/self-evaluations/2026-10-14-agent-economy/research/R1-RESEARCH.md`) records Commander commit `ba6d13ddb4243e5913367734f8c159089ffe7834`, npm version 15.0.0, engines `node >= 22.12.0`, MIT, with no dependencies field. The integrated decision is to keep the received standard-Node client rather than adopt Commander or extend the older handoff client. The engines field stays at that floor so a later parser cannot silently accept an older Node.

The argv parser in `src/cli.mjs` is a few dozen lines. It rejects secret-named flags, duplicate flags, and unknown flags. It does not shell out.

Workspace Node used while building this package was v22.14.0, which satisfies the floor and therefore does not prove that an older Node fails the engines check.

TLS and file locking come from the vendored C0 wire (`src/c0/participant-wire.mjs`), byte-identical to `tools/ops/funded-continuation/participant-wire.mjs` at base `9a4be4834b21ff7dbd8a9ce894dfa2c40eda675c`. The brand transport adds a caller timeout and a distinct `timeout` error. It keeps verified HTTPS, `agent: false`, and `connection: close`.
