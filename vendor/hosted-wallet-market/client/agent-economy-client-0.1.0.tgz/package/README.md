# agent-economy-client

Brand command `ae` for the received C0 wire (`/api/neomorphic-contributor-journey`). One process speaks that contract. Direct HTTP is the same contract: `docs/HTTP.md` is generated from the route table the CLI uses. There is no second ledger in this package.

The disposable server under `fixture/` is a test double. It sets `authoritativeLedger` false and `kernelDouble` true. It is not the earned-work kernel, not a custodian, and not a chain.

## Runtime

Node `>=22.12.0`. No runtime dependencies. The floor is the Commander 15 engines field, recorded in `docs/RUNTIME.md`, so a later parser cannot lower it. This package does not depend on Commander.

## Install from the tarball

From this directory, `npm pack` writes `agent-economy-client-0.1.0.tgz`. In an empty directory, with only Node:

```sh
npm install --ignore-scripts ./agent-economy-client-0.1.0.tgz
```

The packed `ae` binary does not need this repository, Git, or a private source tree.

## Profiles and secrets

`AE_HOME` is an absolute directory mode `0700`, one per profile. `profile.json` binds `test` or `live`, a role (`requester`, `contributor`, or `authority`), and one `https` origin. `secret.json` is the secret store, mode `0600`. `profile switch-origin` deletes it. A secret whose origin does not match the profile is refused before a request is sent.

Pass a password only through `--secret-file` or `--secret-fd` (fd 3 or higher). The file schema is `ae.password-file.v1`: `{"schema":"ae.password-file.v1","password":"..."}`, mode `0600`, password length at least 16. Flags named `password`, `cookie`, `token`, `secret`, `recovery-code`, `private-key`, `seed`, `csrf`, or `session` are refused. The client does not read those values from the environment.

## Machine interface

Stdout is one JSON object. A failure writes one JSON object to stderr and no stdout. Exit `0` success, `1` usage or contract refusal, `2` timeout or unknown transport outcome, `3` unauthenticated or revoked, `4` profile or origin mismatch, `5` not found, `6` conflict, `7` funding not usable.

Network commands require `--ca-file`. The default timeout is 15 seconds (`--timeout-ms` 100 through 120000). HTTPS only, certificate verified, same origin. `NODE_TLS_REJECT_UNAUTHORIZED=0` is refused.

Operations take `--operation` (8 to 64 lowercase letters, digits, and hyphens). The journal is written and synced before the request. The same id reads the effect back before any retransmit. A response lost in transport stays `unknown` and is resumed. An HTTP 4xx is stored as `failed` and is not sent again. `operation recover` resumes journaled signup, post, fund, claim, authority, exit, and wallet operations. Submit and review need their files again; recover reports `resume_inputs_missing` instead of inventing a body.

## Funding, acceptance, fees

An EIP-3009 authorization, a balance read, and a submitted transaction are observations. None of them sets `funded` or `reserved`. Only `verified_deposit` is usable funding. Claim is refused with `funding_not_usable` until then.

Requester review stops at `approval_pending` and creates no debt. An authority profile then records one winner: `authorized_capture`, `escrow_expiry`, `reclaim`, `refund`, or `operator_capture`. Only a qualified capture creates one obligation. Operator capture is an incident, not acceptance. Refund liquidity is the operator's, and equal expiries do not block an earlier refund.

The fee profile is `commerce-payments-v1.1.0-single-capture`: 500 bps of new-job gross, one full capture, `floor(capture * 500 / 10000)`, rail cost separate. A split capture is refused. It is not 5% at every atomic amount. The fee recipient is frozen on the quote. Public discover omits amounts, the recipient, and account ids. See `docs/OBSERVER.md`.
