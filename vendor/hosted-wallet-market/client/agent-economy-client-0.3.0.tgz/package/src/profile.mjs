import path from 'node:path';
import {unlink} from 'node:fs/promises';
import {AeError} from './errors.mjs';
import {ownedDirectory, privateRead, privateWrite, lock, removeDeadLock} from './c0/participant-wire.mjs';
import {digest} from './canonical.mjs';

export function assertOrigin(origin) {
  let url;
  try { url = new URL(origin); } catch { throw new AeError('origin_refused', 1); }
  if (url.username || url.password || url.search || url.hash || url.origin !== origin) throw new AeError('origin_refused', 1);
  const loopback = url.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname);
  if (url.protocol !== 'https:' && !loopback) throw new AeError('origin_refused', 1);
  return url.origin;
}

export async function requireHome() {
  const home = process.env.AE_HOME;
  if (!home || !path.isAbsolute(home)) throw new AeError('ae_home_required', 1);
  await ownedDirectory(home);
  return home;
}

export async function withLock(home, fn) {
  try {
    await removeDeadLock(home, 'client');
  } catch (error) {
    if (error?.message === 'existing_writer_alive') throw new AeError('existing_writer_alive', 6);
    throw error;
  }
  let unlock;
  try {
    unlock = await lock(home, 'client');
  } catch (error) {
    if (error?.code === 'EEXIST') throw new AeError('existing_writer_alive', 6);
    throw error;
  }
  try { return await fn(); }
  finally { await unlock(); }
}

export async function readProfile(home) {
  let profile;
  try { profile = await privateRead(path.join(home, 'profile.json')); }
  catch (error) {
    if (error?.code === 'ENOENT') throw new AeError('profile_required', 1);
    throw error;
  }
  if (profile.schema !== 'ae.profile.v1' || !['test', 'live'].includes(profile.kind) || !['requester', 'contributor', 'authority'].includes(profile.role)) {
    throw new AeError('profile_refused', 1);
  }
  assertOrigin(profile.origin);
  assertStoredNetwork(profile);
  return profile;
}

function assertStoredNetwork(profile) {
  if (profile.network === undefined && profile.networkReceipt === undefined) return;
  if (profile.network !== undefined) {
    const network = profile.network;
    const chainId = typeof network?.chain === 'string' ? /^eip155:([1-9][0-9]*)$/.exec(network.chain) : null;
    const id = chainId ? Number(chainId[1]) : NaN;
    if (!chainId || !['sandbox','public','owned-fork'].includes(network.class) || !Number.isSafeInteger(id) || String(id) !== chainId[1]) {
      throw new AeError('profile_refused', 1);
    }
  }
  if (profile.networkReceipt !== undefined) {
    const receipt = profile.networkReceipt;
    const keys = receipt && typeof receipt === 'object' ? Object.keys(receipt) : [];
    if (keys.length !== 2 || !Object.hasOwn(receipt, 'path') || !Object.hasOwn(receipt, 'digest')) throw new AeError('profile_refused', 1);
    if (typeof receipt.path !== 'string' || !path.isAbsolute(receipt.path)) throw new AeError('profile_refused', 1);
    if (typeof receipt.digest !== 'string' || !/^[0-9a-f]{64}$/.test(receipt.digest)) throw new AeError('profile_refused', 1);
  }
  if (profile.h1 !== undefined) {
    const h1 = profile.h1;
    const keys = h1 && typeof h1 === 'object' && !Array.isArray(h1) ? Object.keys(h1).sort() : [];
    const expected = ['capability', 'port', 'schema', 'sslmode', 'systemIdentifier'];
    if (keys.length !== expected.length || keys.some((key, index) => key !== expected[index])) throw new AeError('profile_refused', 1);
    if (h1.capability !== 'verify-full' || h1.sslmode !== 'verify-full') throw new AeError('profile_refused', 1);
    if (!/^[a-z][a-z0-9_]{0,62}$/.test(h1.schema || '')) throw new AeError('profile_refused', 1);
    if (!Number.isInteger(h1.port) || h1.port < 1 || h1.port > 65535) throw new AeError('profile_refused', 1);
    if (!/^[0-9]{1,20}$/.test(h1.systemIdentifier || '')) throw new AeError('profile_refused', 1);
  }
}

export async function writeProfile(home, profile) {
  await privateWrite(path.join(home, 'profile.json'), profile);
}

export async function readSecret(home, profile) {
  let secret;
  try { secret = await privateRead(path.join(home, 'secret.json')); }
  catch (error) {
    if (error?.code === 'ENOENT') return null;
    throw error;
  }
  if (secret.schema !== 'ae.secret.v1' || secret.origin !== profile.origin) throw new AeError('origin_credential_mismatch', 4);
  // Old enrolled profiles may omit the redundant role. Keep those readable;
  // a role actually stored with a credential must agree with its profile.
  if (secret.role !== undefined && secret.role !== profile.role) throw new AeError('profile_server_mismatch', 4);
  return secret;
}

export async function writeSecret(home, secret) {
  await privateWrite(path.join(home, 'secret.json'), secret);
}

export function journalPath(home, origin) {
  return path.join(home, `journal-${digest(origin).slice(0, 16)}.json`);
}

export async function dropSecret(home) {
  await unlink(path.join(home, 'secret.json')).catch(error => {
    if (error.code !== 'ENOENT') throw error;
  });
}
