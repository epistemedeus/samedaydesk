import {PREFIX} from './c0/participant-wire.mjs';
import {ROUNDING_PROFILE} from './fee.mjs';

export {PREFIX};
export const WIRE_VERSION = 'c0-1';
export const WIRE_HEADER = 'x-ae-wire-version';
export const SERVER_CLASS_HEADER = 'x-ae-server-class';

// One route table. CLI commands and direct HTTP both use these suffixes
// under the C0 prefix. fixtureOnly rows are test hooks, not product actions.
export const ROUTES = Object.freeze([
  {id:'account.login',method:'POST',path:'/v1/account/login',auth:false,mutates:true,body:['accountId','password'],note:'Machine capability only. Uses the native account authority and original operation proof; issues a cookie session.'},
  {id:'account.recover',method:'POST',path:'/v1/account/recover',auth:false,mutates:true,body:['accountId','recoveryCode','newPassword'],note:'Machine capability only. Revokes old sessions and rotates account recovery; wallet keys and earned destinations stay separate.'},
  {id:'machine.profile',method:'GET',path:'/v1/market/profile',auth:false,mutates:false,note:'Public source/capability fields for cold profile initialization. No operator or signing authority.'},
  {id:'machine.discover',method:'GET',path:'/v1/market/discover',auth:false,mutates:false,note:'Source-qualified machine listing, including unfunded work. No private quotes, payout amounts, submissions or correspondence.'},
  {id:'market.call',method:'POST',path:'/v1/market/{action}',auth:true,mutates:true,note:'Existing requester-market action wire. Exact inputs are in MACHINE-MARKET.md. Read/reconcile actions never create a transfer.'},
  {id:'market.prove-wallet',method:'POST',path:'/v1/market/walletProve',auth:true,mutates:true,note:'First walletChallenge, then a personal signature of its exact origin/account/epoch-bound message. No seed or keystore is sent.'},
  {id:'market.fund',method:'POST',path:'/v1/market/fundingAuthorize',auth:true,mutates:true,note:'First fundingIntent. The principal signs the exact EIP-3009 terms; the version-qualified server rail journals the original authorization. A signature alone is not funding.'},
  {id:'market.reclaim',method:'POST',path:'/v1/market/fundingIntent',auth:true,mutates:false,note:'Reads the original selected payment. The principal journals and broadcasts a payer reclaim over the verified scoped RPC after expiry. It is not a refund.'},
  {id: 'health', method: 'GET', path: '/healthz', auth: false, mutates: false, c0: true,
    note: 'Fixture advertises serverClass fixture and mode fixture. It does not claim C0 mode live.'},
  {id: 'discover', method: 'GET', path: '/v1/discover', auth: false, mutates: false, c0: false,
    query: ['cursor', 'limit'],
    note: 'Public listing. Amounts, fee recipient, and account ids are omitted. Contract request public_listing.amounts. C0 showcase stays off.'},
  {id: 'account.signup', method: 'POST', path: '/v1/account/signup', auth: false, mutates: true, c0: true,
    body: ['password', 'displayName', 'role'],
    note: 'C0 body is password and displayName. role is the marketplace extension (account.role_on_signup). Session is the __Host cookie, never a JSON sessionToken.'},
  {id: 'account.readback', method: 'POST', path: '/v1/account/readback', auth: false, mutates: false, c0: true,
    body: ['operation'],
    note: 'C0 lost-signup readback. Requires the original idempotency key and x-account-operation-proof. Returns the same cookie session.'},
  {id: 'account.session', method: 'GET', path: '/v1/account/session', auth: true, mutates: false, c0: true,
    note: 'Returns account id and role. CSRF is the x-cj-csrf response header and is stored, not printed.'},
  {id: 'account.exit', method: 'POST', path: '/v1/account/exit', auth: true, mutates: true, c0: false,
    note: 'Principal exit. Later requests with the old cookie fail revoked. Distinct from wallet export.'},
  {id: 'wallet.bind', method: 'POST', path: '/v1/wallet/bind', auth: true, mutates: true, c0: false,
    body: ['address'],
    note: 'Address only. The local secret never leaves the secret store.'},
  {id: 'wallet.export', method: 'GET', path: '/v1/wallet/export', auth: true, mutates: false, c0: false,
    note: 'Public descriptor. revocationEpoch is unchanged. providerCopyRetained is true on this fixture.'},
  {id: 'wallet.exit', method: 'POST', path: '/v1/wallet/exit', auth: true, mutates: true, c0: false,
    note: 'Bumps the wallet epoch only. Session and old obligations stay.'},
  {id: 'task.post', method: 'POST', path: '/v1/tasks', auth: true, mutates: true, c0: false,
    body: ['title', 'publicText', 'grossAtomic', 'railCostAtomic', 'feeRecipient', 'captures'],
    note: `Creates one frozen quote. Rounding profile ${ROUNDING_PROFILE}. No contributor yet.`},
  {id: 'task.quote', method: 'GET', path: '/v1/tasks/{taskId}/quote', auth: true, mutates: false, c0: false,
    note: 'Authenticated quote read, including amounts. Not the public discover document.'},
  {id: 'task.fund', method: 'POST', path: '/v1/tasks/{taskId}/funding', auth: true, mutates: true, c0: false,
    body: ['evidenceKind', 'proofId'],
    note: 'evidenceKind is eip3009_authorization, balance_read, submitted_tx, or verified_deposit. Only verified_deposit sets funded.'},
  {id: 'task.intent', method: 'POST', path: '/v1/tasks/{taskId}/funding-intent', auth: true, mutates: true, c0: false,
    note: 'Body is {}. Issues the server funding intent bound to tenant, chain, account, task, payer, recipient, token, gross, and notBeforeBlock. Reissue before authorization replaces that message. This does not transfer value.'},
  {id: 'task.intent.sign', method: 'POST', path: '/v1/tasks/{taskId}/funding-intent/signature', auth: true, mutates: true, c0: false,
    body: ['signature'],
    note: 'Submits the EIP-191 personal_sign of the exact issued message. The signature is produced by the caller-owned signer. A contract wallet is contract_wallet_unsupported. ERC-1271 is not accepted. This does not transfer value.'},
  {id: 'task.terms', method: 'GET', path: '/v1/claims/terms', auth: true, mutates: false, c0: true,
    query: ['taskId'],
    note: 'C0 terms read. Amounts are visible to the authenticated claimer.'},
  {id: 'task.binding', method: 'POST', path: '/v1/claims/binding', auth: true, mutates: true, c0: true,
    body: ['roundKey'],
    note: 'C0 binding. roundKey is the task id on this fixture.'},
  {id: 'task.claim', method: 'POST', path: '/v1/claims/claims', auth: true, mutates: true, c0: true,
    body: ['taskId', 'termsVersion', 'acceptTerms', 'payoutDestination'],
    note: 'One slot. Concurrent inserts meet a primary key. Requires confirmed usable funding. Optional payoutDestination is stored once and is not a wallet enrollment.'},
  {id: 'task.draft', method: 'POST', path: '/v1/submission/{reservationId}/draft', auth: true, mutates: true, c0: true,
    body: ['reservationId', 'termsVersion', 'expectedRevision', 'evidence'],
    note: 'C0 draft. Evidence is a continuity report. HTTP success is not acceptance.'},
  {id: 'task.submit', method: 'POST', path: '/v1/submission/{reservationId}/submit', auth: true, mutates: true, c0: true,
    body: ['reservationId', 'expectedRevision'],
    note: 'C0 submit. deliveryState submitted is not a useful outcome and not a debt.'},
  {id: 'task.review.read', method: 'GET', path: '/v1/review', auth: true, mutates: false, c0: true,
    query: ['taskId', 'reservationId'],
    note: 'Reservation-only query returns the review source object and fulfillment.paid false. When taskId and reservationId are both present, the same GET returns that source plus the entitled join: authenticated role, exact artifact bytes, terms, verdict, and canonical disposition. fulfillment.paid is true only for a native_paid disposition with kernelPaid, nativePaidObservation, no transfer, and archival payout_state owed. Accepted-unpaid stays projection owed. This read does not pay or transfer.'},
  {id: 'task.verdict', method: 'POST', path: '/v1/review/verdict', auth: true, mutates: true, c0: true,
    body: ['source', 'outcome'],
    note: 'Records the verdict. Does not create debt.'},
  {id: 'task.decision', method: 'POST', path: '/v1/review/decision', auth: true, mutates: true, c0: true,
    body: ['source', 'decision', 'verdictId'],
    note: 'C0 path. Amended result is approval_pending and debtCreated false. accepted at this step is premature_acceptance.'},
  {id: 'task.authority', method: 'POST', path: '/v1/review/authority', auth: true, mutates: true, c0: false,
    body: ['reservationId', 'winner'],
    note: 'Application authority journal. Caller role must be authority, not the requester. Winners: authorized_capture, escrow_expiry, reclaim, refund, operator_capture. One winner row. Operator capture is an incident and is not acceptance.'},
  {id: 'payout.status', method: 'GET', path: '/v1/payouts', auth: true, mutates: false, c0: false,
    query: ['cursor', 'limit'],
    note: 'Accepted obligations, including legacy debt with no wallet. Separate measurement fields.'},
  {id: 'operation.readback', method: 'GET', path: '/v1/operations', auth: true, mutates: false, c0: false,
    query: ['idempotencyKey'],
    note: 'Generic lost-response readback for authenticated effects. Signup keeps the C0 POST readback.'},
  {id: 'fixture.fault', method: 'POST', path: '/v1/fixture/faults', auth: false, mutates: true, fixtureOnly: true,
    note: 'Test hook. Requires the fixture token. Not a product command and not called by the CLI.'},
  {id: 'fixture.effect', method: 'GET', path: '/v1/fixture/effects', auth: false, mutates: false, fixtureOnly: true,
    query: ['idempotencyKey'],
    note: 'Test hook. applyCount and postsReceived. No response bodies.'},
  {id: 'fixture.legacy', method: 'POST', path: '/v1/fixture/legacy-obligation', auth: true, mutates: true, fixtureOnly: true,
    note: 'Test hook. Seeds one pre-wallet accepted obligation for the session account.'},
  {id: 'fixture.access', method: 'GET', path: '/v1/fixture/access', auth: false, mutates: false, fixtureOnly: true,
    note: 'Test hook. Method, path, and whether a cookie header was present. Cookie values are not logged.'},
  {id: 'fixture.reprice', method: 'POST', path: '/v1/fixture/reprice', auth: false, mutates: false, fixtureOnly: true,
    note: 'Test hook. Refuses to reprice a legacy obligation. Returns legacy_obligation_immutable.'},
  {id: 'fixture.claims', method: 'GET', path: '/v1/fixture/claims', auth: false, mutates: false, fixtureOnly: true,
    note: 'Test hook. Claim rows for concurrency assertions. Not a second slot kernel.'},
  {id: 'fixture.obligations', method: 'GET', path: '/v1/fixture/obligations', auth: false, mutates: false, fixtureOnly: true,
    note: 'Test hook. Obligation rows standing in for the kernel owed record. authoritativeLedger is false.'},
]);

export const COMMANDS = Object.freeze([
  {id:'account.login',route:'account.login',argv:['account','login'],help:'Resume the same machine principal using the existing account authority and a private password handle.'},
  {id:'account.recover',route:'account.recover',argv:['account','recover'],help:'Recover the same machine account with its private recovery handle. This does not recover or change a wallet.'},
  {id:'wallet.local-create',argv:['wallet','local-create'],local:true,transport:'vault',help:'Create a principal-held encrypted Ethereum JSON keystore using a private password handle. No account or network.'},
  {id:'wallet.recover',argv:['wallet','recover'],local:true,transport:'vault',help:'Independently recover an encrypted keystore and verify its address. No account or network.'},
  {id:'wallet.encrypted-export',argv:['wallet','encrypted-export'],local:true,transport:'vault',help:'Copy encrypted wallet recovery material to a new private file.'},
  {id:'market.prove-wallet',route:'market.prove-wallet',argv:['market','prove-wallet'],help:'Sign an origin/account-bound wallet-control challenge with a principal wallet.'},
  {id:'market.fund',route:'market.fund',argv:['market','fund'],help:'Sign the exact selected terms; the version-qualified rail authorizes and observes original funding.'},
  {id:'market.reclaim',route:'market.reclaim',argv:['market','reclaim'],help:'Reclaim unearned expired escrow with the payer wallet. Persist the original transaction before broadcast.'},
  {id: 'version', argv: ['version'], local: true, help: 'Read the installed package version as JSON without a profile or network.'},
  {id: 'help', argv: ['help'], local: true, help: 'List commands and the wire version as JSON.'},
  {id: 'profile.init', argv: ['profile', 'init'], local: true, help: 'Create a test or live profile bound to one origin.'},
  {id: 'profile.show', argv: ['profile', 'show'], local: true, help: 'Print the profile without secrets.'},
  {id: 'profile.switch-origin', argv: ['profile', 'switch-origin'], local: true, help: 'Bind a new origin and drop credentials.'},
  {id: 'discover', argv: ['discover'], route: 'discover', help: 'List public tasks without pay amounts.'},
  {id: 'account.signup', argv: ['account', 'signup'], route: 'account.signup', help: 'Create an account. Password comes from a secret file or fd.'},
  {id: 'account.session', argv: ['account', 'session'], route: 'account.session', help: 'Read the current account.'},
  {id: 'account.exit', argv: ['account', 'exit'], route: 'account.exit', help: 'Revoke the principal session.'},
  {id: 'account.resume', argv: ['account', 'resume'], route: 'account.readback', help: 'Read back the original signup and return to that same account. This does not create a second account.'},
  {id: 'wallet.create', argv: ['wallet', 'create'], local: true, help: 'Fixture profiles return a labeled fake address. A live profile uses the sandbox local-keystore adapter or refuses.'},
  {id: 'wallet.declare', argv: ['wallet', 'declare'], local: true, help: 'Store a declared 0x address for wallet bind. No private key is read or stored.'},
  {id: 'wallet.bind', argv: ['wallet', 'bind'], route: 'wallet.bind', help: 'Bind the local address. A sandbox keystore uses --asset with the wallet module. The secret stays local.'},
  {id: 'wallet.export', argv: ['wallet', 'export'], route: 'wallet.export', help: 'Export the public wallet descriptor. This does not revoke.'},
  {id: 'wallet.exit', argv: ['wallet', 'exit'], route: 'wallet.exit', help: 'Revoke the wallet capability. The session and old debt remain.'},
  {id: 'task.post', argv: ['task', 'post'], route: 'task.post', help: 'Post a task and freeze one quote.'},
  {id: 'task.quote', argv: ['task', 'quote'], route: 'task.quote', help: 'Read the frozen quote.'},
  {id: 'task.intent', argv: ['task', 'intent'], route: 'task.intent', help: 'Issue the server funding intent. With --signer-module, sign that exact EIP-191 message and submit it. A contract wallet is refused. This does not transfer value.'},
  {id: 'task.intent.sign', argv: ['task', 'intent', 'sign'], route: 'task.intent.sign', help: 'Sign one journaled funding intent and submit that signature. This does not issue a new intent and does not transfer value.'},
  {id: 'task.fund', argv: ['task', 'fund'], route: 'task.fund', help: 'Record a funding observation. A signature is not funding.'},
  {id: 'task.claim', argv: ['task', 'claim'], route: 'task.claim', help: 'Bind and claim one funded slot.'},
  {id: 'task.submit', argv: ['task', 'submit'], route: 'task.submit', help: 'Draft and submit evidence. Completion is not acceptance.'},
  {id: 'task.review', argv: ['task', 'review'], route: 'task.decision', help: 'Record an explicit review. The state stays approval_pending.'},
  {id: 'task.authority', argv: ['task', 'authority'], route: 'task.authority', help: 'Record the capture, expiry, reclaim, refund, or operator-capture winner.'},
  {id: 'payout.status', argv: ['payout', 'status'], route: 'payout.status', help: 'List payable obligations. A wallet is not required.'},
  {id: 'operation.recover', argv: ['operation', 'recover'], local: true, help: 'Read back unknown operations and retransmit only when the effect is absent.'},
  {id: 'account.service-signup', argv: ['account', 'service-signup'], local: false, help: 'Sign up on the loopback Neo account service. The bearer and recovery code stay in the secret store.'},
  {id: 'market.call', route:'market.call', argv: ['market', 'call'], local: false, help: 'Use the existing market actions over certificate-verified account HTTP or the original loopback bearer route. HTTP 200 is not useful work.'},
  {id: 'network.bind', argv: ['network', 'bind'], local: false, help: 'Discover the hosted-wallet market chain from health and record the H1 binding identity. The database URL stays in the binding file.'},
  {id: 'task.receipt', argv: ['task', 'receipt'], local: false, help: 'Fetch the unpaid quote and write a receipt file. Funding, signature, and capture stay unused.'},
  {id: 'task.retained', argv: ['task', 'retained'], route: 'task.review.read', help: 'Read an already accepted artifact and its original disposition. The exact response is written to a mode 0600 receipt. This does not buy, pay, or submit again. Paid is not task success.'},
  {id: 'job.submit', argv: ['job', 'submit'], local: false, transport: 'gateway', help: 'Submit one https URL on url.extract. The body key and gateway key are journaled before the POST. This does not fund.'},
  {id: 'job.poll', argv: ['job', 'poll'], local: false, transport: 'gateway', help: 'Poll one job on the configured free machine-gateway route. This does not fund or submit.'},
  {id: 'job.result', argv: ['job', 'result'], local: false, transport: 'gateway', help: 'Read one job result and its exact artifact bytes on the configured free machine-gateway route.'},
  {id: 'job.receipt', argv: ['job', 'receipt'], local: false, transport: 'gateway', help: 'Read one machine-gateway receipt by id from the configured endpoint.'},
]);

export function routeById(id) {
  const route = ROUTES.find(row => row.id === id);
  if (!route) throw new Error('route_missing');
  return route;
}

export function renderHttpMarkdown() {
  const product = ROUTES.filter(row => !row.fixtureOnly);
  const hooks = ROUTES.filter(row => row.fixtureOnly);
  const lines = [];
  lines.push('# Direct HTTP equivalents');
  lines.push('');
  lines.push(`Every product command speaks \`${WIRE_VERSION}\` under \`${PREFIX}\`.`);
  lines.push('Send header `' + WIRE_HEADER + ': ' + WIRE_VERSION + '`.');
  lines.push('Mutations also send `idempotency-key`, and authenticated writes send the session cookie, `origin`, and `x-cj-csrf`.');
  lines.push('Cookie and password belong in a file or an HTTP module secret, not in the process argv.');
  lines.push('A Make HTTP module can call these URLs without the CLI. The CLI does not add a second ledger.');
  lines.push('');
  lines.push('Success body: `{"ok":true,"value":...}`. Failure body: `{"ok":false,"code":"..."}`.');
  lines.push('');
  lines.push('## Product routes');
  lines.push('');
  for (const row of product) {
    lines.push(`### ${row.method} ${PREFIX}${row.path}`);
    lines.push('');
    lines.push(`- Id: \`${row.id}\``);
    lines.push(`- Auth cookie: ${row.auth ? 'yes' : 'no'}`);
    lines.push(`- Mutates: ${row.mutates ? 'yes' : 'no'}`);
    lines.push(`- C0 path: ${row.c0 ? 'yes' : 'no, contract request'}`);
    if (row.query) lines.push(`- Query: ${row.query.map(q => '`' + q + '`').join(', ')}`);
    if (row.body) lines.push(`- JSON keys: ${row.body.map(q => '`' + q + '`').join(', ')}`);
    lines.push(`- ${row.note}`);
    lines.push('');
  }
  lines.push('## Fixture hooks');
  lines.push('');
  lines.push('These exist only on the disposable test server. The CLI never calls them. `authoritativeLedger` is false.');
  lines.push('');
  for (const row of hooks) {
    lines.push(`- \`${row.method} ${PREFIX}${row.path}\` — ${row.note}`);
  }
  lines.push('');
  lines.push('## Command map');
  lines.push('');
  for (const command of COMMANDS) {
    const http = command.route
      ? `${routeById(command.route).method} ${PREFIX}${routeById(command.route).path}`
      : command.transport === 'gateway' ? 'configured machine-gateway' : 'local';
    lines.push(`- \`ae ${command.argv.join(' ')}\` → ${http}. ${command.help}`);
  }
  lines.push('');
  return lines.join('\n');
}
