# Machine requester market

Version 0.3.0 extends the existing `ae` client and C0 cookie/CSRF transport.
The older archives remain immutable. Help and version need no profile, secrets
or network. The machine profile is independent of the original private profile.

Cold callers can use `profile init --name <name> --kind live --role requester
--origin <https-origin> --market on --ca-file <ca>` to fetch the public profile
over verified HTTPS. Contributors use `--role contributor`. This needs no owner
invitation, account, operator module or private capability file.

Root prepares a source and host bound capability after receiving an installation.
`profile init --capability-file <private-json>` records that exact capability with
the ordinary origin, role, and network. It does not supply a signer. The public
Commerce Payments v1.1.0 deployment is qualified separately from the historical
v1.0.0 address. `money: unfunded` works without any operator and cannot fund or
capture. `money: qualified` binds the received versioned network identity and
requires a separately supplied scoped operator, fresh code/proxy attestation,
gas budget and principal signatures. The capability file supplies no signer.
Public execution requires HTTPS; an explicitly identified owned fork uses a
loopback route and its separate journal. The old chain31337 sandbox remains
available for disposable compatibility receiving. Local-chain execution is
technical evidence, not an outside customer or production revenue.

The candidate covers Base and Base Sepolia. It freezes implementation source,
deployment declaration, selected ABI, escrow/collector set, token proxy and
implementation, linked library and code hashes. A block/route refresh cannot
rewrite this identity or reset nonce/budget state. USDC executable and linked
library bodies match the pinned compiler build; their metadata/IPFS provenance
remains unknown. That unknown is retained separately from runtime identity.

`account signup` self-registers a requester or contributor. Machine signup,
`account login --account <id>`, and `account recover --account <id>` use the
installed native account authority. Passwords enter through `--secret-file` or
`--secret-fd`. A recovery handle contains the new `password` and original
`recoveryCode` with schema `ae.password-file.v1`. Recovery revokes old account
sessions, rotates the recovery code, and retains the account's work and debt.
It does not decrypt a wallet or change a payout destination. Repeating the same
account operation recovers its original receipt. The current client stores
credentials only in its existing mode 0600 secret file.

`wallet local-create --keystore <new-private-file> --secret-file <handle>` uses
ethers 6.17.0 to create and encrypt a standard Ethereum JSON V3 keystore. The
password handle uses schema `ae.password-file.v1` and a password of at least 16
characters. `wallet encrypted-export --keystore <file> --out <new-private-file>`
copies encrypted material. `wallet recover --keystore <file> --secret-file
<handle>` verifies recovery independently of an account or profile. An upstream
`Wallet.fromEncryptedJson` can recover the same address. Back up the encrypted
export and password independently. The server never receives a seed, private
key, keystore, or wallet password. Output contains only the address and receipt.

`market prove-wallet` signs a fresh origin, tenant, account, address and epoch
bound challenge. An address declaration grants no wallet authority. Wallet
revocation blocks a fresh mandate; it cannot revoke a transaction already
broadcast on chain. A destination change is refused by the account/password
route and requires separately established wallet authority. Existing selected
terms and earned destinations are never rewritten.

`market call --action <action> --body-file <absolute-json> --operation <id>
--ca-file <ca>` uses the original action wire at
`/api/neomorphic-contributor-journey/v1/market/<action>`. The existing loopback
bearer form remains available with `--origin`. For a hosted cookie profile the
origin comes from the profile. Public `discover` uses the qualified machine
listing and reveals only intended public task fields.

The sequence is `post`, `interest`, `quote`, requester `select`, contributor
`assent`, `market fund`, `claim`, `deliver`, `review`, `approve`, then `retained`.
A quote freezes one selected contributor, requester/reviewer, artifact criteria,
asset, gross, fixed fee recipient, per-capture floor fee, net, expiry and wallet
control epochs in the existing canonical terms. Discovery creates no paid duty.
A quote uses `railCostCap: "0"`; network gas is separate from the 5% deduction.
For gross 19/20/21 atoms the fee is 0/1/1. Older fixed-net obligations are not
repriced, and a retained read never imports, pays, or creates another obligation.

`market fund --task <id> --quote-digest <digest> --chain-url <verified-rpc>
--keystore <file> --secret-file <handle> --operation <id> --ca-file <ca>` verifies
profile/source, exact selected quote, chain, contract code, collector and payer,
then signs only that EIP-3009 mandate. The pinned server operator journals the
original transaction before broadcast and reserves funding only after actual
chain confirmation. Reuse the same operation after a lost response.

An optional caller-owned `--signer-module <absolute-module>` can replace the
local keystore. It exports `accountKind: 'eoa'`, an address (or use the existing
`wallet declare` descriptor), `personalSign(message)`, and
`signTypedData({domain,types,message})`. Signatures can be strings or
`{address,signature}`. A reclaim signer also exports `signTransaction(tx)`.
The caller owns this module and its key access. No key material belongs in argv.

Review can leave `approval_pending`. Only the original authorized final capture
joins the retained artifact, canonical owed projection, and qualified settlement.
`reconcile` observes that operation. `payoutDisposition` refuses a second payout
for capture allocations even when the archival kernel field still says `owed`.
An unjournaled operator capture remains an incident. Pending and unknown outcomes
are preserved across restart; a new operation is not a recovery shortcut.

`market reclaim` uses the same exact task, quote, keystore and chain flags after
authorization expiry. It persists the original payer-signed transaction before
broadcast, then reads that hash on retry. It reclaims unearned escrow and is not
a post-capture refund. The chain owns capture versus reclaim, with one winner.
Public payer reclaim also requires explicit `--gas-limit`, `--max-fee-per-gas`
and `--max-priority-fee-per-gas` values in wei. L1/operator costs are separate;
execution gas limits do not provide an enforceable all-in L1 cap. Never replace
an uncertain transaction with a new operation or nonce.

The existing measurement records retain source, operation, technical provenance,
usefulness and repeat use separately. Fresh principal acquisition is unknown
unless observed evidence establishes it. Local-chain capture is not paid outside
work, a platform profit measurement, or public activation.
